ixmaps.jsapi.import(
{ "type": "Map",
  "name": "tolentino",
  "title": "Tolentino open data",
  "description": "Layer cartografici generati da iXmaps&nbsp;<hr>Questi layer cartografici si basano su dati rilascati dal comune di Tolentino sul proprio sito nella parte 'Open Data' con licenza IODL 2.0. La rappresentazione &egrave; un test, <b>non!</b> una pubblicazione ufficializzata<br><br>",
  "comment": "Creator: JsonGis 1.1 version:1.1 build:255 generation-time:Tue Feb 25 12:31:31 2014 ",
  "bbox": [13.240391, 43.129405 ,13.429970, 43.285768],
  "layers": [
      { "type": "FeatureCollection",
        "properties": {
          "name": "Contrade",
          "description": "",
          "Snippet": "",
          "visibility": "1",
          "open": "0",
          "legendstyle": "CHECKSUBLAYER",
          "end": ""
        },
        "link": {
        "properties": {
          "href": "tolentino_Contrade.js",
          "type": "geojson"
          }
        }
      },
      { "type": "FeatureCollection",
        "properties": {
          "name": "Piano_Acustico",
          "description": "",
          "Snippet": "",
          "visibility": "1",
          "open": "0",
          "legendstyle": "",
          "end": ""
        },
        "link": {
        "properties": {
          "href": "tolentino_Piano_Acustico.js",
          "type": "geojson"
          }
        }
      },
      { "type": "FeatureCollection",
        "properties": {
          "name": "SezCens2011",
          "description": "",
          "Snippet": "",
          "visibility": "1",
          "open": "0",
          "legendstyle": "",
          "end": ""
        },
        "link": {
        "properties": {
          "href": "tolentino_SezCens2011.js",
          "type": "geojson"
          }
        }
      },
      { "type": "FeatureCollection",
        "properties": {
          "name": "Sezioni_eletto_2010",
          "description": "",
          "Snippet": "",
          "visibility": "1",
          "open": "0",
          "legendstyle": "",
          "end": ""
        },
        "link": {
        "properties": {
          "href": "tolentino_Sezioni_eletto_2010.js",
          "type": "geojson"
          }
        }
      },
      { "type": "FeatureCollection",
        "properties": {
          "name": "edifici_pubblici",
          "description": "",
          "Snippet": "",
          "visibility": "1",
          "open": "0",
          "legendstyle": "CHECKSUBLAYER",
          "end": ""
        },
        "link": {
        "properties": {
          "href": "tolentino_edifici_pubblici.js",
          "type": "geojson"
          }
        }
      },
      { "type": "FeatureCollection",
        "properties": {
          "name": "edifici",
          "description": "",
          "Snippet": "",
          "visibility": "1",
          "open": "0",
          "legendstyle": "",
          "end": ""
        },
        "link": {
        "properties": {
          "href": "tolentino_edifici.js",
          "type": "geojson"
          }
        }
      },
      { "type": "FeatureCollection",
        "properties": {
          "name": "stradario",
          "description": "",
          "Snippet": "",
          "visibility": "1",
          "open": "0",
          "legendstyle": "",
          "end": ""
        },
        "link": {
        "properties": {
          "href": "tolentino_stradario.js",
          "type": "geojson"
          }
        }
      }
    ]
  }  );