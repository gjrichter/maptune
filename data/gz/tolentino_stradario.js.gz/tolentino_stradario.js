ixmaps.jsapi.import(
{ "type": "Map",
  "name": "tolentino_stradario",
  "comment": "Creator: Tolentino open data Layer cartografici generati da iXmaps&nbsp;<hr>Questi layer cartografici si basano su dati rilascati dal comune di Tolentino sul proprio sito nella parte 'Open Data' con licenza IODL 2.0. La rappresentazione &egrave; un test, <b>non!</b> una pubblicazione ufficializzata<br><br> version:JsonGis build:1.1 generation-time:1.1 ",
  "bbox": [13.240391, 43.129405 ,13.429970, 43.285768],
  "layers": [
    { "type": "FeatureCollection",
      "properties": {
        "name": "stradario",
        "description": "",
        "Snippet": "",
        "visibility": "1",
        "open": "0",
        "legendstyle": "",
        "end": ""
      },
      "features": [
        { "type": "Feature",
          "properties": {
            "name": "",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283111,43.214264 ,0],
                [13.283424,43.214279,0 ],
                [13.283484,43.214264,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.258725,43.183289 ,0],
                [13.258506,43.183594,0 ],
                [13.258892,43.183689,0 ],
                [13.259341,43.183716,0 ],
                [13.259616,43.183365,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ACCORAMBONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283708,43.210571 ,0],
                [13.283734,43.210594,0 ],
                [13.283906,43.210697,0 ],
                [13.284081,43.210796,0 ],
                [13.284262,43.210873,0 ],
                [13.284296,43.210888,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA ADRIANA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282287,43.209309 ,0],
                [13.282308,43.209297,0 ],
                [13.282358,43.209251,0 ],
                [13.282396,43.209206,0 ],
                [13.282443,43.209099,0 ],
                [13.282455,43.209053,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ADRIANA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281516,43.209099 ,0],
                [13.281633,43.209164,0 ],
                [13.281726,43.209229,0 ],
                [13.281806,43.209217,0 ],
                [13.282004,43.209240,0 ],
                [13.282171,43.209274,0 ],
                [13.282242,43.209293,0 ],
                [13.282287,43.209309,0 ],
                [13.282327,43.209320,0 ],
                [13.282421,43.209373,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.282421,43.209373 ,0],
                [13.282479,43.209389,0 ],
                [13.282878,43.209496,0 ],
                [13.282947,43.209507,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "LARGO AMADDIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284469,43.210461 ,0],
                [13.284503,43.210445,0 ],
                [13.284595,43.210419,0 ],
                [13.284709,43.210365,0 ],
                [13.284756,43.210316,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZALE DELLA BATTAGLIA DI TOLENTINO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291763,43.209213 ,0],
                [13.291949,43.209236,0 ],
                [13.292156,43.209309,0 ],
                [13.292249,43.209290,0 ],
                [13.292432,43.209358,0 ],
                [13.292558,43.209347,0 ],
                [13.292748,43.209126,0 ],
                [13.292211,43.208893,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DELL&#x27;AQUILA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281874,43.211166 ,0],
                [13.281815,43.211155,0 ],
                [13.282103,43.210884,0 ],
                [13.281963,43.210739,0 ],
                [13.281952,43.210720,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.280616,43.210922 ,0],
                [13.280647,43.210930,0 ],
                [13.280832,43.210979,0 ],
                [13.281025,43.211056,0 ],
                [13.281134,43.211090,0 ],
                [13.281178,43.211086,0 ],
                [13.281219,43.211063,0 ],
                [13.281385,43.211086,0 ],
                [13.281815,43.211155,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DELL&#x27;ARCO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284877,43.209488 ,0],
                [13.284884,43.209465,0 ],
                [13.284907,43.209385,0 ],
                [13.284927,43.209332,0 ],
                [13.284974,43.209248,0 ],
                [13.284915,43.209217,0 ],
                [13.284857,43.209187,0 ],
                [13.284912,43.209118,0 ],
                [13.284944,43.209084,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE CESARE BATTISTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286443,43.211235 ,0],
                [13.286465,43.211193,0 ],
                [13.287178,43.210674,0 ],
                [13.288468,43.209732,0 ],
                [13.288589,43.209690,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA BEATO TOMMASO DA TOLENTINO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284944,43.209084 ,0],
                [13.284961,43.209114,0 ],
                [13.285121,43.209209,0 ],
                [13.285332,43.209339,0 ],
                [13.285394,43.209400,0 ],
                [13.285442,43.209469,0 ],
                [13.285472,43.209526,0 ],
                [13.285517,43.209572,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "LARGO FRANCESCO SAVERIO BEZZI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283069,43.210442 ,0],
                [13.282863,43.210339,0 ],
                [13.282909,43.210293,0 ],
                [13.283090,43.210384,0 ],
                [13.283117,43.210400,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIOVANNI BEZZI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284520,43.209911 ,0],
                [13.284552,43.209900,0 ],
                [13.284671,43.209846,0 ],
                [13.284840,43.209755,0 ],
                [13.284967,43.209679,0 ],
                [13.285051,43.209625,0 ],
                [13.285101,43.209553,0 ],
                [13.285115,43.209534,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE BEZZI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285531,43.208054 ,0],
                [13.285542,43.208031,0 ],
                [13.285590,43.207943,0 ],
                [13.285712,43.207722,0 ],
                [13.285815,43.207554,0 ],
                [13.285828,43.207489,0 ],
                [13.285818,43.207409,0 ],
                [13.285806,43.207382,0 ],
                [13.285721,43.207241,0 ],
                [13.285712,43.207184,0 ],
                [13.285660,43.207138,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA NAPOLEONE BONAPARTE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284009,43.210045 ,0],
                [13.284078,43.210007,0 ],
                [13.284335,43.209793,0 ],
                [13.284355,43.209778,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO BONELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285400,43.207508 ,0],
                [13.285429,43.207508,0 ],
                [13.285609,43.207504,0 ],
                [13.285794,43.207493,0 ],
                [13.285828,43.207489,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DELLA CARITA&#x27;",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283254,43.209156 ,0],
                [13.283266,43.209118,0 ],
                [13.283305,43.209053,0 ],
                [13.283360,43.208939,0 ],
                [13.283388,43.208855,0 ],
                [13.283392,43.208839,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ALBINO CASELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282404,43.211853 ,0],
                [13.282522,43.211895,0 ],
                [13.283743,43.212368,0 ],
                [13.283798,43.212414,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DELLE CASERME",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282115,43.208939 ,0],
                [13.282364,43.209034,0 ],
                [13.282455,43.209053,0 ],
                [13.282695,43.209042,0 ],
                [13.282816,43.209053,0 ],
                [13.282873,43.209057,0 ],
                [13.283173,43.209141,0 ],
                [13.283254,43.209156,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA CAVOUR",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281571,43.211864 ,0],
                [13.281535,43.211849,0 ],
                [13.281499,43.211834,0 ],
                [13.281080,43.211994,0 ],
                [13.280946,43.212311,0 ],
                [13.280973,43.212330,0 ],
                [13.281000,43.212345,0 ],
                [13.281393,43.212208,0 ],
                [13.281571,43.211864,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GAETANO CIAPPI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280338,43.212517 ,0],
                [13.280372,43.212486,0 ],
                [13.280628,43.212269,0 ],
                [13.280806,43.211815,0 ],
                [13.280849,43.211704,0 ],
                [13.280863,43.211689,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA FILIPPO CORRIDONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282200,43.211262 ,0],
                [13.282224,43.211273,0 ],
                [13.282697,43.211449,0 ],
                [13.283267,43.211597,0 ],
                [13.283323,43.211617,0 ],
                [13.283504,43.211670,0 ],
                [13.283554,43.211704,0 ],
                [13.283760,43.211838,0 ],
                [13.284249,43.212170,0 ],
                [13.284286,43.212200,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ANDREA COSTA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280024,43.212322 ,0],
                [13.280022,43.212345,0 ],
                [13.279963,43.212471,0 ],
                [13.280396,43.212738,0 ],
                [13.280449,43.212772,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA DELLA CROCE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280901,43.211468 ,0],
                [13.280923,43.211422,0 ],
                [13.280993,43.211308,0 ],
                [13.281090,43.211205,0 ],
                [13.281178,43.211086,0 ],
                [13.281242,43.210991,0 ],
                [13.281345,43.210892,0 ],
                [13.281502,43.210754,0 ],
                [13.281577,43.210678,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CURLAMONTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282307,43.209682 ,0],
                [13.282334,43.209682,0 ],
                [13.282478,43.209740,0 ],
                [13.282535,43.209778,0 ],
                [13.282741,43.209850,0 ],
                [13.282814,43.209869,0 ],
                [13.283004,43.209991,0 ],
                [13.283031,43.210003,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ALBO DAMIANI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282947,43.209507 ,0],
                [13.283003,43.209522,0 ],
                [13.283124,43.209572,0 ],
                [13.283064,43.209656,0 ],
                [13.283213,43.209717,0 ],
                [13.283383,43.209797,0 ],
                [13.283635,43.209904,0 ],
                [13.283712,43.209934,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DELLE ERBE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283120,43.210098 ,0],
                [13.283133,43.210121,0 ],
                [13.283199,43.210163,0 ],
                [13.283278,43.210213,0 ],
                [13.283299,43.210228,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "GALLERIA EUROPA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285419,43.211124 ,0],
                [13.285522,43.211182,0 ],
                [13.285875,43.211445,0 ],
                [13.285974,43.211525,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "LARGO FIDI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282947,43.209507 ,0],
                [13.283025,43.209400,0 ],
                [13.283075,43.209377,0 ],
                [13.283206,43.209175,0 ],
                [13.283254,43.209156,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA FRANCESCO FILELFO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282917,43.210617 ,0],
                [13.282937,43.210625,0 ],
                [13.283498,43.210907,0 ],
                [13.283823,43.211185,0 ],
                [13.283841,43.211205,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA FRANCESCO FILELFO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284123,43.209511 ,0],
                [13.284192,43.209442,0 ],
                [13.284225,43.209408,0 ],
                [13.284270,43.209362,0 ],
                [13.284504,43.209057,0 ],
                [13.284558,43.208969,0 ],
                [13.284575,43.208939,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.281535,43.211849 ,0],
                [13.281555,43.211830,0 ],
                [13.281765,43.211647,0 ],
                [13.282009,43.211426,0 ],
                [13.282037,43.211399,0 ],
                [13.282138,43.211315,0 ],
                [13.282200,43.211262,0 ],
                [13.282373,43.211113,0 ],
                [13.282521,43.211018,0 ],
                [13.282753,43.210819,0 ],
                [13.282917,43.210617,0 ],
                [13.283069,43.210442,0 ],
                [13.283116,43.210400,0 ],
                [13.283299,43.210228,0 ],
                [13.283402,43.210136,0 ],
                [13.283617,43.209949,0 ],
                [13.283712,43.209934,0 ],
                [13.283799,43.209843,0 ],
                [13.284030,43.209602,0 ],
                [13.284123,43.209511,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CORSO GIUSEPPE GARIBALDI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285139,43.208828 ,0],
                [13.285183,43.208851,0 ],
                [13.285484,43.208923,0 ],
                [13.285717,43.208981,0 ],
                [13.285814,43.209007,0 ],
                [13.286096,43.209095,0 ],
                [13.286597,43.209179,0 ],
                [13.286759,43.209202,0 ],
                [13.286852,43.209190,0 ],
                [13.286968,43.209175,0 ],
                [13.287133,43.209251,0 ],
                [13.287214,43.209263,0 ],
                [13.287350,43.209278,0 ],
                [13.287681,43.209320,0 ],
                [13.288025,43.209385,0 ],
                [13.288175,43.209419,0 ],
                [13.288382,43.209530,0 ],
                [13.288506,43.209629,0 ],
                [13.288589,43.209690,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PAOLO GIACCONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280066,43.212173 ,0],
                [13.280024,43.212322,0 ],
                [13.280338,43.212517,0 ],
                [13.280583,43.212666,0 ],
                [13.280946,43.212894,0 ],
                [13.280975,43.212917,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ANTONIO GRAMSCI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.279971,43.211292 ,0],
                [13.280076,43.211311,0 ],
                [13.280270,43.211346,0 ],
                [13.280760,43.211441,0 ],
                [13.280901,43.211468,0 ],
                [13.280956,43.211479,0 ],
                [13.281622,43.211605,0 ],
                [13.281731,43.211636,0 ],
                [13.281765,43.211647,0 ],
                [13.281796,43.211655,0 ],
                [13.282294,43.211796,0 ],
                [13.282404,43.211853,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA DELLA LIBERTA&#x27;",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285139,43.208828 ,0],
                [13.285052,43.208801,0 ],
                [13.284844,43.208733,0 ],
                [13.284802,43.208714,0 ],
                [13.284587,43.208622,0 ],
                [13.284567,43.208649,0 ],
                [13.284390,43.208885,0 ],
                [13.284575,43.208939,0 ],
                [13.284653,43.208958,0 ],
                [13.284944,43.209080,0 ],
                [13.285139,43.208828,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE LUCATELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282179,43.210045 ,0],
                [13.282201,43.210056,0 ],
                [13.282398,43.210159,0 ],
                [13.282495,43.210217,0 ],
                [13.282551,43.210217,0 ],
                [13.282849,43.210335,0 ],
                [13.282863,43.210339,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA MADAMA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283213,43.209717 ,0],
                [13.283201,43.209732,0 ],
                [13.283031,43.210003,0 ],
                [13.283120,43.210098,0 ],
                [13.283364,43.209820,0 ],
                [13.283383,43.209797,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "LARGO CESARE MARCORELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283121,43.208370 ,0],
                [13.283062,43.208267,0 ],
                [13.283354,43.207970,0 ],
                [13.283533,43.207962,0 ],
                [13.283445,43.208233,0 ],
                [13.283319,43.208210,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA MARTIRI DI MONTALTO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283402,43.210136 ,0],
                [13.283425,43.210148,0 ],
                [13.283874,43.210392,0 ],
                [13.283913,43.210346,0 ],
                [13.284121,43.210224,0 ],
                [13.284196,43.210251,0 ],
                [13.284217,43.210167,0 ],
                [13.284064,43.210075,0 ],
                [13.284009,43.210045,0 ],
                [13.283771,43.209919,0 ],
                [13.283712,43.209934,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PACIFICO MASSI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282697,43.211449 ,0],
                [13.282756,43.211437,0 ],
                [13.283455,43.210865,0 ],
                [13.283708,43.210571,0 ],
                [13.283853,43.210419,0 ],
                [13.283874,43.210392,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DEL MATTATOIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280776,43.213100 ,0],
                [13.280815,43.213020,0 ],
                [13.280975,43.212917,0 ],
                [13.281021,43.212887,0 ],
                [13.281326,43.212646,0 ],
                [13.281611,43.212414,0 ],
                [13.281691,43.212376,0 ],
                [13.281761,43.212337,0 ],
                [13.281897,43.212059,0 ],
                [13.282032,43.212101,0 ],
                [13.282146,43.212135,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA NICCOLO&#x27; MAURUZI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284024,43.209549 ,0],
                [13.283296,43.209183,0 ],
                [13.283329,43.209156,0 ],
                [13.283774,43.209370,0 ],
                [13.283867,43.209274,0 ],
                [13.284150,43.209389,0 ],
                [13.284225,43.209408,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.283254,43.209156 ,0],
                [13.283296,43.209183,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA GIUSEPPE MAZZINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283486,43.208344 ,0],
                [13.283509,43.208279,0 ],
                [13.283587,43.208084,0 ],
                [13.283751,43.208107,0 ],
                [13.283811,43.207947,0 ],
                [13.283745,43.207932,0 ],
                [13.283605,43.207935,0 ],
                [13.283566,43.208061,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ENRICO MESTICA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285786,43.209721 ,0],
                [13.285803,43.209736,0 ],
                [13.285948,43.209824,0 ],
                [13.286106,43.209927,0 ],
                [13.286259,43.210064,0 ],
                [13.286370,43.210163,0 ],
                [13.286384,43.210175,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DEL MONASTERO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281196,43.210537 ,0],
                [13.281299,43.210552,0 ],
                [13.281505,43.210636,0 ],
                [13.281748,43.210716,0 ],
                [13.281767,43.210724,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA MONTECAVALLO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281333,43.209576 ,0],
                [13.281349,43.209587,0 ],
                [13.281449,43.209663,0 ],
                [13.281545,43.209724,0 ],
                [13.281685,43.209801,0 ],
                [13.281714,43.209812,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MONTECAVALLO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280270,43.211346 ,0],
                [13.280328,43.211300,0 ],
                [13.280422,43.211216,0 ],
                [13.280515,43.211124,0 ],
                [13.280589,43.210987,0 ],
                [13.280616,43.210922,0 ],
                [13.280651,43.210720,0 ],
                [13.280645,43.210598,0 ],
                [13.280717,43.210430,0 ],
                [13.280767,43.210346,0 ],
                [13.280808,43.210224,0 ],
                [13.280985,43.209995,0 ],
                [13.281028,43.209938,0 ],
                [13.281099,43.209839,0 ],
                [13.281134,43.209797,0 ],
                [13.281163,43.209759,0 ],
                [13.281241,43.209663,0 ],
                [13.281333,43.209576,0 ],
                [13.281421,43.209492,0 ],
                [13.281503,43.209408,0 ],
                [13.281593,43.209316,0 ],
                [13.281671,43.209240,0 ],
                [13.281726,43.209229,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA DEL MORO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281559,43.210064 ,0],
                [13.281581,43.210072,0 ],
                [13.281748,43.210148,0 ],
                [13.281865,43.210228,0 ],
                [13.282004,43.210293,0 ],
                [13.282027,43.210304,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO NARDI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281953,43.210495 ,0],
                [13.281985,43.210503,0 ],
                [13.282150,43.210537,0 ],
                [13.282505,43.210258,0 ],
                [13.282521,43.210217,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GUGLIELMO OBERDAN",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285477,43.208172 ,0],
                [13.285459,43.208202,0 ],
                [13.285463,43.208225,0 ],
                [13.285532,43.208275,0 ],
                [13.285744,43.208424,0 ],
                [13.285926,43.208496,0 ],
                [13.285970,43.208515,0 ],
                [13.286239,43.208618,0 ],
                [13.286264,43.208630,0 ],
                [13.286467,43.208744,0 ],
                [13.286664,43.208851,0 ],
                [13.286842,43.209011,0 ],
                [13.286942,43.209118,0 ],
                [13.286968,43.209175,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DELL&#x27;ORFANOTROFIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284359,43.211422 ,0],
                [13.284311,43.211384,0 ],
                [13.284238,43.211330,0 ],
                [13.284355,43.211227,0 ],
                [13.284379,43.211205,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA ORSELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281134,43.209797 ,0],
                [13.281149,43.209805,0 ],
                [13.281256,43.209843,0 ],
                [13.281374,43.209892,0 ],
                [13.281385,43.209900,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO ORSELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281216,43.210037 ,0],
                [13.281239,43.210018,0 ],
                [13.281317,43.209957,0 ],
                [13.281385,43.209900,0 ],
                [13.281430,43.209850,0 ],
                [13.281529,43.209736,0 ],
                [13.281545,43.209724,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DEGLI ORTOLANI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281299,43.210552 ,0],
                [13.281309,43.210541,0 ],
                [13.281352,43.210453,0 ],
                [13.281380,43.210285,0 ],
                [13.281394,43.210247,0 ],
                [13.281509,43.210121,0 ],
                [13.281559,43.210064,0 ],
                [13.281595,43.210022,0 ],
                [13.281692,43.209843,0 ],
                [13.281714,43.209812,0 ],
                [13.281744,43.209778,0 ],
                [13.281863,43.209690,0 ],
                [13.281978,43.209629,0 ],
                [13.282036,43.209587,0 ],
                [13.282052,43.209557,0 ],
                [13.282067,43.209538,0 ],
                [13.282088,43.209507,0 ],
                [13.282191,43.209373,0 ],
                [13.282237,43.209305,0 ],
                [13.282242,43.209293,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA OZERI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282816,43.209053 ,0],
                [13.282829,43.209034,0 ],
                [13.282871,43.208961,0 ],
                [13.282907,43.208885,0 ],
                [13.282951,43.208855,0 ],
                [13.283078,43.208828,0 ],
                [13.283128,43.208824,0 ],
                [13.283175,43.208820,0 ],
                [13.283325,43.208836,0 ],
                [13.283392,43.208839,0 ],
                [13.283525,43.208843,0 ],
                [13.283719,43.208836,0 ],
                [13.283883,43.208832,0 ],
                [13.284050,43.208839,0 ],
                [13.284204,43.208866,0 ],
                [13.284216,43.208866,0 ],
                [13.284259,43.208878,0 ],
                [13.284311,43.208889,0 ],
                [13.284390,43.208885,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DELLA PACE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284123,43.209511 ,0],
                [13.284147,43.209553,0 ],
                [13.284199,43.209633,0 ],
                [13.284355,43.209778,0 ],
                [13.284520,43.209911,0 ],
                [13.284553,43.209938,0 ],
                [13.284577,43.209969,0 ],
                [13.284595,43.209988,0 ],
                [13.284737,43.210094,0 ],
                [13.284867,43.210186,0 ],
                [13.285105,43.210320,0 ],
                [13.285161,43.210346,0 ],
                [13.285284,43.210423,0 ],
                [13.285765,43.210751,0 ],
                [13.285816,43.210800,0 ],
                [13.285938,43.210903,0 ],
                [13.286246,43.211109,0 ],
                [13.286443,43.211235,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO PADOVANI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285051,43.209625 ,0],
                [13.285069,43.209641,0 ],
                [13.285233,43.209740,0 ],
                [13.285409,43.209805,0 ],
                [13.285564,43.209690,0 ],
                [13.285731,43.209782,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA EMIDIO PALLOTTA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280806,43.211815 ,0],
                [13.280837,43.211834,0 ],
                [13.281049,43.211971,0 ],
                [13.281080,43.211994,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.281393,43.212208 ,0],
                [13.281691,43.212376,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO PANUNZI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284444,43.208179 ,0],
                [13.284469,43.208183,0 ],
                [13.284580,43.208214,0 ],
                [13.284648,43.208233,0 ],
                [13.284991,43.208340,0 ],
                [13.285017,43.208347,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ANNIBALE PARISANI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284196,43.210251 ,0],
                [13.284469,43.210461,0 ],
                [13.284682,43.210625,0 ],
                [13.285336,43.211067,0 ],
                [13.285419,43.211124,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA NICOLO&#x27; PICCININO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284120,43.211006 ,0],
                [13.284150,43.211029,0 ],
                [13.284379,43.211205,0 ],
                [13.284509,43.211105,0 ],
                [13.284274,43.210938,0 ],
                [13.284249,43.210918,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MARIANO PIERVITTORI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284577,43.209969 ,0],
                [13.284601,43.209957,0 ],
                [13.284655,43.209942,0 ],
                [13.284752,43.209927,0 ],
                [13.284887,43.209927,0 ],
                [13.284986,43.209938,0 ],
                [13.285186,43.210022,0 ],
                [13.285338,43.210110,0 ],
                [13.285355,43.210121,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DEL PONTE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285695,43.207020 ,0],
                [13.285910,43.207047,0 ],
                [13.286036,43.207069,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DEL POPOLO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284601,43.207924 ,0],
                [13.284605,43.207901,0 ],
                [13.284614,43.207855,0 ],
                [13.284612,43.207836,0 ],
                [13.284456,43.207794,0 ],
                [13.284451,43.207722,0 ],
                [13.284462,43.207623,0 ],
                [13.284521,43.207592,0 ],
                [13.284533,43.207523,0 ],
                [13.284516,43.207489,0 ],
                [13.284527,43.207428,0 ],
                [13.284531,43.207405,0 ],
                [13.284541,43.207348,0 ],
                [13.284593,43.207321,0 ],
                [13.284686,43.207283,0 ],
                [13.284801,43.207268,0 ],
                [13.284893,43.207253,0 ],
                [13.284984,43.207191,0 ],
                [13.284994,43.207111,0 ],
                [13.285054,43.207016,0 ],
                [13.285157,43.206944,0 ],
                [13.285324,43.206924,0 ],
                [13.285492,43.206959,0 ],
                [13.285670,43.206982,0 ],
                [13.285705,43.206989,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA VINCENZO PORCELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280760,43.211441 ,0],
                [13.280747,43.211472,0 ],
                [13.280683,43.211655,0 ],
                [13.280863,43.211689,0 ],
                [13.280942,43.211514,0 ],
                [13.280956,43.211479,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA I MAGGIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284533,43.207523 ,0],
                [13.284682,43.207523,0 ],
                [13.284802,43.207516,0 ],
                [13.284943,43.207489,0 ],
                [13.285026,43.207447,0 ],
                [13.285080,43.207420,0 ],
                [13.285092,43.207371,0 ],
                [13.285120,43.207317,0 ],
                [13.285327,43.207336,0 ],
                [13.285447,43.207355,0 ],
                [13.285472,43.207359,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ROMA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.279817,43.209301 ,0],
                [13.280766,43.209377,0 ],
                [13.280946,43.209377,0 ],
                [13.281095,43.209347,0 ],
                [13.281357,43.209190,0 ],
                [13.281516,43.209099,0 ],
                [13.281666,43.209015,0 ],
                [13.281916,43.208885,0 ],
                [13.282460,43.208611,0 ],
                [13.282985,43.208408,0 ],
                [13.283121,43.208370,0 ],
                [13.283248,43.208332,0 ],
                [13.283368,43.208336,0 ],
                [13.283486,43.208344,0 ],
                [13.283570,43.208351,0 ],
                [13.283780,43.208385,0 ],
                [13.284225,43.208492,0 ],
                [13.284269,43.208504,0 ],
                [13.284534,43.208603,0 ],
                [13.284587,43.208622,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CARLO RUTILONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.279595,43.213280 ,0],
                [13.279728,43.213242,0 ],
                [13.279922,43.213173,0 ],
                [13.280025,43.213112,0 ],
                [13.280270,43.212933,0 ],
                [13.280449,43.212772,0 ],
                [13.280583,43.212666,0 ],
                [13.280954,43.212345,0 ],
                [13.280973,43.212330,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO SALNITRARI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284104,43.207294 ,0],
                [13.284192,43.207310,0 ],
                [13.284510,43.207397,0 ],
                [13.284531,43.207405,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA SAN CATERVO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286611,43.209396 ,0],
                [13.286639,43.209366,0 ],
                [13.286734,43.209240,0 ],
                [13.286759,43.209202,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SAN CATERVO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284192,43.209442 ,0],
                [13.284279,43.209457,0 ],
                [13.284521,43.209457,0 ],
                [13.284843,43.209480,0 ],
                [13.284877,43.209488,0 ],
                [13.285115,43.209534,0 ],
                [13.285280,43.209560,0 ],
                [13.285517,43.209572,0 ],
                [13.285854,43.209610,0 ],
                [13.285943,43.209549,0 ],
                [13.286013,43.209507,0 ],
                [13.286093,43.209480,0 ],
                [13.286209,43.209446,0 ],
                [13.286326,43.209412,0 ],
                [13.286424,43.209393,0 ],
                [13.286569,43.209393,0 ],
                [13.286611,43.209396,0 ],
                [13.286690,43.209419,0 ],
                [13.286824,43.209469,0 ],
                [13.286860,43.209518,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA SAN GIOVANNI BOSCO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282146,43.212135 ,0],
                [13.282213,43.212101,0 ],
                [13.282404,43.211853,0 ],
                [13.282657,43.211510,0 ],
                [13.282697,43.211449,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA SAN NICOLA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285160,43.208073 ,0],
                [13.285189,43.208080,0 ],
                [13.285477,43.208172,0 ],
                [13.285531,43.208054,0 ],
                [13.285227,43.207970,0 ],
                [13.285204,43.207962,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA SAN NICOLA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285052,43.208801 ,0],
                [13.285086,43.208763,0 ],
                [13.285145,43.208717,0 ],
                [13.285228,43.208664,0 ],
                [13.285276,43.208614,0 ],
                [13.285331,43.208557,0 ],
                [13.285350,43.208538,0 ],
                [13.285385,43.208488,0 ],
                [13.285432,43.208393,0 ],
                [13.285516,43.208290,0 ],
                [13.285532,43.208275,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SAN NICOLA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284802,43.208714 ,0],
                [13.284833,43.208675,0 ],
                [13.284939,43.208488,0 ],
                [13.285017,43.208347,0 ],
                [13.285084,43.208225,0 ],
                [13.285160,43.208073,0 ],
                [13.285179,43.208027,0 ],
                [13.285204,43.207962,0 ],
                [13.285261,43.207817,0 ],
                [13.285302,43.207737,0 ],
                [13.285342,43.207603,0 ],
                [13.285400,43.207508,0 ],
                [13.285472,43.207359,0 ],
                [13.285487,43.207329,0 ],
                [13.285569,43.207161,0 ],
                [13.285660,43.207138,0 ],
                [13.285695,43.207020,0 ],
                [13.285705,43.206989,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.285705,43.206989 ,0],
                [13.285732,43.206905,0 ],
                [13.285748,43.206871,0 ],
                [13.285864,43.206764,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SAN NICOLO&#x27;",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281593,43.209316 ,0],
                [13.281617,43.209332,0 ],
                [13.282052,43.209557,0 ],
                [13.282061,43.209583,0 ],
                [13.282119,43.209618,0 ],
                [13.282272,43.209686,0 ],
                [13.282307,43.209682,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO SAN PIETRO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286374,43.208427 ,0],
                [13.286406,43.208439,0 ],
                [13.286669,43.208435,0 ],
                [13.286794,43.208405,0 ],
                [13.286922,43.208332,0 ],
                [13.287040,43.208275,0 ],
                [13.287089,43.208275,0 ],
                [13.287196,43.208485,0 ],
                [13.287224,43.208534,0 ],
                [13.287488,43.208809,0 ],
                [13.287553,43.208908,0 ],
                [13.287621,43.209007,0 ],
                [13.287666,43.209034,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SAN SALVATORE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283128,43.208824 ,0],
                [13.283134,43.208767,0 ],
                [13.283156,43.208759,0 ],
                [13.283230,43.208633,0 ],
                [13.283290,43.208569,0 ],
                [13.283352,43.208508,0 ],
                [13.283370,43.208408,0 ],
                [13.283368,43.208336,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.282936,43.208725 ,0],
                [13.283134,43.208767,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA SANTA MARIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284225,43.208492 ,0],
                [13.284241,43.208458,0 ],
                [13.284258,43.208393,0 ],
                [13.284274,43.208302,0 ],
                [13.284288,43.208267,0 ],
                [13.284328,43.208256,0 ],
                [13.284444,43.208179,0 ],
                [13.284466,43.208164,0 ],
                [13.284484,43.208145,0 ],
                [13.284500,43.208126,0 ],
                [13.284562,43.208057,0 ],
                [13.284594,43.207996,0 ],
                [13.284602,43.207947,0 ],
                [13.284601,43.207924,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.284266,43.208237 ,0],
                [13.284288,43.208267,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SANTA MARIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284451,43.207722 ,0],
                [13.284431,43.207722,0 ],
                [13.284201,43.207718,0 ],
                [13.284161,43.207699,0 ],
                [13.284040,43.207687,0 ],
                [13.284010,43.207829,0 ],
                [13.283960,43.207962,0 ],
                [13.284081,43.208004,0 ],
                [13.284121,43.208023,0 ],
                [13.284215,43.208065,0 ],
                [13.284230,43.208069,0 ],
                [13.284280,43.208080,0 ],
                [13.284458,43.208134,0 ],
                [13.284484,43.208145,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.283811,43.207947 ,0],
                [13.283960,43.207962,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "LARGO SANTA TERESA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281952,43.210720 ,0],
                [13.281931,43.210651,0 ],
                [13.281898,43.210644,0 ],
                [13.281818,43.210640,0 ],
                [13.281767,43.210724,0 ],
                [13.281751,43.210770,0 ],
                [13.281857,43.210808,0 ],
                [13.281952,43.210720,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA SAN VINCENZO MARIA STRAMBI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.287214,43.209263 ,0],
                [13.287200,43.209297,0 ],
                [13.287078,43.209396,0 ],
                [13.287189,43.209465,0 ],
                [13.287283,43.209480,0 ],
                [13.287338,43.209316,0 ],
                [13.287350,43.209278,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA NAZARIO SAURO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286406,43.210155 ,0],
                [13.286493,43.210220,0 ],
                [13.286574,43.210243,0 ],
                [13.287057,43.210590,0 ],
                [13.287178,43.210674,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MEDORO SAVINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284196,43.210251 ,0],
                [13.284232,43.210228,0 ],
                [13.284558,43.209976,0 ],
                [13.284577,43.209969,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DELLE SCUOLE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285350,43.208538 ,0],
                [13.285367,43.208542,0 ],
                [13.285545,43.208591,0 ],
                [13.285720,43.208443,0 ],
                [13.285744,43.208424,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA DOMENICO SILVERI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285926,43.208496 ,0],
                [13.286006,43.208366,0 ],
                [13.286035,43.208347,0 ],
                [13.286133,43.208374,0 ],
                [13.286188,43.208363,0 ],
                [13.286226,43.208332,0 ],
                [13.286409,43.208393,0 ],
                [13.286374,43.208427,0 ],
                [13.286277,43.208580,0 ],
                [13.286239,43.208618,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA BENEDETTO SILVIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281898,43.210644 ,0],
                [13.281900,43.210632,0 ],
                [13.281953,43.210495,0 ],
                [13.281980,43.210426,0 ],
                [13.282027,43.210304,0 ],
                [13.282102,43.210194,0 ],
                [13.282149,43.210110,0 ],
                [13.282179,43.210045,0 ],
                [13.282206,43.209949,0 ],
                [13.282213,43.209904,0 ],
                [13.282220,43.209862,0 ],
                [13.282226,43.209805,0 ],
                [13.282274,43.209713,0 ],
                [13.282307,43.209682,0 ],
                [13.282316,43.209675,0 ],
                [13.282370,43.209621,0 ],
                [13.282410,43.209553,0 ],
                [13.282434,43.209473,0 ],
                [13.282442,43.209427,0 ],
                [13.282421,43.209373,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SPARACIARI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284081,43.208004 ,0],
                [13.284095,43.207985,0 ],
                [13.284136,43.207920,0 ],
                [13.284185,43.207859,0 ],
                [13.284294,43.207867,0 ],
                [13.284410,43.207882,0 ],
                [13.284571,43.207920,0 ],
                [13.284601,43.207924,0 ],
                [13.284631,43.207928,0 ],
                [13.284805,43.207954,0 ],
                [13.284960,43.207977,0 ],
                [13.285156,43.208019,0 ],
                [13.285179,43.208027,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO STORTO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282213,43.209904 ,0],
                [13.282237,43.209911,0 ],
                [13.282421,43.209991,0 ],
                [13.282454,43.209988,0 ],
                [13.282508,43.209896,0 ],
                [13.282540,43.209808,0 ],
                [13.282535,43.209778,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA STRETTA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280832,43.210979 ,0],
                [13.280849,43.210957,0 ],
                [13.280908,43.210835,0 ],
                [13.281030,43.210690,0 ],
                [13.281095,43.210625,0 ],
                [13.281164,43.210541,0 ],
                [13.281196,43.210537,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA FERNANDO TAMBRONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285075,43.211361 ,0],
                [13.285419,43.211124,0 ],
                [13.285799,43.210865,0 ],
                [13.285816,43.210800,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DEL TORRIONE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281100,43.209839 ,0],
                [13.281060,43.209816,0 ],
                [13.280958,43.209766,0 ],
                [13.281059,43.209663,0 ],
                [13.281218,43.209511,0 ],
                [13.281313,43.209431,0 ],
                [13.281402,43.209476,0 ],
                [13.281421,43.209492,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA DEL TRIANGOLO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284178,43.208187 ,0],
                [13.284187,43.208160,0 ],
                [13.284225,43.208084,0 ],
                [13.284230,43.208069,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DEL TRIANGOLO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283751,43.208107 ,0],
                [13.283777,43.208115,0 ],
                [13.283824,43.208122,0 ],
                [13.283935,43.208138,0 ],
                [13.284041,43.208164,0 ],
                [13.284146,43.208183,0 ],
                [13.284178,43.208187,0 ],
                [13.284269,43.208195,0 ],
                [13.284266,43.208237,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA DELL&#x27;UNITA&#x27;",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285287,43.211792 ,0],
                [13.285088,43.211876,0 ],
                [13.284665,43.211597,0 ],
                [13.285033,43.211338,0 ],
                [13.285075,43.211361,0 ],
                [13.285123,43.211456,0 ],
                [13.285462,43.211716,0 ],
                [13.285287,43.211792,0 ],
                [13.285387,43.211876,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA NICOLA VACCAI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282037,43.211399 ,0],
                [13.281971,43.211376,0 ],
                [13.281844,43.211349,0 ],
                [13.281874,43.211166,0 ],
                [13.281993,43.211239,0 ],
                [13.282083,43.211285,0 ],
                [13.282138,43.211315,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA NICOLA VACCAI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285717,43.208981 ,0],
                [13.285738,43.208935,0 ],
                [13.285837,43.208767,0 ],
                [13.285879,43.208694,0 ],
                [13.285883,43.208649,0 ],
                [13.285950,43.208546,0 ],
                [13.285970,43.208515,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA VALPORRO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285647,43.209869 ,0],
                [13.285664,43.209888,0 ],
                [13.285772,43.209988,0 ],
                [13.285839,43.210087,0 ],
                [13.285875,43.210152,0 ],
                [13.285946,43.210239,0 ],
                [13.286021,43.210308,0 ],
                [13.286104,43.210373,0 ],
                [13.286134,43.210388,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA VALPORRO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285816,43.210800 ,0],
                [13.285855,43.210735,0 ],
                [13.285892,43.210693,0 ],
                [13.285952,43.210594,0 ],
                [13.285996,43.210529,0 ],
                [13.286050,43.210457,0 ],
                [13.286134,43.210388,0 ],
                [13.286207,43.210331,0 ],
                [13.286286,43.210270,0 ],
                [13.286384,43.210175,0 ],
                [13.286406,43.210155,0 ],
                [13.286449,43.210087,0 ],
                [13.286529,43.209965,0 ],
                [13.286628,43.209824,0 ],
                [13.286742,43.209679,0 ],
                [13.286860,43.209518,0 ],
                [13.286970,43.209469,0 ],
                [13.287055,43.209412,0 ],
                [13.287078,43.209396,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA VALTIERI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280985,43.209995 ,0],
                [13.281004,43.210003,0 ],
                [13.281170,43.210072,0 ],
                [13.281216,43.210037,0 ],
                [13.281053,43.209949,0 ],
                [13.281028,43.209938,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA VALTIERI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281170,43.210072 ,0],
                [13.281155,43.210106,0 ],
                [13.281366,43.210228,0 ],
                [13.281394,43.210247,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DEI VASARI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283554,43.211704 ,0],
                [13.283607,43.211674,0 ],
                [13.283844,43.211586,0 ],
                [13.284359,43.211422,0 ],
                [13.284617,43.211578,0 ],
                [13.284665,43.211597,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA LAURA ZAMPESCHI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283323,43.211617 ,0],
                [13.283347,43.211548,0 ],
                [13.283841,43.211205,0 ],
                [13.284120,43.211006,0 ],
                [13.284249,43.210918,0 ],
                [13.284296,43.210888,0 ],
                [13.284682,43.210625,0 ],
                [13.284816,43.210529,0 ],
                [13.284988,43.210419,0 ],
                [13.285105,43.210320,0 ],
                [13.285152,43.210278,0 ],
                [13.285221,43.210220,0 ],
                [13.285355,43.210121,0 ],
                [13.285442,43.210060,0 ],
                [13.285543,43.209972,0 ],
                [13.285647,43.209869,0 ],
                [13.285688,43.209831,0 ],
                [13.285731,43.209782,0 ],
                [13.285786,43.209721,0 ],
                [13.285857,43.209633,0 ],
                [13.285854,43.209610,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ADAMELLO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288647,43.215061 ,0],
                [13.289123,43.215336,0 ],
                [13.289477,43.215534,0 ],
                [13.289717,43.215679,0 ],
                [13.290004,43.215843,0 ],
                [13.290122,43.215916,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.285462,43.213413 ,0],
                [13.285549,43.213440,0 ],
                [13.286186,43.213757,0 ],
                [13.287244,43.214272,0 ],
                [13.288104,43.214741,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE DANTE ALIGHIERI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.294499,43.214783 ,0],
                [13.294552,43.214775,0 ],
                [13.296035,43.214539,0 ],
                [13.296306,43.214661,0 ],
                [13.296788,43.214878,0 ],
                [13.296864,43.214939,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA UMBERTO ANGELELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.295746,43.218445 ,0],
                [13.296202,43.218864,0 ],
                [13.296570,43.218636,0 ],
                [13.296642,43.218590,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SALVADOR ALLENDE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.297741,43.214901 ,0],
                [13.298257,43.214352,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ARSIERO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.292445,43.216290 ,0],
                [13.292515,43.216251,0 ],
                [13.292832,43.215988,0 ],
                [13.292946,43.215866,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ASIAGO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.294198,43.217617 ,0],
                [13.294358,43.217682,0 ],
                [13.294708,43.217739,0 ],
                [13.294938,43.217766,0 ],
                [13.295217,43.217628,0 ],
                [13.295293,43.217575,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.294088,43.218067 ,0],
                [13.294320,43.218033,0 ],
                [13.294681,43.217892,0 ],
                [13.294938,43.217766,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA A.V.I.S.",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.334258,43.225853 ,0],
                [13.335340,43.224007,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ADINO BARCARELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288923,43.217522 ,0],
                [13.289425,43.217068,0 ],
                [13.289976,43.216568,0 ],
                [13.290071,43.216484,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ACHILLE BARILATTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.278169,43.209290 ,0],
                [13.278185,43.209312,0 ],
                [13.278541,43.210571,0 ],
                [13.278555,43.210587,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA BASSANO DEL GRAPPA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.292027,43.217041 ,0],
                [13.292162,43.216530,0 ],
                [13.292034,43.216442,0 ],
                [13.292177,43.216267,0 ],
                [13.292250,43.216190,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ARNALDO BELLUIGI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.331916,43.222404 ,0],
                [13.332510,43.221718,0 ],
                [13.332676,43.221527,0 ],
                [13.332822,43.221359,0 ],
                [13.332905,43.221298,0 ],
                [13.332989,43.221272,0 ],
                [13.333073,43.221260,0 ],
                [13.333167,43.221268,0 ],
                [13.333273,43.221298,0 ],
                [13.336165,43.222595,0 ],
                [13.336289,43.222683,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.331673,43.221050 ,0],
                [13.332676,43.221527,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA BEATO ANGELICO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.297563,43.218742 ,0],
                [13.298170,43.219090,0 ],
                [13.298346,43.218937,0 ],
                [13.297820,43.218639,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE GIOVANNI BENADDUCI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286443,43.211235 ,0],
                [13.286710,43.211243,0 ],
                [13.287216,43.211304,0 ],
                [13.287990,43.211700,0 ],
                [13.288607,43.211826,0 ],
                [13.288677,43.211842,0 ],
                [13.288870,43.211880,0 ],
                [13.290149,43.212139,0 ],
                [13.290186,43.212147,0 ],
                [13.290346,43.212181,0 ],
                [13.291196,43.212353,0 ],
                [13.291417,43.212395,0 ],
                [13.291924,43.212502,0 ],
                [13.292263,43.212456,0 ],
                [13.293662,43.212269,0 ],
                [13.293797,43.212254,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIADOTTO ENRICO BERLINGUER",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.298725,43.214703 ,0],
                [13.298758,43.214725,0 ],
                [13.298797,43.214733,0 ],
                [13.298851,43.214733,0 ],
                [13.298893,43.214714,0 ],
                [13.298933,43.214684,0 ],
                [13.299957,43.215122,0 ],
                [13.300120,43.215233,0 ],
                [13.300373,43.215424,0 ],
                [13.300589,43.215618,0 ],
                [13.300745,43.215794,0 ],
                [13.300936,43.215996,0 ],
                [13.301174,43.216164,0 ],
                [13.301354,43.216255,0 ],
                [13.301569,43.216343,0 ],
                [13.301694,43.216389,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA EMILIO ED UGO BETTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.292524,43.213593 ,0],
                [13.292602,43.213593,0 ],
                [13.293468,43.213490,0 ],
                [13.293535,43.213486,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA BEZZECCA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284077,43.212696 ,0],
                [13.284523,43.212502,0 ],
                [13.284811,43.212257,0 ],
                [13.285229,43.212124,0 ],
                [13.285266,43.212112,0 ],
                [13.285313,43.211948,0 ],
                [13.285387,43.211876,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MARCO BIAGI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.366617,43.237686 ,0],
                [13.367920,43.238289,0 ],
                [13.367155,43.239132,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA TRAIANO BOCCALINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291196,43.212353 ,0],
                [13.291311,43.212082,0 ],
                [13.291417,43.212395,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.291008,43.210640 ,0],
                [13.291076,43.210957,0 ],
                [13.291068,43.211063,0 ],
                [13.291132,43.211369,0 ],
                [13.291205,43.211678,0 ],
                [13.291311,43.212082,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PAOLO BORSELLINO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.261800,43.188797 ,0],
                [13.261919,43.188755,0 ],
                [13.264073,43.187904,0 ],
                [13.264256,43.187939,0 ],
                [13.264568,43.188335,0 ],
                [13.264595,43.188965,0 ],
                [13.262792,43.189701,0 ],
                [13.262660,43.189774,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA BRAMANTE DA URBINO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289628,43.212421 ,0],
                [13.289786,43.212570,0 ],
                [13.290008,43.212605,0 ],
                [13.290173,43.212185,0 ],
                [13.290186,43.212147,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA FRANCESCO BRANCADORI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291778,43.213348 ,0],
                [13.291823,43.213322,0 ],
                [13.292114,43.213112,0 ],
                [13.292148,43.213093,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA BRENTA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.290415,43.216290 ,0],
                [13.291158,43.215591,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA GIACOMO BRODOLINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293991,43.212360 ,0],
                [13.294632,43.211731,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE GIACOMO BRODOLINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293806,43.212307 ,0],
                [13.293956,43.212345,0 ],
                [13.293991,43.212360,0 ],
                [13.294930,43.212814,0 ],
                [13.295321,43.212997,0 ],
                [13.296074,43.213345,0 ],
                [13.296544,43.213566,0 ],
                [13.298257,43.214352,0 ],
                [13.298614,43.214516,0 ],
                [13.298742,43.214588,0 ],
                [13.298776,43.214573,0 ],
                [13.298822,43.214569,0 ],
                [13.298860,43.214577,0 ],
                [13.298890,43.214588,0 ],
                [13.298908,43.214600,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE BRUNO BUOZZI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.274988,43.204456 ,0],
                [13.275376,43.204762,0 ],
                [13.275790,43.205112,0 ],
                [13.275908,43.205223,0 ],
                [13.276065,43.205376,0 ],
                [13.276657,43.206020,0 ],
                [13.276979,43.206375,0 ],
                [13.277560,43.207073,0 ],
                [13.277592,43.207111,0 ],
                [13.277761,43.207325,0 ],
                [13.278226,43.207901,0 ],
                [13.278924,43.208771,0 ],
                [13.279023,43.208897,0 ],
                [13.279069,43.208950,0 ],
                [13.279199,43.209061,0 ],
                [13.279366,43.209167,0 ],
                [13.279553,43.209244,0 ],
                [13.279705,43.209286,0 ],
                [13.279817,43.209301,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.276065,43.205376 ,0],
                [13.275642,43.205605,0 ],
                [13.276155,43.206169,0 ],
                [13.276192,43.206219,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA LUIGI CADORNA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285555,43.206051 ,0],
                [13.285584,43.206150,0 ],
                [13.285602,43.206287,0 ],
                [13.285566,43.206482,0 ],
                [13.285575,43.206532,0 ],
                [13.285734,43.206696,0 ],
                [13.285714,43.206776,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GRANDE TORINO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.333796,43.220547 ,0],
                [13.333664,43.220757,0 ],
                [13.335215,43.221138,0 ],
                [13.335374,43.221149,0 ],
                [13.335531,43.221134,0 ],
                [13.335686,43.221073,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA LAURO CAPPELLACCI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281054,43.215031 ,0],
                [13.280645,43.214581,0 ],
                [13.280536,43.214474,0 ],
                [13.280503,43.214428,0 ],
                [13.280480,43.214298,0 ],
                [13.280492,43.214249,0 ],
                [13.280573,43.214138,0 ],
                [13.280789,43.214027,0 ],
                [13.281087,43.213898,0 ],
                [13.281798,43.213631,0 ],
                [13.282372,43.213486,0 ],
                [13.282789,43.213398,0 ],
                [13.283723,43.213242,0 ],
                [13.284142,43.213173,0 ],
                [13.284948,43.213028,0 ],
                [13.285043,43.213017,0 ],
                [13.285495,43.212978,0 ],
                [13.285723,43.212929,0 ],
                [13.285924,43.212894,0 ],
                [13.286212,43.212856,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE DEI CAPPUCCINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.279177,43.213242 ,0],
                [13.279242,43.213104,0 ],
                [13.279252,43.213081,0 ],
                [13.279407,43.212715,0 ],
                [13.279622,43.212292,0 ],
                [13.279823,43.211758,0 ],
                [13.279971,43.211292,0 ],
                [13.280095,43.210899,0 ],
                [13.280207,43.210217,0 ],
                [13.280352,43.209953,0 ],
                [13.281008,43.209419,0 ],
                [13.281095,43.209347,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA NICOLA CALIPARI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276642,43.208038 ,0],
                [13.276675,43.208027,0 ],
                [13.277202,43.207798,0 ],
                [13.277273,43.207767,0 ],
                [13.277151,43.207615,0 ],
                [13.277130,43.207588,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA AUDIO CARASSAI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280645,43.214581 ,0],
                [13.281718,43.214314,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIOSUE&#x27; CARDUCCI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.298985,43.213387 ,0],
                [13.299406,43.212818,0 ],
                [13.299638,43.212589,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SALVATORE CARNEVALE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.292940,43.212009 ,0],
                [13.292850,43.212021,0 ],
                [13.293731,43.211903,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MASSIMO D&#x27;ANTONA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.367239,43.238365 ,0],
                [13.367021,43.238594,0 ],
                [13.367121,43.238644,0 ],
                [13.367266,43.238487,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.366995,43.238777 ,0],
                [13.367121,43.238644,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.367021,43.238594 ,0],
                [13.366616,43.238400,0 ],
                [13.367039,43.237915,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA DELLE CARTIERE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289925,43.208847 ,0],
                [13.289988,43.208870,0 ],
                [13.290291,43.208969,0 ],
                [13.290763,43.209122,0 ],
                [13.290818,43.209148,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE DELLE CARTIERE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288165,43.210602 ,0],
                [13.288959,43.209984,0 ],
                [13.289058,43.209908,0 ],
                [13.289115,43.209827,0 ],
                [13.289182,43.209717,0 ],
                [13.289248,43.209587,0 ],
                [13.289283,43.209518,0 ],
                [13.289317,43.209427,0 ],
                [13.289336,43.209335,0 ],
                [13.289459,43.209183,0 ],
                [13.289573,43.209045,0 ],
                [13.289925,43.208847,0 ],
                [13.290531,43.208508,0 ],
                [13.290748,43.208412,0 ],
                [13.290909,43.208317,0 ],
                [13.291263,43.208172,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.287216,43.211304 ,0],
                [13.287316,43.211250,0 ],
                [13.287508,43.211128,0 ],
                [13.288095,43.210655,0 ],
                [13.288165,43.210598,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA IV NOVEMBRE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.273293,43.207867 ,0],
                [13.273301,43.207932,0 ],
                [13.273335,43.208000,0 ],
                [13.273756,43.208515,0 ],
                [13.273932,43.208519,0 ],
                [13.274038,43.208481,0 ],
                [13.273992,43.208424,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CASTELLO DI VARANO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.279762,43.213287 ,0],
                [13.279774,43.213322,0 ],
                [13.279910,43.213665,0 ],
                [13.279977,43.213779,0 ],
                [13.280065,43.213898,0 ],
                [13.280105,43.213928,0 ],
                [13.280258,43.213951,0 ],
                [13.280332,43.213970,0 ],
                [13.280375,43.213989,0 ],
                [13.280267,43.214046,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE CEGNA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284716,43.214741 ,0],
                [13.284699,43.214664,0 ],
                [13.284661,43.214592,0 ],
                [13.284602,43.214539,0 ],
                [13.284513,43.214493,0 ],
                [13.284396,43.214451,0 ],
                [13.283484,43.214264,0 ],
                [13.283395,43.214195,0 ],
                [13.283345,43.214104,0 ],
                [13.283344,43.214039,0 ],
                [13.283375,43.213974,0 ],
                [13.283496,43.213902,0 ],
                [13.283643,43.213848,0 ],
                [13.283790,43.213802,0 ],
                [13.283987,43.213783,0 ],
                [13.284154,43.213799,0 ],
                [13.284585,43.213860,0 ],
                [13.284756,43.213879,0 ],
                [13.285014,43.213875,0 ],
                [13.285455,43.213852,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CENGIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.297468,43.220047 ,0],
                [13.297356,43.220181,0 ],
                [13.297310,43.220261,0 ],
                [13.297280,43.220341,0 ],
                [13.297265,43.220413,0 ],
                [13.297276,43.220493,0 ],
                [13.297314,43.220573,0 ],
                [13.297501,43.220821,0 ],
                [13.297605,43.220955,0 ],
                [13.297744,43.221111,0 ],
                [13.297823,43.221188,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ROMOLO CERINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.303082,43.217392 ,0],
                [13.303131,43.217232,0 ],
                [13.303066,43.217117,0 ],
                [13.303329,43.217030,0 ],
                [13.303429,43.216743,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.302649,43.217266 ,0],
                [13.303066,43.217117,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA LUIGI CERQUETTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.287519,43.216064 ,0],
                [13.287520,43.216114,0 ],
                [13.287946,43.216660,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA FRATELLI CERVI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.273131,43.205036 ,0],
                [13.273045,43.205338,0 ],
                [13.274179,43.205692,0 ],
                [13.274227,43.205708,0 ],
                [13.274716,43.205872,0 ],
                [13.274814,43.205917,0 ],
                [13.274873,43.205963,0 ],
                [13.274951,43.206039,0 ],
                [13.275212,43.206345,0 ],
                [13.275957,43.206257,0 ],
                [13.276192,43.206219,0 ],
                [13.276278,43.206200,0 ],
                [13.276307,43.206196,0 ],
                [13.276608,43.206043,0 ],
                [13.276657,43.206020,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DAMIANO CHIESA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293861,43.216354 ,0],
                [13.293892,43.216328,0 ],
                [13.294538,43.215691,0 ],
                [13.294913,43.216232,0 ],
                [13.295094,43.216347,0 ],
                [13.295135,43.216370,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA NICOLA CIARAPICA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.294151,43.213688 ,0],
                [13.296074,43.213345,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA IDEALE CIARAPICA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291798,43.214401 ,0],
                [13.291836,43.214363,0 ],
                [13.291996,43.214184,0 ],
                [13.292377,43.213760,0 ],
                [13.292506,43.213619,0 ],
                [13.292524,43.213593,0 ],
                [13.292557,43.213543,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE DEL CARMELO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.277874,43.215866 ,0],
                [13.277871,43.215866,0 ],
                [13.277780,43.215748,0 ],
                [13.277684,43.215599,0 ],
                [13.277679,43.215511,0 ],
                [13.277705,43.215435,0 ],
                [13.277732,43.215408,0 ],
                [13.278259,43.214882,0 ],
                [13.278652,43.214268,0 ],
                [13.278745,43.214123,0 ],
                [13.279177,43.213242,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA COL DI LANA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282392,43.214783 ,0],
                [13.282397,43.214710,0 ],
                [13.282462,43.214184,0 ],
                [13.282470,43.214123,0 ],
                [13.282498,43.214054,0 ],
                [13.282552,43.213985,0 ],
                [13.282621,43.213890,0 ],
                [13.282674,43.213791,0 ],
                [13.282764,43.213737,0 ],
                [13.282905,43.213699,0 ],
                [13.284104,43.213432,0 ],
                [13.284148,43.213253,0 ],
                [13.284142,43.213173,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA TULLIO COLSALVATICO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.302028,43.213703 ,0],
                [13.301985,43.213371,0 ],
                [13.302002,43.213352,0 ],
                [13.302530,43.213379,0 ],
                [13.302773,43.213409,0 ],
                [13.303065,43.213470,0 ],
                [13.303818,43.213692,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CRISTOFORO COLOMBO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.322008,43.219723 ,0],
                [13.320626,43.219429,0 ],
                [13.320508,43.219383,0 ],
                [13.320443,43.219330,0 ],
                [13.320416,43.219265,0 ],
                [13.320432,43.219181,0 ],
                [13.320878,43.218060,0 ],
                [13.322789,43.218452,0 ],
                [13.324190,43.218746,0 ],
                [13.325850,43.219090,0 ],
                [13.327493,43.219410,0 ],
                [13.328069,43.219563,0 ],
                [13.328814,43.219723,0 ],
                [13.329184,43.219772,0 ],
                [13.329561,43.219788,0 ],
                [13.329950,43.219769,0 ],
                [13.330289,43.219723,0 ],
                [13.330585,43.219669,0 ],
                [13.331270,43.219513,0 ],
                [13.331636,43.219456,0 ],
                [13.332060,43.219425,0 ],
                [13.332436,43.219425,0 ],
                [13.332854,43.219467,0 ],
                [13.333274,43.219540,0 ],
                [13.333614,43.219627,0 ],
                [13.333916,43.219738,0 ],
                [13.334217,43.219868,0 ],
                [13.334526,43.220028,0 ],
                [13.334785,43.220200,0 ],
                [13.335022,43.220398,0 ],
                [13.335224,43.220608,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.311179,43.217293 ,0],
                [13.311460,43.217087,0 ],
                [13.312516,43.216537,0 ],
                [13.312666,43.216484,0 ],
                [13.312840,43.216446,0 ],
                [13.313021,43.216442,0 ],
                [13.313179,43.216457,0 ],
                [13.319431,43.217762,0 ],
                [13.320878,43.218060,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DELLE CONCE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281702,43.208374 ,0],
                [13.281724,43.208408,0 ],
                [13.281732,43.208427,0 ],
                [13.281744,43.208473,0 ],
                [13.281748,43.208508,0 ],
                [13.281741,43.208546,0 ],
                [13.281701,43.208603,0 ],
                [13.281632,43.208683,0 ],
                [13.281647,43.208710,0 ],
                [13.281676,43.208721,0 ],
                [13.282034,43.208614,0 ],
                [13.282182,43.208576,0 ],
                [13.282249,43.208576,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA BENEDETTO CROCE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276283,43.211308 ,0],
                [13.276427,43.211422,0 ],
                [13.276484,43.211445,0 ],
                [13.276567,43.211426,0 ],
                [13.276709,43.211254,0 ],
                [13.276761,43.211212,0 ],
                [13.277119,43.211140,0 ],
                [13.277418,43.211086,0 ],
                [13.277808,43.211098,0 ],
                [13.277823,43.211235,0 ],
                [13.277857,43.211285,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SALVO D&#x27;ACQUISTO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293690,43.211010 ,0],
                [13.293614,43.210503,0 ],
                [13.293667,43.210407,0 ],
                [13.293862,43.210365,0 ],
                [13.294600,43.210396,0 ],
                [13.295068,43.210464,0 ],
                [13.294827,43.211014,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CARLO ALBERTO DALLA CHIESA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.267385,43.191467 ,0],
                [13.267474,43.191437,0 ],
                [13.268075,43.191250,0 ],
                [13.268347,43.192776,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ALCIDE DE GASPERI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.296306,43.214661 ,0],
                [13.296308,43.214787,0 ],
                [13.296373,43.215374,0 ],
                [13.296864,43.214939,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.295394,43.216228 ,0],
                [13.295440,43.216206,0 ],
                [13.296249,43.215485,0 ],
                [13.296373,43.215374,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ARMANDO DIAZ",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.280786,43.208836 ,0],
                [13.280814,43.208813,0 ],
                [13.280907,43.208740,0 ],
                [13.281108,43.208591,0 ],
                [13.281168,43.208370,0 ],
                [13.281172,43.208351,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE DI VITTORIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.275305,43.209023 ,0],
                [13.275326,43.209011,0 ],
                [13.276585,43.208317,0 ],
                [13.276609,43.208294,0 ],
                [13.276629,43.208275,0 ],
                [13.276648,43.208244,0 ],
                [13.276642,43.208038,0 ],
                [13.276645,43.207989,0 ],
                [13.276525,43.207844,0 ],
                [13.277130,43.207588,0 ],
                [13.277656,43.207367,0 ],
                [13.277761,43.207325,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE DELLA CONCORDIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.302152,43.216507 ,0],
                [13.302341,43.216476,0 ],
                [13.303664,43.216263,0 ],
                [13.304055,43.216251,0 ],
                [13.304472,43.216309,0 ],
                [13.304897,43.216457,0 ],
                [13.307214,43.217484,0 ],
                [13.307301,43.217522,0 ],
                [13.308253,43.217941,0 ],
                [13.308403,43.218006,0 ],
                [13.309762,43.218609,0 ],
                [13.309987,43.218704,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE DELLA FRATERNITA&#x27;",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.309457,43.219337 ,0],
                [13.309987,43.218704,0 ],
                [13.311083,43.217400,0 ],
                [13.311179,43.217293,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA JAN PALACH",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.304643,43.218090 ,0],
                [13.304977,43.217686,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA 8 MARZO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.302780,43.217468 ,0],
                [13.304617,43.217541,0 ],
                [13.304977,43.217686,0 ],
                [13.305922,43.218102,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DELLA SOLIDARIETA&#x27;",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.307214,43.217484 ,0],
                [13.307292,43.217358,0 ],
                [13.308251,43.216183,0 ],
                [13.308620,43.215729,0 ],
                [13.308756,43.215572,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "LARGO &#x27;815",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.308403,43.218006 ,0],
                [13.308711,43.218216,0 ],
                [13.308473,43.218494,0 ],
                [13.308019,43.218300,0 ],
                [13.307952,43.218369,0 ],
                [13.309502,43.219017,0 ],
                [13.309553,43.218960,0 ],
                [13.308967,43.218697,0 ],
                [13.309110,43.218536,0 ],
                [13.309213,43.218430,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA EMERAINVILLE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293689,43.213856 ,0],
                [13.293636,43.213890,0 ],
                [13.293418,43.214096,0 ],
                [13.293338,43.214214,0 ],
                [13.293770,43.214855,0 ],
                [13.293909,43.214981,0 ],
                [13.294036,43.214935,0 ],
                [13.294249,43.214748,0 ],
                [13.294311,43.214703,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZALE EUROPA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286443,43.211235 ,0],
                [13.286382,43.211273,0 ],
                [13.285974,43.211525,0 ],
                [13.285387,43.211876,0 ],
                [13.285807,43.212334,0 ],
                [13.286869,43.211689,0 ],
                [13.286955,43.211639,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIOVANNI FALCONE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.254749,43.183487 ,0],
                [13.254734,43.183685,0 ],
                [13.254809,43.183884,0 ],
                [13.254974,43.184105,0 ],
                [13.255025,43.184391,0 ],
                [13.254881,43.184887,0 ],
                [13.254893,43.185719,0 ],
                [13.255043,43.186104,0 ],
                [13.255290,43.186455,0 ],
                [13.255718,43.186855,0 ],
                [13.255999,43.187237,0 ],
                [13.256224,43.187977,0 ],
                [13.256602,43.188419,0 ],
                [13.259490,43.191055,0 ],
                [13.259533,43.191109,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA FRANCESCO FERRANTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288410,43.212273 ,0],
                [13.288548,43.212368,0 ],
                [13.288831,43.212147,0 ],
                [13.288671,43.211941,0 ],
                [13.288664,43.211876,0 ],
                [13.288677,43.211842,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MANLIO FERRARIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276047,43.209240 ,0],
                [13.276059,43.209229,0 ],
                [13.277062,43.208622,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SALVATORE FICILI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.335484,43.223492 ,0],
                [13.335339,43.223682,0 ],
                [13.335366,43.223763,0 ],
                [13.336145,43.224117,0 ],
                [13.336658,43.223545,0 ],
                [13.336321,43.223389,0 ],
                [13.336080,43.223656,0 ],
                [13.335580,43.223438,0 ],
                [13.335497,43.223354,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE FABIO FILZI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281666,43.209015 ,0],
                [13.281704,43.208950,0 ],
                [13.281754,43.208897,0 ],
                [13.282195,43.208618,0 ],
                [13.282249,43.208576,0 ],
                [13.282638,43.208305,0 ],
                [13.283057,43.207947,0 ],
                [13.283707,43.207375,0 ],
                [13.284013,43.207180,0 ],
                [13.284582,43.206902,0 ],
                [13.285280,43.206764,0 ],
                [13.285714,43.206776,0 ],
                [13.285864,43.206764,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA FLAMINIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289791,43.209766 ,0],
                [13.289817,43.209728,0 ],
                [13.290037,43.209370,0 ],
                [13.290291,43.208969,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA FLAMINIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286968,43.209175 ,0],
                [13.287076,43.209137,0 ],
                [13.287223,43.209106,0 ],
                [13.287666,43.209034,0 ],
                [13.287861,43.209011,0 ],
                [13.287904,43.209015,0 ],
                [13.287951,43.209023,0 ],
                [13.288052,43.209091,0 ],
                [13.288796,43.209404,0 ],
                [13.289157,43.209557,0 ],
                [13.289248,43.209587,0 ],
                [13.289416,43.209637,0 ],
                [13.289628,43.209721,0 ],
                [13.289791,43.209766,0 ],
                [13.290497,43.209972,0 ],
                [13.291225,43.210121,0 ],
                [13.291770,43.210232,0 ],
                [13.292065,43.210289,0 ],
                [13.292228,43.210312,0 ],
                [13.292397,43.210316,0 ],
                [13.293015,43.210239,0 ],
                [13.293108,43.210243,0 ],
                [13.293142,43.210251,0 ],
                [13.293335,43.210308,0 ],
                [13.293390,43.210335,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CARLO FORLANINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276237,43.207981 ,0],
                [13.276629,43.208275,0 ],
                [13.277076,43.208633,0 ],
                [13.277604,43.208889,0 ],
                [13.277853,43.209023,0 ],
                [13.278136,43.209267,0 ],
                [13.278169,43.209290,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.275541,43.206905 ,0],
                [13.275521,43.207127,0 ],
                [13.275529,43.207165,0 ],
                [13.275975,43.207703,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "GALLERIA FORNACE MASSI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291339,43.213680 ,0],
                [13.291386,43.213642,0 ],
                [13.291725,43.213383,0 ],
                [13.291778,43.213348,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DELLE FORNACI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291142,43.213528 ,0],
                [13.290708,43.213886,0 ],
                [13.291620,43.214546,0 ],
                [13.292026,43.214836,0 ],
                [13.292227,43.214981,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.290436,43.214108 ,0],
                [13.290708,43.213886,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE FORO BOARIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.287795,43.207829 ,0],
                [13.287355,43.207424,0 ],
                [13.287047,43.207134,0 ],
                [13.286710,43.206875,0 ],
                [13.286817,43.206856,0 ],
                [13.286973,43.206779,0 ],
                [13.287320,43.206547,0 ],
                [13.287365,43.206535,0 ],
                [13.288273,43.207375,0 ],
                [13.288315,43.207439,0 ],
                [13.288307,43.207504,0 ],
                [13.288275,43.207573,0 ],
                [13.287858,43.207817,0 ],
                [13.287795,43.207829,0 ],
                [13.287834,43.207863,0 ],
                [13.288547,43.208511,0 ],
                [13.288833,43.208775,0 ],
                [13.289285,43.209206,0 ],
                [13.289323,43.209259,0 ],
                [13.289336,43.209335,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.285956,43.206680 ,0],
                [13.286087,43.206646,0 ],
                [13.286208,43.206650,0 ],
                [13.286312,43.206661,0 ],
                [13.286469,43.206718,0 ],
                [13.286598,43.206787,0 ],
                [13.286710,43.206875,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA LUIGI FRANCESCONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.334903,43.223789 ,0],
                [13.335191,43.223480,0 ],
                [13.335497,43.223354,0 ],
                [13.335666,43.223282,0 ],
                [13.335731,43.223221,0 ],
                [13.336127,43.222782,0 ],
                [13.336289,43.222683,0 ],
                [13.336721,43.222630,0 ],
                [13.337051,43.222580,0 ],
                [13.337137,43.222569,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PADRE NICOLA FUSCONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.274151,43.215000 ,0],
                [13.275474,43.215103,0 ],
                [13.275742,43.215149,0 ],
                [13.276329,43.215328,0 ],
                [13.276563,43.215378,0 ],
                [13.276799,43.215385,0 ],
                [13.277532,43.215382,0 ],
                [13.277677,43.215393,0 ],
                [13.277732,43.215408,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA NAZARENO GABRIELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.290345,43.211132 ,0],
                [13.289882,43.211037,0 ],
                [13.290006,43.210907,0 ],
                [13.290922,43.210979,0 ],
                [13.290985,43.211266,0 ],
                [13.290465,43.211159,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PADRE DOMENICO GENTILI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.274550,43.209049 ,0],
                [13.274447,43.208939,0 ],
                [13.274709,43.208805,0 ],
                [13.274769,43.208817,0 ],
                [13.275123,43.208958,0 ],
                [13.275212,43.208965,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ARISTIDE GENTILONI SILVERJ",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276556,43.209393 ,0],
                [13.276557,43.209400,0 ],
                [13.276554,43.209415,0 ],
                [13.276549,43.209423,0 ],
                [13.276546,43.209438,0 ],
                [13.276547,43.209438,0 ],
                [13.276614,43.209419,0 ],
                [13.276793,43.209408,0 ],
                [13.276932,43.209415,0 ],
                [13.276984,43.209419,0 ],
                [13.277409,43.209465,0 ],
                [13.277501,43.209465,0 ],
                [13.277599,43.209461,0 ],
                [13.277946,43.209408,0 ],
                [13.278169,43.209290,0 ],
                [13.278202,43.209274,0 ],
                [13.278490,43.209103,0 ],
                [13.278598,43.209049,0 ],
                [13.278994,43.208904,0 ],
                [13.279023,43.208897,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.275773,43.209724 ,0],
                [13.276138,43.209576,0 ],
                [13.276175,43.209564,0 ],
                [13.276546,43.209438,0 ],
                [13.276514,43.209507,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ARDUINO GERMONDANI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288165,43.210602 ,0],
                [13.288563,43.210804,0 ],
                [13.289371,43.211216,0 ],
                [13.289473,43.211269,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZALE GIUSEPPE TUCCI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289571,43.211067 ,0],
                [13.289479,43.211159,0 ],
                [13.289454,43.211147,0 ],
                [13.289310,43.211079,0 ],
                [13.289530,43.210854,0 ],
                [13.289690,43.210938,0 ],
                [13.289590,43.211040,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE GIOVANNI XXIII",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293570,43.211033 ,0],
                [13.293657,43.211014,0 ],
                [13.293690,43.211010,0 ],
                [13.294350,43.210949,0 ],
                [13.294419,43.210945,0 ],
                [13.294827,43.211014,0 ],
                [13.295317,43.211102,0 ],
                [13.297529,43.212273,0 ],
                [13.298027,43.212536,0 ],
                [13.298146,43.212643,0 ],
                [13.298233,43.212749,0 ],
                [13.298766,43.213825,0 ],
                [13.298939,43.214005,0 ],
                [13.299495,43.214275,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZALE CESARE ANGELETTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291620,43.214546 ,0],
                [13.291677,43.214508,0 ],
                [13.291798,43.214401,0 ],
                [13.292185,43.214684,0 ],
                [13.292068,43.214802,0 ],
                [13.292026,43.214836,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GORIZIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288647,43.215061 ,0],
                [13.289238,43.214512,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ACHILLE GRANDI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.275006,43.208588 ,0],
                [13.275096,43.208557,0 ],
                [13.275814,43.208229,0 ],
                [13.276136,43.208038,0 ],
                [13.276237,43.207981,0 ],
                [13.275975,43.207703,0 ],
                [13.276167,43.207607,0 ],
                [13.276888,43.207443,0 ],
                [13.277098,43.207352,0 ],
                [13.277504,43.207153,0 ],
                [13.277592,43.207111,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MANFREDI GRAVINA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285221,43.212475 ,0],
                [13.285329,43.212429,0 ],
                [13.285245,43.212196,0 ],
                [13.285229,43.212124,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ROBERTO GULLINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285995,43.206573 ,0],
                [13.286088,43.206577,0 ],
                [13.286295,43.206585,0 ],
                [13.286390,43.206573,0 ],
                [13.286516,43.206520,0 ],
                [13.286713,43.206337,0 ],
                [13.286744,43.206276,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE GURRIERI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.332681,43.221806 ,0],
                [13.332345,43.222206,0 ],
                [13.332338,43.222317,0 ],
                [13.332425,43.222439,0 ],
                [13.334819,43.223419,0 ],
                [13.334948,43.223335,0 ],
                [13.335264,43.223221,0 ],
                [13.335387,43.223209,0 ],
                [13.335438,43.223270,0 ],
                [13.335497,43.223354,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE IMPASTATO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.258520,43.182396 ,0],
                [13.257733,43.182991,0 ],
                [13.257926,43.183170,0 ],
                [13.259663,43.183311,0 ],
                [13.260114,43.182693,0 ],
                [13.258707,43.182423,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA INDIPENDENZA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.294697,43.216785 ,0],
                [13.295135,43.216370,0 ],
                [13.295326,43.216194,0 ],
                [13.295358,43.216175,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PARCO ISOLA D&#x27;ISTRIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293324,43.215549 ,0],
                [13.293844,43.215836,0 ],
                [13.294294,43.215385,0 ],
                [13.294036,43.215115,0 ],
                [13.293881,43.215080,0 ],
                [13.293567,43.215275,0 ],
                [13.293336,43.215492,0 ],
                [13.292311,43.214874,0 ],
                [13.293009,43.214245,0 ],
                [13.293142,43.214306,0 ],
                [13.293526,43.214855,0 ],
                [13.293806,43.215096,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ISONZO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.290915,43.217800 ,0],
                [13.290926,43.217739,0 ],
                [13.291098,43.217045,0 ],
                [13.291109,43.216999,0 ],
                [13.291117,43.216969,0 ],
                [13.291128,43.216919,0 ],
                [13.291427,43.215897,0 ],
                [13.291457,43.215843,0 ],
                [13.291505,43.215790,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA JOHN E ROBERT KENNEDY",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.296429,43.217010 ,0],
                [13.297339,43.217560,0 ],
                [13.297520,43.217617,0 ],
                [13.297677,43.217648,0 ],
                [13.297724,43.217655,0 ],
                [13.297983,43.217617,0 ],
                [13.298153,43.217522,0 ],
                [13.298456,43.217007,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MARTIN LUTHER KING",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.295946,43.217243 ,0],
                [13.295991,43.217228,0 ],
                [13.296022,43.217205,0 ],
                [13.296038,43.217182,0 ],
                [13.296041,43.217136,0 ],
                [13.296170,43.217110,0 ],
                [13.296429,43.217010,0 ],
                [13.296537,43.216961,0 ],
                [13.297381,43.216167,0 ],
                [13.297624,43.215923,0 ],
                [13.297933,43.215576,0 ],
                [13.298040,43.215450,0 ],
                [13.298604,43.214813,0 ],
                [13.298725,43.214703,0 ],
                [13.298700,43.214680,0 ],
                [13.298695,43.214642,0 ],
                [13.298711,43.214607,0 ],
                [13.298742,43.214588,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIORGIO LA PIRA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.301590,43.218166 ,0],
                [13.301588,43.218010,0 ],
                [13.301591,43.217926,0 ],
                [13.301501,43.217430,0 ],
                [13.301471,43.217113,0 ],
                [13.301475,43.216988,0 ],
                [13.301476,43.216904,0 ],
                [13.301529,43.216694,0 ],
                [13.301610,43.216518,0 ],
                [13.301694,43.216389,0 ],
                [13.301849,43.216419,0 ],
                [13.302100,43.216431,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE LABASTIDE MURAT",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.295904,43.217075 ,0],
                [13.295864,43.217087,0 ],
                [13.295832,43.217113,0 ],
                [13.295819,43.217148,0 ],
                [13.295822,43.217178,0 ],
                [13.295841,43.217201,0 ],
                [13.295863,43.217220,0 ],
                [13.295898,43.217236,0 ],
                [13.295946,43.217243,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.290958,43.214607 ,0],
                [13.291214,43.214874,0 ],
                [13.291939,43.215298,0 ],
                [13.292946,43.215866,0 ],
                [13.293861,43.216354,0 ],
                [13.294448,43.216679,0 ],
                [13.294697,43.216785,0 ],
                [13.295020,43.216934,0 ],
                [13.295480,43.217117,0 ],
                [13.295637,43.217171,0 ],
                [13.295753,43.217182,0 ],
                [13.295822,43.217178,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA UGO LA MALFA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.298040,43.215450 ,0],
                [13.298142,43.215515,0 ],
                [13.298710,43.215767,0 ],
                [13.299187,43.215919,0 ],
                [13.299038,43.216167,0 ],
                [13.298223,43.215855,0 ],
                [13.298345,43.215717,0 ],
                [13.298651,43.215851,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA EMANUELE LENA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.277501,43.209465 ,0],
                [13.277806,43.211075,0 ],
                [13.277808,43.211098,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA LUCIANO LAMA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.275276,43.209011 ,0],
                [13.275297,43.209137,0 ],
                [13.275773,43.209724,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIACOMO LEOPARDI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.290697,43.213188 ,0],
                [13.290726,43.213211,0 ],
                [13.291142,43.213528,0 ],
                [13.291339,43.213680,0 ],
                [13.291946,43.214142,0 ],
                [13.291996,43.214184,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ARNALDO LUCENTINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291196,43.212353 ,0],
                [13.291137,43.212471,0 ],
                [13.290978,43.212681,0 ],
                [13.290687,43.213047,0 ],
                [13.290632,43.213203,0 ],
                [13.290697,43.213188,0 ],
                [13.290856,43.213150,0 ],
                [13.291045,43.213009,0 ],
                [13.291085,43.212955,0 ],
                [13.291120,43.212868,0 ],
                [13.291279,43.212521,0 ],
                [13.291345,43.212456,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.289936,43.213749 ,0],
                [13.290005,43.213696,0 ],
                [13.290632,43.213203,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.291345,43.212456 ,0],
                [13.291417,43.212395,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA UMBERTO LUCENTINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.271480,43.207237 ,0],
                [13.271870,43.206879,0 ],
                [13.271948,43.206833,0 ],
                [13.272053,43.206814,0 ],
                [13.272141,43.206833,0 ],
                [13.272923,43.207218,0 ],
                [13.273889,43.207634,0 ],
                [13.273989,43.207691,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA LINO LIVIABELLA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.327356,43.222378 ,0],
                [13.327742,43.221252,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CADUTI DI NASSIRIYA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.290818,43.209148 ,0],
                [13.291624,43.209423,0 ],
                [13.291763,43.209213,0 ],
                [13.292359,43.208324,0 ],
                [13.292724,43.208157,0 ],
                [13.294848,43.209091,0 ],
                [13.294968,43.209194,0 ],
                [13.295004,43.209316,0 ],
                [13.295007,43.209480,0 ],
                [13.294866,43.209976,0 ],
                [13.294856,43.210049,0 ],
                [13.294926,43.210114,0 ],
                [13.295453,43.210365,0 ],
                [13.295662,43.210518,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CADUTI SUL LAVORO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.273784,43.204926 ,0],
                [13.274222,43.204720,0 ],
                [13.274327,43.204678,0 ],
                [13.274466,43.204670,0 ],
                [13.274542,43.204647,0 ],
                [13.274957,43.204479,0 ],
                [13.274988,43.204456,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MADRE TERESA DI CALCUTTA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.255219,43.183353 ,0],
                [13.256404,43.183720,0 ],
                [13.257837,43.184010,0 ],
                [13.258886,43.184093,0 ],
                [13.259127,43.184143,0 ],
                [13.259472,43.184299,0 ],
                [13.259772,43.184475,0 ],
                [13.262196,43.186161,0 ],
                [13.262356,43.186260,0 ],
                [13.262504,43.186352,0 ],
                [13.262782,43.186501,0 ],
                [13.263623,43.186947,0 ],
                [13.263916,43.187061,0 ],
                [13.264209,43.187119,0 ],
                [13.264562,43.187180,0 ],
                [13.264802,43.187248,0 ],
                [13.264990,43.187408,0 ],
                [13.266503,43.189632,0 ],
                [13.266797,43.190067,0 ],
                [13.267105,43.190533,0 ],
                [13.267220,43.190704,0 ],
                [13.267385,43.191467,0 ],
                [13.267406,43.191559,0 ],
                [13.267531,43.192493,0 ],
                [13.267517,43.192646,0 ],
                [13.267323,43.192909,0 ],
                [13.267145,43.193069,0 ],
                [13.266967,43.193295,0 ],
                [13.266878,43.193592,0 ],
                [13.266903,43.193851,0 ],
                [13.267010,43.194138,0 ],
                [13.267131,43.194386,0 ],
                [13.267297,43.194588,0 ],
                [13.267568,43.194756,0 ],
                [13.268056,43.194931,0 ],
                [13.268372,43.195084,0 ],
                [13.268710,43.195339,0 ],
                [13.268936,43.195591,0 ],
                [13.269066,43.195843,0 ],
                [13.269287,43.197830,0 ],
                [13.269644,43.199703,0 ],
                [13.269750,43.199902,0 ],
                [13.269909,43.200104,0 ],
                [13.270263,43.200405,0 ],
                [13.270596,43.200703,0 ],
                [13.270751,43.200878,0 ],
                [13.271246,43.201641,0 ],
                [13.271739,43.202198,0 ],
                [13.272412,43.202667,0 ],
                [13.273053,43.202957,0 ],
                [13.273376,43.203159,0 ],
                [13.274939,43.204422,0 ],
                [13.274988,43.204456,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GOFFREDO MAMELI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.297677,43.217648 ,0],
                [13.297649,43.217804,0 ],
                [13.297698,43.217850,0 ],
                [13.298110,43.217964,0 ],
                [13.298374,43.218025,0 ],
                [13.299788,43.218220,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MAESTRI DEL LAVORO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.317903,43.220142 ,0],
                [13.319367,43.217930,0 ],
                [13.319431,43.217762,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA LUCIANO MANARA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.278652,43.214268 ,0],
                [13.278693,43.214275,0 ],
                [13.279256,43.214500,0 ],
                [13.279407,43.214619,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ALESSANDRO MANZONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.300729,43.213512 ,0],
                [13.300966,43.213169,0 ],
                [13.301033,43.213001,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE MARI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.294951,43.218906 ,0],
                [13.295440,43.219223,0 ],
                [13.296383,43.219887,0 ],
                [13.296757,43.219646,0 ],
                [13.297149,43.219383,0 ],
                [13.297233,43.219284,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA GUGLIELMO MARCONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.290958,43.214607 ,0],
                [13.290946,43.214470,0 ],
                [13.290585,43.214207,0 ],
                [13.290537,43.214336,0 ],
                [13.290866,43.214523,0 ],
                [13.290958,43.214607,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PIERSANTI MATTARELLA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.267105,43.190533 ,0],
                [13.267205,43.190487,0 ],
                [13.268388,43.189960,0 ],
                [13.268750,43.189899,0 ],
                [13.269815,43.189968,0 ],
                [13.270209,43.189877,0 ],
                [13.271342,43.189240,0 ],
                [13.271764,43.189163,0 ],
                [13.273528,43.189362,0 ],
                [13.273708,43.189285,0 ],
                [13.274241,43.188938,0 ],
                [13.274485,43.188667,0 ],
                [13.274771,43.187996,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ENRICO MATTEI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.303586,43.218174 ,0],
                [13.303380,43.218159,0 ],
                [13.303271,43.218121,0 ],
                [13.303199,43.218071,0 ],
                [13.303144,43.218002,0 ],
                [13.303016,43.217815,0 ],
                [13.302780,43.217468,0 ],
                [13.302649,43.217266,0 ],
                [13.302505,43.217049,0 ],
                [13.302152,43.216507,0 ],
                [13.302100,43.216431,0 ],
                [13.302079,43.216362,0 ],
                [13.302123,43.216309,0 ],
                [13.302393,43.216160,0 ],
                [13.302518,43.216106,0 ],
                [13.302828,43.216026,0 ],
                [13.303046,43.215916,0 ],
                [13.303353,43.215710,0 ],
                [13.303477,43.215580,0 ],
                [13.303557,43.215523,0 ],
                [13.303888,43.215397,0 ],
                [13.303970,43.215343,0 ],
                [13.304019,43.215282,0 ],
                [13.304323,43.214813,0 ],
                [13.304338,43.214725,0 ],
                [13.304307,43.214649,0 ],
                [13.304074,43.214458,0 ],
                [13.303988,43.214378,0 ],
                [13.303895,43.214272,0 ],
                [13.303849,43.214169,0 ],
                [13.303835,43.214062,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.302357,43.217793 ,0],
                [13.303016,43.217815,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE GIACOMO MATTEOTTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286443,43.211235 ,0],
                [13.286609,43.211395,0 ],
                [13.286955,43.211639,0 ],
                [13.289936,43.213749,0 ],
                [13.290436,43.214108,0 ],
                [13.290585,43.214207,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MARIO MATTOLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.294029,43.213333 ,0],
                [13.294426,43.213264,0 ],
                [13.294543,43.213238,0 ],
                [13.294613,43.213173,0 ],
                [13.294930,43.212814,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DON GIOVANNI MINZONI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289668,43.211067 ,0],
                [13.291132,43.211369,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MONTEGRAPPA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285736,43.214226 ,0],
                [13.285798,43.214188,0 ],
                [13.286186,43.213757,0 ],
                [13.286529,43.213383,0 ],
                [13.286693,43.213207,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MONTELLO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288414,43.216530 ,0],
                [13.288465,43.216484,0 ],
                [13.289013,43.215965,0 ],
                [13.289044,43.215939,0 ],
                [13.289068,43.215916,0 ],
                [13.289477,43.215534,0 ],
                [13.290043,43.215008,0 ],
                [13.290073,43.214977,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ALDO MORO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.296249,43.215485 ,0],
                [13.296285,43.215504,0 ],
                [13.296847,43.215847,0 ],
                [13.297381,43.216167,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE GIOACCHINO MURAT",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285864,43.206764 ,0],
                [13.286058,43.206890,0 ],
                [13.286447,43.207069,0 ],
                [13.287227,43.207645,0 ],
                [13.287333,43.207764,0 ],
                [13.287392,43.207878,0 ],
                [13.287489,43.208351,0 ],
                [13.287571,43.208511,0 ],
                [13.287736,43.208755,0 ],
                [13.287852,43.208916,0 ],
                [13.287863,43.208969,0 ],
                [13.287861,43.209011,0 ],
                [13.287868,43.209084,0 ],
                [13.287941,43.209152,0 ],
                [13.288715,43.209583,0 ],
                [13.288731,43.209641,0 ],
                [13.288678,43.209682,0 ],
                [13.288589,43.209690,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA NAZIONALE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288589,43.209690 ,0],
                [13.288981,43.209930,0 ],
                [13.289022,43.209953,0 ],
                [13.289881,43.210464,0 ],
                [13.290050,43.210537,0 ],
                [13.290242,43.210594,0 ],
                [13.290434,43.210621,0 ],
                [13.290664,43.210644,0 ],
                [13.290877,43.210648,0 ],
                [13.291008,43.210640,0 ],
                [13.291094,43.210632,0 ],
                [13.292051,43.210510,0 ],
                [13.293236,43.210346,0 ],
                [13.293390,43.210335,0 ],
                [13.293440,43.210327,0 ],
                [13.294016,43.210278,0 ],
                [13.294586,43.210304,0 ],
                [13.295133,43.210381,0 ],
                [13.296532,43.210979,0 ],
                [13.297892,43.211666,0 ],
                [13.299638,43.212589,0 ],
                [13.300135,43.212849,0 ],
                [13.300193,43.212879,0 ],
                [13.300274,43.212898,0 ],
                [13.300772,43.212997,0 ],
                [13.301033,43.213001,0 ],
                [13.301876,43.212975,0 ],
                [13.302343,43.212990,0 ],
                [13.302986,43.213062,0 ],
                [13.304971,43.213470,0 ],
                [13.305264,43.213612,0 ],
                [13.305732,43.213913,0 ],
                [13.305857,43.213902,0 ],
                [13.305927,43.213921,0 ],
                [13.305978,43.213951,0 ],
                [13.306005,43.213982,0 ],
                [13.306023,43.214012,0 ],
                [13.306038,43.214054,0 ],
                [13.306056,43.214111,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PIETRO NENNI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.305732,43.213913 ,0],
                [13.305691,43.213940,0 ],
                [13.305673,43.213963,0 ],
                [13.305661,43.214001,0 ],
                [13.305662,43.214046,0 ],
                [13.305671,43.214088,0 ],
                [13.305700,43.214146,0 ],
                [13.305802,43.214180,0 ],
                [13.305856,43.214188,0 ],
                [13.305938,43.214184,0 ],
                [13.305997,43.214169,0 ],
                [13.306056,43.214111,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.298933,43.214684 ,0],
                [13.298943,43.214653,0 ],
                [13.298930,43.214619,0 ],
                [13.298908,43.214600,0 ],
                [13.299055,43.214493,0 ],
                [13.299315,43.214348,0 ],
                [13.299495,43.214275,0 ],
                [13.299666,43.214203,0 ],
                [13.300124,43.214100,0 ],
                [13.301343,43.213818,0 ],
                [13.301957,43.213711,0 ],
                [13.302028,43.213703,0 ],
                [13.302397,43.213707,0 ],
                [13.302828,43.213783,0 ],
                [13.303835,43.214062,0 ],
                [13.304154,43.214146,0 ],
                [13.304617,43.214302,0 ],
                [13.305136,43.214310,0 ],
                [13.305700,43.214146,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GUIDOBALDO ORIZI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.274814,43.205917 ,0],
                [13.274829,43.205833,0 ],
                [13.274829,43.205757,0 ],
                [13.274707,43.205547,0 ],
                [13.274988,43.205444,0 ],
                [13.275367,43.205322,0 ],
                [13.275419,43.205311,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VICOLO DEGLI ORTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289459,43.209183 ,0],
                [13.289557,43.209206,0 ],
                [13.290037,43.209370,0 ],
                [13.290395,43.209484,0 ],
                [13.290449,43.209473,0 ],
                [13.290715,43.209282,0 ],
                [13.290818,43.209148,0 ],
                [13.290998,43.208858,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ARNALDO OSMANI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.278312,43.207302 ,0],
                [13.278480,43.207577,0 ],
                [13.278666,43.207691,0 ],
                [13.278893,43.207771,0 ],
                [13.279310,43.207916,0 ],
                [13.279644,43.208054,0 ],
                [13.279912,43.208241,0 ],
                [13.279981,43.208294,0 ],
                [13.280088,43.208382,0 ],
                [13.280233,43.208492,0 ],
                [13.280786,43.208836,0 ],
                [13.281240,43.209122,0 ],
                [13.281399,43.209099,0 ],
                [13.281516,43.209099,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PAOLO PACE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.295778,43.216797 ,0],
                [13.295883,43.216709,0 ],
                [13.296847,43.215847,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIOVANNI PALATUCCI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.262356,43.186260 ,0],
                [13.262414,43.186226,0 ],
                [13.262612,43.186089,0 ],
                [13.262676,43.186100,0 ],
                [13.262962,43.186310,0 ],
                [13.262816,43.186459,0 ],
                [13.262782,43.186501,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE PARINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.292263,43.212456 ,0],
                [13.292269,43.212479,0 ],
                [13.292403,43.213020,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIOVANNI PASCOLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.300124,43.214100 ,0],
                [13.299972,43.213867,0 ],
                [13.299843,43.213772,0 ],
                [13.299641,43.213673,0 ],
                [13.299582,43.213612,0 ],
                [13.300115,43.212875,0 ],
                [13.300135,43.212849,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.299243,43.214020 ,0],
                [13.299504,43.213657,0 ],
                [13.299582,43.213612,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA BALILLA PASCOLINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.274179,43.205692 ,0],
                [13.274008,43.205914,0 ],
                [13.274002,43.205921,0 ],
                [13.274419,43.206169,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.273234,43.206013 ,0],
                [13.273404,43.205727,0 ],
                [13.274002,43.205921,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZALE ENNIO PASSAMONTI E PETER IVANOVICH",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.290687,43.213047 ,0],
                [13.290628,43.212994,0 ],
                [13.290609,43.212906,0 ],
                [13.290467,43.212803,0 ],
                [13.290771,43.212589,0 ],
                [13.290913,43.212658,0 ],
                [13.290978,43.212681,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PASUBIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.287911,43.215359 ,0],
                [13.288085,43.215157,0 ],
                [13.288286,43.214966,0 ],
                [13.288847,43.214443,0 ],
                [13.288951,43.214344,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA NICOLA PERAMEZZA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.275457,43.205330 ,0],
                [13.275693,43.205536,0 ],
                [13.275943,43.205410,0 ],
                [13.275696,43.205158,0 ],
                [13.275790,43.205112,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.274584,43.205040 ,0],
                [13.274732,43.205036,0 ],
                [13.274873,43.205048,0 ],
                [13.275005,43.205078,0 ],
                [13.275133,43.205124,0 ],
                [13.275262,43.205189,0 ],
                [13.275342,43.205250,0 ],
                [13.275419,43.205311,0 ],
                [13.275696,43.205158,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SPARTACO PERUGINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.274227,43.205708 ,0],
                [13.274158,43.205452,0 ],
                [13.274177,43.205425,0 ],
                [13.274864,43.205238,0 ],
                [13.274988,43.205444,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PIAVE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289066,43.216869 ,0],
                [13.289141,43.216808,0 ],
                [13.289709,43.216290,0 ],
                [13.290122,43.215916,0 ],
                [13.290197,43.215855,0 ],
                [13.290680,43.215366,0 ],
                [13.290713,43.215332,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SANDRO PERTINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.306056,43.214111 ,0],
                [13.307134,43.214767,0 ],
                [13.307833,43.215130,0 ],
                [13.308756,43.215572,0 ],
                [13.309749,43.216049,0 ],
                [13.310164,43.216331,0 ],
                [13.310694,43.216797,0 ],
                [13.311179,43.217293,0 ],
                [13.312817,43.218964,0 ],
                [13.313308,43.219257,0 ],
                [13.313732,43.219429,0 ],
                [13.314777,43.219627,0 ],
                [13.314891,43.219650,0 ],
                [13.316681,43.219925,0 ],
                [13.317903,43.220142,0 ],
                [13.321504,43.220783,0 ],
                [13.323367,43.220821,0 ],
                [13.324628,43.220928,0 ],
                [13.325551,43.221035,0 ],
                [13.327742,43.221252,0 ],
                [13.328274,43.221348,0 ],
                [13.329539,43.221523,0 ],
                [13.329990,43.221645,0 ],
                [13.331610,43.222244,0 ],
                [13.331916,43.222404,0 ],
                [13.332988,43.222961,0 ],
                [13.334630,43.223656,0 ],
                [13.334903,43.223789,0 ],
                [13.335340,43.224007,0 ],
                [13.336038,43.224354,0 ],
                [13.336659,43.224468,0 ],
                [13.337346,43.224541,0 ],
                [13.337714,43.224640,0 ],
                [13.339020,43.225296,0 ],
                [13.340014,43.225792,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DEL PONTE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285864,43.206764 ,0],
                [13.285956,43.206680,0 ],
                [13.285995,43.206573,0 ],
                [13.286118,43.206184,0 ],
                [13.286240,43.205788,0 ],
                [13.286492,43.205135,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PORTANOVA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.281054,43.215031 ,0],
                [13.281154,43.215050,0 ],
                [13.281635,43.214943,0 ],
                [13.282335,43.214779,0 ],
                [13.282392,43.214783,0 ],
                [13.282465,43.214783,0 ],
                [13.283686,43.214821,0 ],
                [13.284456,43.214848,0 ],
                [13.284622,43.214809,0 ],
                [13.284716,43.214741,0 ],
                [13.285313,43.215244,0 ],
                [13.285620,43.215481,0 ],
                [13.286361,43.215881,0 ],
                [13.287336,43.215973,0 ],
                [13.287519,43.216064,0 ],
                [13.288023,43.216320,0 ],
                [13.288414,43.216530,0 ],
                [13.288550,43.216599,0 ],
                [13.289066,43.216869,0 ],
                [13.289425,43.217068,0 ],
                [13.290500,43.217621,0 ],
                [13.290839,43.217789,0 ],
                [13.290915,43.217800,0 ],
                [13.292108,43.217979,0 ],
                [13.292852,43.217892,0 ],
                [13.293100,43.217789,0 ],
                [13.293152,43.217762,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CAMILLO PRAMPOLINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.277815,43.208668 ,0],
                [13.277847,43.208561,0 ],
                [13.277852,43.208504,0 ],
                [13.277690,43.208336,0 ],
                [13.277641,43.208279,0 ],
                [13.277730,43.208199,0 ],
                [13.277842,43.208065,0 ],
                [13.278195,43.207912,0 ],
                [13.278226,43.207901,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ENNIO PROIETTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.297677,43.217648 ,0],
                [13.298286,43.216679,0 ],
                [13.298643,43.216808,0 ],
                [13.299038,43.216167,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA MARIO RAMUNDO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.296544,43.213566 ,0],
                [13.297529,43.212273,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ORONZO REALE LOTTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.301588,43.218010 ,0],
                [13.303109,43.218094,0 ],
                [13.303199,43.218071,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA REDIPUGLIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.284547,43.213390 ,0],
                [13.285015,43.213425,0 ],
                [13.285041,43.213074,0 ],
                [13.285043,43.213017,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE DELLA REPUBBLICA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293440,43.210327 ,0],
                [13.293570,43.211033,0 ],
                [13.293731,43.211903,0 ],
                [13.293797,43.212254,0 ],
                [13.293806,43.212307,0 ],
                [13.293978,43.213100,0 ],
                [13.294028,43.213333,0 ],
                [13.294151,43.213688,0 ],
                [13.294475,43.214718,0 ],
                [13.294499,43.214783,0 ],
                [13.294532,43.214870,0 ],
                [13.294650,43.215179,0 ],
                [13.294827,43.215427,0 ],
                [13.295358,43.216175,0 ],
                [13.295394,43.216228,0 ],
                [13.295724,43.216690,0 ],
                [13.295778,43.216797,0 ],
                [13.295869,43.216969,0 ],
                [13.295904,43.217075,0 ],
                [13.295939,43.217075,0 ],
                [13.295979,43.217083,0 ],
                [13.296007,43.217102,0 ],
                [13.296027,43.217113,0 ],
                [13.296041,43.217136,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA PADRE MATTEO RICCI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291345,43.212456 ,0],
                [13.292148,43.213093,0 ],
                [13.292510,43.213375,0 ],
                [13.292557,43.213497,0 ],
                [13.292557,43.213543,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZALE RISORGIMENTO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.290149,43.212139 ,0],
                [13.290179,43.212070,0 ],
                [13.290268,43.211857,0 ],
                [13.290455,43.211895,0 ],
                [13.290374,43.212097,0 ],
                [13.290346,43.212181,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA LUIGI ROCCHI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291120,43.212868 ,0],
                [13.291176,43.212906,0 ],
                [13.291778,43.213348,0 ],
                [13.292302,43.213726,0 ],
                [13.292377,43.213760,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE ROMITA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.294350,43.210949 ,0],
                [13.294349,43.211010,0 ],
                [13.294314,43.211555,0 ],
                [13.294632,43.211731,0 ],
                [13.295835,43.212395,0 ],
                [13.295321,43.212997,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA FRATELLI ROSSELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276546,43.209438 ,0],
                [13.276674,43.210114,0 ],
                [13.277010,43.210659,0 ],
                [13.277110,43.211105,0 ],
                [13.277119,43.211140,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIOACCHINO ROSSINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.317903,43.220142 ,0],
                [13.317816,43.220375,0 ],
                [13.317902,43.220440,0 ],
                [13.327131,43.222328,0 ],
                [13.327356,43.222378,0 ],
                [13.328432,43.222633,0 ],
                [13.328941,43.222851,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ROVERETO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.295707,43.217663 ,0],
                [13.295920,43.217915,0 ],
                [13.296046,43.218048,0 ],
                [13.296158,43.218166,0 ],
                [13.296331,43.218327,0 ],
                [13.296508,43.218475,0 ],
                [13.296642,43.218590,0 ],
                [13.296751,43.218681,0 ],
                [13.296827,43.218739,0 ],
                [13.296943,43.218807,0 ],
                [13.297155,43.218933,0 ],
                [13.297250,43.218998,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.296808,43.219273 ,0],
                [13.296531,43.219063,0 ],
                [13.296943,43.218807,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA ANDREJ SACHAROV",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.335224,43.220608 ,0],
                [13.335686,43.221073,0 ],
                [13.337049,43.222454,0 ],
                [13.337137,43.222569,0 ],
                [13.337879,43.223507,0 ],
                [13.338797,43.224663,0 ],
                [13.339020,43.225296,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA ANDREJ SACHAROV",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.337137,43.222569 ,0],
                [13.337747,43.222298,0 ],
                [13.338516,43.223251,0 ],
                [13.337879,43.223507,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SANT&#x27;EGIDIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293978,43.213100 ,0],
                [13.293922,43.213108,0 ],
                [13.293676,43.213177,0 ],
                [13.293571,43.213345,0 ],
                [13.293535,43.213486,0 ],
                [13.293529,43.213512,0 ],
                [13.293567,43.213665,0 ],
                [13.293689,43.213856,0 ],
                [13.294050,43.214420,0 ],
                [13.294311,43.214703,0 ],
                [13.294362,43.214760,0 ],
                [13.294488,43.214851,0 ],
                [13.294532,43.214870,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SAN FRANCESCO D&#x27;ASSISI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.298105,43.220490 ,0],
                [13.297860,43.220394,0 ],
                [13.297662,43.220280,0 ],
                [13.297533,43.220192,0 ],
                [13.297482,43.220112,0 ],
                [13.297468,43.220047,0 ],
                [13.297517,43.219963,0 ],
                [13.297555,43.219841,0 ],
                [13.297530,43.219707,0 ],
                [13.297429,43.219555,0 ],
                [13.297287,43.219368,0 ],
                [13.297233,43.219284,0 ],
                [13.297226,43.219200,0 ],
                [13.297225,43.219093,0 ],
                [13.297250,43.218998,0 ],
                [13.297317,43.218922,0 ],
                [13.297433,43.218834,0 ],
                [13.297563,43.218742,0 ],
                [13.297593,43.218719,0 ],
                [13.297734,43.218594,0 ],
                [13.298070,43.218277,0 ],
                [13.298217,43.218163,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SANTA RITA DA CASCIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.299626,43.218822 ,0],
                [13.299457,43.218937,0 ],
                [13.299401,43.219002,0 ],
                [13.299359,43.219131,0 ],
                [13.299373,43.219296,0 ],
                [13.299348,43.219398,0 ],
                [13.299136,43.219624,0 ],
                [13.299726,43.219955,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.297288,43.219368 ,0],
                [13.297503,43.219475,0 ],
                [13.298511,43.220028,0 ],
                [13.298576,43.220051,0 ],
                [13.298648,43.220043,0 ],
                [13.298706,43.220009,0 ],
                [13.299136,43.219624,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA CARLO SANTINI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289571,43.211067 ,0],
                [13.289637,43.211098,0 ],
                [13.289668,43.211067,0 ],
                [13.289921,43.210815,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.288870,43.211880 ,0],
                [13.288961,43.211796,0 ],
                [13.289426,43.211315,0 ],
                [13.289473,43.211269,0 ],
                [13.289637,43.211098,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA RAFFAELLO SANZIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.294827,43.215427 ,0],
                [13.294867,43.215416,0 ],
                [13.295135,43.215309,0 ],
                [13.295662,43.214882,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIACOMO SAPUTO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.332510,43.221718 ,0],
                [13.332681,43.221806,0 ],
                [13.333375,43.222137,0 ],
                [13.333768,43.221695,0 ],
                [13.333745,43.221642,0 ],
                [13.333203,43.221382,0 ],
                [13.333096,43.221378,0 ],
                [13.333010,43.221428,0 ],
                [13.332729,43.221752,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIUSEPPE SARAGAT",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.301475,43.216988 ,0],
                [13.302505,43.217049,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA GIOVANNI SEBASTIANI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288273,43.212093 ,0],
                [13.288574,43.211857,0 ],
                [13.288607,43.211826,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA SISTO V",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289426,43.211315 ,0],
                [13.291205,43.211678,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA TONINO SPAZZOLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276109,43.206551 ,0],
                [13.276888,43.207443,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA UGO SPOSETTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.300274,43.212898 ,0],
                [13.300292,43.212860,0 ],
                [13.300797,43.211906,0 ],
                [13.300841,43.211807,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA STELVIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289717,43.215679 ,0],
                [13.290221,43.215157,0 ],
                [13.290286,43.215096,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA STICCHI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293142,43.210251 ,0],
                [13.293146,43.210209,0 ],
                [13.293059,43.209690,0 ],
                [13.293985,43.209606,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DON LUIGI STURZO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.295832,43.217602 ,0],
                [13.295953,43.217655,0 ],
                [13.296330,43.217728,0 ],
                [13.296935,43.217865,0 ],
                [13.297618,43.218029,0 ],
                [13.298217,43.218163,0 ],
                [13.298658,43.218262,0 ],
                [13.299314,43.218662,0 ],
                [13.299626,43.218822,0 ],
                [13.299874,43.218948,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "LARGO GIOVANNI TACCI PORCELLI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288558,43.211563 ,0],
                [13.288469,43.211521,0 ],
                [13.288253,43.211403,0 ],
                [13.288477,43.211185,0 ],
                [13.288291,43.211071,0 ],
                [13.288507,43.210861,0 ],
                [13.288563,43.210804,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA TAGLIAMENTO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.292585,43.217148 ,0],
                [13.292984,43.216663,0 ],
                [13.293066,43.216576,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE TERME SANTA LUCIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.275589,43.212959 ,0],
                [13.276126,43.212940,0 ],
                [13.276299,43.212906,0 ],
                [13.276466,43.212818,0 ],
                [13.276584,43.212711,0 ],
                [13.277039,43.212090,0 ],
                [13.277216,43.211895,0 ],
                [13.277857,43.211285,0 ],
                [13.278274,43.210880,0 ],
                [13.278555,43.210587,0 ],
                [13.279115,43.210045,0 ],
                [13.279757,43.209408,0 ],
                [13.279817,43.209301,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA TIMAVO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293441,43.217468 ,0],
                [13.293855,43.216984,0 ],
                [13.293898,43.216942,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA WALTER TOBAGI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.257356,43.184902 ,0],
                [13.261528,43.188488,0 ],
                [13.261800,43.188797,0 ],
                [13.262660,43.189774,0 ],
                [13.262779,43.189907,0 ],
                [13.262823,43.189972,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA PALMIRO TOGLIATTI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.297812,43.215656 ,0],
                [13.297170,43.215378,0 ],
                [13.297485,43.214973,0 ],
                [13.298127,43.215260,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA TOLMEZZO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.289123,43.215336 ,0],
                [13.289653,43.214825,0 ],
                [13.289713,43.214775,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA TONEZZA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286973,43.214878 ,0],
                [13.286902,43.214985,0 ],
                [13.286879,43.215103,0 ],
                [13.286988,43.215263,0 ],
                [13.287461,43.215549,0 ],
                [13.287551,43.215702,0 ],
                [13.287362,43.215935,0 ],
                [13.287336,43.215973,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE XXX GIUGNO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.279242,43.213104 ,0],
                [13.279296,43.213161,0 ],
                [13.279413,43.213253,0 ],
                [13.279524,43.213280,0 ],
                [13.279595,43.213280,0 ],
                [13.279673,43.213284,0 ],
                [13.279762,43.213287,0 ],
                [13.279863,43.213291,0 ],
                [13.280614,43.213161,0 ],
                [13.280776,43.213100,0 ],
                [13.281078,43.213001,0 ],
                [13.281489,43.212917,0 ],
                [13.281900,43.212879,0 ],
                [13.282351,43.212845,0 ],
                [13.282556,43.212807,0 ],
                [13.282804,43.212746,0 ],
                [13.283363,43.212601,0 ],
                [13.283568,43.212524,0 ],
                [13.283709,43.212460,0 ],
                [13.283798,43.212414,0 ],
                [13.284005,43.212315,0 ],
                [13.284204,43.212231,0 ],
                [13.284286,43.212200,0 ],
                [13.285116,43.211922,0 ],
                [13.285387,43.211876,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE TRENTO E TRIESTE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285495,43.212978 ,0],
                [13.285483,43.213058,0 ],
                [13.285462,43.213413,0 ],
                [13.285443,43.213749,0 ],
                [13.285455,43.213852,0 ],
                [13.285499,43.213978,0 ],
                [13.285547,43.214062,0 ],
                [13.285613,43.214130,0 ],
                [13.285736,43.214226,0 ],
                [13.285848,43.214302,0 ],
                [13.286973,43.214878,0 ],
                [13.287911,43.215359,0 ],
                [13.289044,43.215939,0 ],
                [13.289709,43.216290,0 ],
                [13.290071,43.216484,0 ],
                [13.291109,43.216999,0 ],
                [13.291949,43.217430,0 ],
                [13.293093,43.217739,0 ],
                [13.293152,43.217762,0 ],
                [13.293866,43.218052,0 ],
                [13.294073,43.218067,0 ],
                [13.294088,43.218067,0 ]
                ]
              }
            ,{ "type": "LineString",
              "coordinates": [
                [13.285719,43.214752 ,0],
                [13.285261,43.214539,0 ],
                [13.285192,43.214485,0 ],
                [13.285174,43.214439,0 ],
                [13.285331,43.214287,0 ],
                [13.285406,43.214241,0 ],
                [13.285538,43.214214,0 ],
                [13.285736,43.214226,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA EMILIO TREVES",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276932,43.209415 ,0],
                [13.277026,43.209259,0 ],
                [13.277049,43.209236,0 ],
                [13.277173,43.209137,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA FILIPPO TURATI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.273989,43.207691 ,0],
                [13.274043,43.207623,0 ],
                [13.275541,43.206905,0 ],
                [13.276031,43.206676,0 ],
                [13.276066,43.206646,0 ],
                [13.276109,43.206551,0 ],
                [13.276272,43.206226,0 ],
                [13.276278,43.206200,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DELLE VAGLIE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.272752,43.207890 ,0],
                [13.272780,43.207916,0 ],
                [13.273293,43.207867,0 ],
                [13.273624,43.207836,0 ],
                [13.273744,43.207806,0 ],
                [13.273910,43.207741,0 ],
                [13.273989,43.207691,0 ],
                [13.274174,43.207806,0 ],
                [13.274493,43.208084,0 ],
                [13.274872,43.208450,0 ],
                [13.275006,43.208588,0 ],
                [13.275029,43.208611,0 ],
                [13.275096,43.208801,0 ],
                [13.275169,43.208923,0 ],
                [13.275212,43.208965,0 ],
                [13.275246,43.209000,0 ],
                [13.275276,43.209011,0 ],
                [13.275305,43.209023,0 ],
                [13.275347,43.209038,0 ],
                [13.275636,43.209129,0 ],
                [13.276047,43.209240,0 ],
                [13.276361,43.209362,0 ],
                [13.276546,43.209438,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DEL VALLATO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.279981,43.208294 ,0],
                [13.280164,43.208256,0 ],
                [13.280539,43.208298,0 ],
                [13.280899,43.208313,0 ],
                [13.281172,43.208351,0 ],
                [13.281447,43.208389,0 ],
                [13.281623,43.208401,0 ],
                [13.281702,43.208374,0 ],
                [13.281768,43.208355,0 ],
                [13.282079,43.208241,0 ],
                [13.282409,43.208107,0 ],
                [13.282703,43.207996,0 ],
                [13.283046,43.207756,0 ],
                [13.283346,43.207550,0 ],
                [13.283544,43.207382,0 ],
                [13.283651,43.207355,0 ],
                [13.283707,43.207375,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE XXV APRILE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.287736,43.208755 ,0],
                [13.287775,43.208641,0 ],
                [13.287779,43.208538,0 ],
                [13.287742,43.208290,0 ],
                [13.287687,43.207932,0 ],
                [13.287743,43.207851,0 ],
                [13.287795,43.207829,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "PIAZZA DELL&#x27;UGUAGLIANZA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.307301,43.217522 ,0],
                [13.307135,43.217758,0 ],
                [13.307009,43.217922,0 ],
                [13.307411,43.218090,0 ],
                [13.307889,43.218296,0 ],
                [13.308109,43.218033,0 ],
                [13.307411,43.217735,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA VITALE VITALI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.278924,43.208771 ,0],
                [13.278987,43.208740,0 ],
                [13.279370,43.208580,0 ],
                [13.279016,43.208103,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIALE VITTORIO VENETO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285807,43.212334 ,0],
                [13.285917,43.212444,0 ],
                [13.286105,43.212650,0 ],
                [13.286211,43.212856,0 ],
                [13.286306,43.212971,0 ],
                [13.286414,43.213074,0 ],
                [13.286693,43.213207,0 ],
                [13.288791,43.214249,0 ],
                [13.288951,43.214344,0 ],
                [13.289238,43.214512,0 ],
                [13.289713,43.214775,0 ],
                [13.290073,43.214977,0 ],
                [13.290286,43.215096,0 ],
                [13.290713,43.215332,0 ],
                [13.291158,43.215591,0 ],
                [13.291505,43.215790,0 ],
                [13.292250,43.216190,0 ],
                [13.292445,43.216290,0 ],
                [13.292664,43.216400,0 ],
                [13.293066,43.216576,0 ],
                [13.293690,43.216846,0 ],
                [13.293898,43.216942,0 ],
                [13.295293,43.217575,0 ],
                [13.295394,43.217621,0 ],
                [13.295504,43.217659,0 ],
                [13.295607,43.217670,0 ],
                [13.295707,43.217663,0 ],
                [13.295832,43.217602,0 ],
                [13.295882,43.217514,0 ],
                [13.295915,43.217426,0 ],
                [13.295944,43.217335,0 ],
                [13.295946,43.217243,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA DEL VIVAIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.283651,43.207355 ,0],
                [13.283599,43.207329,0 ],
                [13.283663,43.207218,0 ],
                [13.283904,43.207005,0 ],
                [13.284122,43.206833,0 ],
                [13.284008,43.206676,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "VIA WILLY WEBER",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.298472,43.210987 ,0],
                [13.300467,43.211708,0 ],
                [13.300841,43.211807,0 ],
                [13.301108,43.211880,0 ],
                [13.302520,43.212215,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA ABBADIA DI FIASTRA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.375279,43.224812 ,0],
                [13.376931,43.225792,0 ],
                [13.377272,43.225964,0 ],
                [13.377546,43.225998,0 ],
                [13.379736,43.225739,0 ],
                [13.379999,43.225739,0 ],
                [13.381622,43.225891,0 ],
                [13.382852,43.226070,0 ],
                [13.385123,43.226437,0 ],
                [13.386396,43.226719,0 ],
                [13.387750,43.227348,0 ],
                [13.388211,43.227425,0 ],
                [13.388725,43.227360,0 ],
                [13.390224,43.227009,0 ],
                [13.390652,43.227020,0 ],
                [13.390872,43.227142,0 ],
                [13.391325,43.227581,0 ],
                [13.391633,43.227707,0 ],
                [13.395819,43.228962,0 ],
                [13.396203,43.229057,0 ],
                [13.398189,43.229168,0 ],
                [13.398966,43.229156,0 ],
                [13.400587,43.228973,0 ],
                [13.401331,43.228802,0 ],
                [13.401834,43.228767,0 ],
                [13.402406,43.228943,0 ],
                [13.403120,43.229145,0 ],
                [13.405650,43.231541,0 ],
                [13.405861,43.231850,0 ],
                [13.405883,43.234409,0 ],
                [13.406027,43.234615,0 ],
                [13.411402,43.237652,0 ],
                [13.411854,43.237980,0 ],
                [13.414235,43.240757,0 ],
                [13.414557,43.241310,0 ],
                [13.414573,43.241806,0 ],
                [13.414424,43.243633,0 ],
                [13.414516,43.244221,0 ],
                [13.414565,43.244732,0 ],
                [13.414956,43.246902,0 ],
                [13.415935,43.250607,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA ACQUASALATA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.295828,43.242348 ,0],
                [13.296082,43.242279,0 ],
                [13.296270,43.241989,0 ],
                [13.296560,43.241669,0 ],
                [13.296712,43.241436,0 ],
                [13.296785,43.241032,0 ],
                [13.296847,43.240818,0 ],
                [13.296986,43.240650,0 ],
                [13.297264,43.240471,0 ],
                [13.298708,43.239731,0 ],
                [13.299527,43.239368,0 ],
                [13.300076,43.239189,0 ],
                [13.302791,43.238461,0 ],
                [13.302990,43.238449,0 ],
                [13.303685,43.238605,0 ],
                [13.304207,43.238655,0 ],
                [13.304587,43.238659,0 ],
                [13.305054,43.238644,0 ],
                [13.305799,43.238651,0 ],
                [13.306147,43.238720,0 ],
                [13.306554,43.238853,0 ],
                [13.307828,43.239361,0 ],
                [13.308801,43.239799,0 ],
                [13.310106,43.240490,0 ],
                [13.311326,43.241135,0 ],
                [13.311769,43.241375,0 ],
                [13.311994,43.241543,0 ],
                [13.312299,43.242123,0 ],
                [13.312513,43.242538,0 ],
                [13.313457,43.244217,0 ],
                [13.313645,43.244541,0 ],
                [13.313761,43.244678,0 ],
                [13.313922,43.244797,0 ],
                [13.314079,43.244846,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA ANCAIANO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286585,43.205051 ,0],
                [13.287009,43.205051,0 ],
                [13.288363,43.204983,0 ],
                [13.288644,43.204945,0 ],
                [13.288837,43.204895,0 ],
                [13.289022,43.204819,0 ],
                [13.289252,43.204674,0 ],
                [13.289436,43.204536,0 ],
                [13.289950,43.204136,0 ],
                [13.290824,43.203438,0 ],
                [13.291003,43.203335,0 ],
                [13.291164,43.203285,0 ],
                [13.291331,43.203281,0 ],
                [13.291942,43.203377,0 ],
                [13.292288,43.203384,0 ],
                [13.292514,43.203354,0 ],
                [13.292749,43.203289,0 ],
                [13.292919,43.203205,0 ],
                [13.294939,43.202003,0 ],
                [13.295169,43.201847,0 ],
                [13.295339,43.201679,0 ],
                [13.295536,43.201431,0 ],
                [13.295728,43.201031,0 ],
                [13.296412,43.199146,0 ],
                [13.296806,43.197941,0 ],
                [13.297238,43.196938,0 ],
                [13.297283,43.196751,0 ],
                [13.297264,43.196609,0 ],
                [13.297277,43.196491,0 ],
                [13.297359,43.196342,0 ],
                [13.297676,43.196083,0 ],
                [13.297786,43.195930,0 ],
                [13.298094,43.194939,0 ],
                [13.298222,43.194794,0 ],
                [13.298535,43.194649,0 ],
                [13.298673,43.194508,0 ],
                [13.298792,43.194351,0 ],
                [13.298864,43.194191,0 ],
                [13.298932,43.193958,0 ],
                [13.298995,43.193703,0 ],
                [13.299101,43.193581,0 ],
                [13.299238,43.193527,0 ],
                [13.299418,43.193523,0 ],
                [13.299673,43.193592,0 ],
                [13.300104,43.193771,0 ],
                [13.300261,43.193863,0 ],
                [13.300494,43.194096,0 ],
                [13.300606,43.194157,0 ],
                [13.300739,43.194160,0 ],
                [13.302062,43.193691,0 ],
                [13.302339,43.193607,0 ],
                [13.302495,43.193607,0 ],
                [13.302657,43.193657,0 ],
                [13.302769,43.193718,0 ],
                [13.302982,43.193913,0 ],
                [13.303117,43.193993,0 ],
                [13.303325,43.194077,0 ],
                [13.303949,43.194149,0 ],
                [13.304139,43.194187,0 ],
                [13.304458,43.194290,0 ],
                [13.304634,43.194386,0 ],
                [13.304728,43.194466,0 ],
                [13.304816,43.194584,0 ],
                [13.304895,43.194759,0 ],
                [13.305069,43.195187,0 ],
                [13.305405,43.195644,0 ],
                [13.305526,43.195766,0 ],
                [13.305670,43.195854,0 ],
                [13.305845,43.195915,0 ],
                [13.306090,43.195965,0 ],
                [13.306358,43.195988,0 ],
                [13.306529,43.195976,0 ],
                [13.307106,43.195904,0 ],
                [13.307189,43.195869,0 ],
                [13.307235,43.195812,0 ],
                [13.307225,43.195744,0 ],
                [13.307178,43.195694,0 ],
                [13.307077,43.195667,0 ],
                [13.306824,43.195713,0 ],
                [13.306684,43.195713,0 ],
                [13.306606,43.195683,0 ],
                [13.306527,43.195580,0 ],
                [13.306385,43.195091,0 ],
                [13.306280,43.194683,0 ],
                [13.306284,43.194553,0 ],
                [13.306325,43.194382,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA ASININA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.291438,43.223721 ,0],
                [13.291412,43.223598,0 ],
                [13.291291,43.223450,0 ],
                [13.291211,43.223324,0 ],
                [13.291211,43.223255,0 ],
                [13.291323,43.223206,0 ],
                [13.291530,43.223164,0 ],
                [13.291650,43.223103,0 ],
                [13.291786,43.222984,0 ],
                [13.291893,43.222805,0 ],
                [13.292079,43.222626,0 ],
                [13.293116,43.221966,0 ],
                [13.293756,43.221508,0 ],
                [13.294190,43.221306,0 ],
                [13.294575,43.221008,0 ],
                [13.294765,43.220879,0 ],
                [13.294885,43.220749,0 ],
                [13.295275,43.220181,0 ],
                [13.295370,43.220112,0 ],
                [13.295560,43.220051,0 ],
                [13.295710,43.220036,0 ],
                [13.296042,43.219997,0 ],
                [13.296151,43.219982,0 ],
                [13.296233,43.219955,0 ],
                [13.296308,43.219929,0 ],
                [13.296383,43.219887,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA BURA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.245710,43.213371 ,0],
                [13.246232,43.213379,0 ],
                [13.247068,43.213264,0 ],
                [13.247201,43.213215,0 ],
                [13.247512,43.212849,0 ],
                [13.247635,43.212814,0 ],
                [13.248492,43.212898,0 ],
                [13.249468,43.212978,0 ],
                [13.249668,43.212994,0 ],
                [13.249817,43.212982,0 ],
                [13.250663,43.212784,0 ],
                [13.250868,43.212753,0 ],
                [13.251099,43.212757,0 ],
                [13.252023,43.212906,0 ],
                [13.252311,43.212944,0 ],
                [13.252587,43.212936,0 ],
                [13.253182,43.212772,0 ],
                [13.253879,43.212612,0 ],
                [13.253997,43.212543,0 ],
                [13.254206,43.212303,0 ],
                [13.254451,43.212074,0 ],
                [13.255502,43.212002,0 ],
                [13.256092,43.212029,0 ],
                [13.256385,43.211983,0 ],
                [13.256686,43.211876,0 ],
                [13.257051,43.211807,0 ],
                [13.257840,43.211735,0 ],
                [13.258507,43.211670,0 ],
                [13.258686,43.211605,0 ],
                [13.258783,43.211536,0 ],
                [13.258884,43.211334,0 ],
                [13.258894,43.211140,0 ],
                [13.258919,43.211040,0 ],
                [13.259170,43.210888,0 ],
                [13.259481,43.210701,0 ],
                [13.259783,43.210453,0 ],
                [13.259955,43.210232,0 ],
                [13.260104,43.210186,0 ],
                [13.260361,43.210175,0 ],
                [13.260463,43.210060,0 ],
                [13.260642,43.209957,0 ],
                [13.260800,43.209923,0 ],
                [13.261047,43.209953,0 ],
                [13.261252,43.209957,0 ],
                [13.261416,43.209869,0 ],
                [13.261584,43.209682,0 ],
                [13.261762,43.209335,0 ],
                [13.261854,43.209293,0 ],
                [13.262132,43.209457,0 ],
                [13.262492,43.209652,0 ],
                [13.263022,43.209846,0 ],
                [13.263464,43.209965,0 ],
                [13.263787,43.210026,0 ],
                [13.264296,43.210011,0 ],
                [13.264532,43.210030,0 ],
                [13.264645,43.210079,0 ],
                [13.264687,43.210159,0 ],
                [13.264651,43.210239,0 ],
                [13.264437,43.210449,0 ],
                [13.264330,43.210567,0 ],
                [13.264269,43.210705,0 ],
                [13.264286,43.210907,0 ],
                [13.264359,43.211075,0 ],
                [13.264596,43.211319,0 ],
                [13.264700,43.211456,0 ],
                [13.264710,43.211601,0 ],
                [13.264487,43.211983,0 ],
                [13.264488,43.212067,0 ],
                [13.264565,43.212120,0 ],
                [13.264971,43.212158,0 ],
                [13.265114,43.212139,0 ],
                [13.265293,43.212074,0 ],
                [13.265448,43.212097,0 ],
                [13.265582,43.212250,0 ],
                [13.265675,43.212376,0 ],
                [13.265727,43.212490,0 ],
                [13.265738,43.212620,0 ],
                [13.265636,43.212753,0 ],
                [13.265493,43.212868,0 ],
                [13.265356,43.213024,0 ],
                [13.265219,43.213230,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA CALCAVENACCIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.293191,43.184978 ,0],
                [13.293126,43.184944,0 ],
                [13.293013,43.184917,0 ],
                [13.292751,43.184872,0 ],
                [13.292606,43.184837,0 ],
                [13.292444,43.184757,0 ],
                [13.292276,43.184654,0 ],
                [13.292094,43.184464,0 ],
                [13.292016,43.184311,0 ],
                [13.291945,43.184261,0 ],
                [13.291673,43.184177,0 ],
                [13.291386,43.184052,0 ],
                [13.291036,43.183865,0 ],
                [13.290703,43.183762,0 ],
                [13.290567,43.183704,0 ],
                [13.290477,43.183655,0 ],
                [13.290424,43.183605,0 ],
                [13.290395,43.183544,0 ],
                [13.290339,43.182964,0 ],
                [13.290418,43.182514,0 ],
                [13.290484,43.182358,0 ],
                [13.290641,43.182190,0 ],
                [13.290698,43.182095,0 ],
                [13.290708,43.181992,0 ],
                [13.290685,43.181923,0 ],
                [13.290623,43.181835,0 ],
                [13.290085,43.181385,0 ],
                [13.290061,43.181305,0 ],
                [13.290077,43.181232,0 ],
                [13.290147,43.181087,0 ],
                [13.290406,43.180759,0 ],
                [13.290486,43.180294,0 ],
                [13.290492,43.180157,0 ],
                [13.290434,43.180092,0 ],
                [13.290357,43.180046,0 ],
                [13.289942,43.179840,0 ],
                [13.289828,43.179756,0 ],
                [13.289443,43.179428,0 ],
                [13.289462,43.179367,0 ],
                [13.289842,43.179245,0 ],
                [13.289941,43.179199,0 ],
                [13.289986,43.179119,0 ],
                [13.289982,43.178967,0 ],
                [13.289922,43.178673,0 ],
                [13.289905,43.178505,0 ],
                [13.289919,43.178322,0 ],
                [13.290041,43.178123,0 ],
                [13.290223,43.177711,0 ],
                [13.290276,43.177555,0 ],
                [13.290265,43.177513,0 ],
                [13.289506,43.177242,0 ],
                [13.289694,43.176861,0 ],
                [13.289924,43.176331,0 ],
                [13.290260,43.175823,0 ],
                [13.290346,43.175781,0 ],
                [13.291198,43.175983,0 ],
                [13.291337,43.175835,0 ],
                [13.291494,43.175713,0 ],
                [13.291787,43.175518,0 ],
                [13.291965,43.175423,0 ],
                [13.292238,43.175426,0 ],
                [13.292336,43.175411,0 ],
                [13.292542,43.175251,0 ],
                [13.292828,43.174950,0 ],
                [13.293240,43.174381,0 ],
                [13.293301,43.174332,0 ],
                [13.293372,43.174324,0 ],
                [13.293447,43.174355,0 ],
                [13.293689,43.174511,0 ],
                [13.293822,43.174568,0 ],
                [13.293948,43.174603,0 ],
                [13.294052,43.174599,0 ],
                [13.294148,43.174561,0 ],
                [13.294209,43.174503,0 ],
                [13.294361,43.174213,0 ],
                [13.294528,43.173843,0 ],
                [13.294580,43.173744,0 ],
                [13.294648,43.173691,0 ],
                [13.294742,43.173664,0 ],
                [13.294886,43.173702,0 ],
                [13.295058,43.173744,0 ],
                [13.295173,43.173798,0 ],
                [13.295296,43.173828,0 ],
                [13.295406,43.173817,0 ],
                [13.295514,43.173775,0 ],
                [13.295652,43.173653,0 ],
                [13.295806,43.173454,0 ],
                [13.296147,43.173088,0 ],
                [13.296340,43.172916,0 ],
                [13.296555,43.172775,0 ],
                [13.296748,43.172688,0 ],
                [13.297302,43.172451,0 ],
                [13.297392,43.172390,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA CASADICRISTO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.299514,43.162006 ,0],
                [13.299573,43.162231,0 ],
                [13.300219,43.162483,0 ],
                [13.300887,43.162727,0 ],
                [13.301347,43.162914,0 ],
                [13.301843,43.163101,0 ],
                [13.302193,43.163261,0 ],
                [13.302343,43.163345,0 ],
                [13.302379,43.163414,0 ],
                [13.302438,43.163605,0 ],
                [13.302491,43.163666,0 ],
                [13.303099,43.164074,0 ],
                [13.303546,43.164303,0 ],
                [13.305063,43.164883,0 ],
                [13.305192,43.164940,0 ],
                [13.305294,43.165009,0 ],
                [13.306134,43.165997,0 ],
                [13.306202,43.166088,0 ],
                [13.306229,43.166195,0 ],
                [13.306216,43.166317,0 ],
                [13.306139,43.166656,0 ],
                [13.306024,43.167221,0 ],
                [13.306038,43.167313,0 ],
                [13.305037,43.167439,0 ],
                [13.303630,43.167591,0 ],
                [13.303312,43.167614,0 ],
                [13.302878,43.167393,0 ],
                [13.302736,43.167381,0 ],
                [13.302583,43.167427,0 ],
                [13.302377,43.167713,0 ],
                [13.302246,43.167988,0 ],
                [13.302185,43.168076,0 ],
                [13.301927,43.168331,0 ],
                [13.301795,43.168415,0 ],
                [13.301649,43.168453,0 ],
                [13.301610,43.168491,0 ],
                [13.301606,43.168556,0 ],
                [13.301650,43.168644,0 ],
                [13.301637,43.169231,0 ],
                [13.301589,43.169407,0 ],
                [13.301552,43.169785,0 ],
                [13.301471,43.170193,0 ],
                [13.301404,43.170784,0 ],
                [13.301401,43.170963,0 ],
                [13.301434,43.171200,0 ],
                [13.301426,43.171352,0 ],
                [13.301432,43.171551,0 ],
                [13.301490,43.171650,0 ],
                [13.301592,43.171772,0 ],
                [13.301814,43.172001,0 ],
                [13.301908,43.172157,0 ],
                [13.302267,43.173050,0 ],
                [13.302341,43.173336,0 ],
                [13.302348,43.173527,0 ],
                [13.302284,43.173748,0 ],
                [13.302269,43.173935,0 ],
                [13.302316,43.174366,0 ],
                [13.302344,43.174675,0 ],
                [13.302347,43.174992,0 ],
                [13.302213,43.175247,0 ],
                [13.302041,43.175533,0 ],
                [13.301901,43.175644,0 ],
                [13.301858,43.175709,0 ],
                [13.301742,43.176235,0 ],
                [13.301728,43.176701,0 ],
                [13.301698,43.176960,0 ],
                [13.301704,43.177113,0 ],
                [13.301694,43.177258,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA CASONE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.325994,43.232010 ,0],
                [13.326766,43.232002,0 ],
                [13.326964,43.231670,0 ],
                [13.327120,43.231476,0 ],
                [13.327227,43.231396,0 ],
                [13.327314,43.231434,0 ],
                [13.327668,43.231667,0 ],
                [13.328948,43.232227,0 ],
                [13.329174,43.232315,0 ],
                [13.329566,43.232620,0 ],
                [13.329686,43.232704,0 ],
                [13.329887,43.232796,0 ],
                [13.330215,43.232849,0 ],
                [13.330510,43.232841,0 ],
                [13.330975,43.232841,0 ],
                [13.332213,43.232956,0 ],
                [13.332516,43.233013,0 ],
                [13.332799,43.233109,0 ],
                [13.332988,43.233154,0 ],
                [13.333170,43.233158,0 ],
                [13.333396,43.233109,0 ],
                [13.333189,43.232277,0 ],
                [13.333289,43.232216,0 ],
                [13.333999,43.232193,0 ],
                [13.334300,43.232204,0 ],
                [13.334760,43.232285,0 ],
                [13.335036,43.232376,0 ],
                [13.335541,43.232559,0 ],
                [13.336801,43.233078,0 ],
                [13.340935,43.234722,0 ],
                [13.341706,43.233734,0 ],
                [13.343195,43.231941,0 ],
                [13.343624,43.231419,0 ],
                [13.344049,43.230968,0 ],
                [13.344222,43.230732,0 ],
                [13.344328,43.230545,0 ],
                [13.344358,43.230419,0 ],
                [13.344381,43.230194,0 ],
                [13.344456,43.229935,0 ],
                [13.344549,43.229855,0 ],
                [13.344662,43.229843,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA CISTERNA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.314777,43.219627 ,0],
                [13.314755,43.219658,0 ],
                [13.314465,43.220566,0 ],
                [13.314507,43.220654,0 ],
                [13.314619,43.220711,0 ],
                [13.315119,43.220745,0 ],
                [13.315475,43.220802,0 ],
                [13.317205,43.221165,0 ],
                [13.317431,43.221245,0 ],
                [13.317572,43.221371,0 ],
                [13.321904,43.227516,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA COLLINA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.249013,43.226631 ,0],
                [13.249208,43.226807,0 ],
                [13.249375,43.226925,0 ],
                [13.249554,43.226994,0 ],
                [13.249748,43.226986,0 ],
                [13.249956,43.226902,0 ],
                [13.250252,43.226700,0 ],
                [13.250788,43.226284,0 ],
                [13.251003,43.226170,0 ],
                [13.251347,43.226021,0 ],
                [13.251571,43.225883,0 ],
                [13.252258,43.225372,0 ],
                [13.253002,43.224850,0 ],
                [13.253294,43.224712,0 ],
                [13.253535,43.224682,0 ],
                [13.253731,43.224747,0 ],
                [13.254085,43.224941,0 ],
                [13.254459,43.225239,0 ],
                [13.255235,43.225822,0 ],
                [13.255963,43.226368,0 ],
                [13.256330,43.226707,0 ],
                [13.256676,43.226986,0 ],
                [13.257297,43.227341,0 ],
                [13.258071,43.227730,0 ],
                [13.260248,43.228527,0 ],
                [13.260775,43.228691,0 ],
                [13.261089,43.228786,0 ],
                [13.261506,43.228909,0 ],
                [13.261871,43.229050,0 ],
                [13.262156,43.229137,0 ],
                [13.262382,43.229237,0 ],
                [13.262769,43.229458,0 ],
                [13.263161,43.229729,0 ],
                [13.263728,43.230160,0 ],
                [13.264094,43.230415,0 ],
                [13.264405,43.230610,0 ],
                [13.264890,43.230873,0 ],
                [13.265205,43.231018,0 ],
                [13.265422,43.231098,0 ],
                [13.266297,43.231380,0 ],
                [13.266710,43.231617,0 ],
                [13.266995,43.231819,0 ],
                [13.267200,43.231934,0 ],
                [13.267519,43.232048,0 ],
                [13.267680,43.232075,0 ],
                [13.267905,43.232063,0 ],
                [13.268164,43.232071,0 ],
                [13.268380,43.232105,0 ],
                [13.268691,43.232185,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA COLMAGGIORE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.287757,43.234905 ,0],
                [13.289331,43.234917,0 ],
                [13.289371,43.233944,0 ],
                [13.289842,43.233627,0 ],
                [13.290200,43.233318,0 ],
                [13.291122,43.232025,0 ],
                [13.291250,43.231979,0 ],
                [13.291453,43.232040,0 ],
                [13.291814,43.232159,0 ],
                [13.292062,43.232212,0 ],
                [13.292370,43.232216,0 ],
                [13.293037,43.232094,0 ],
                [13.293374,43.231937,0 ],
                [13.294264,43.231300,0 ],
                [13.294922,43.230846,0 ],
                [13.295123,43.230682,0 ],
                [13.295205,43.230534,0 ],
                [13.295332,43.230412,0 ],
                [13.295915,43.229980,0 ],
                [13.296430,43.229557,0 ],
                [13.296736,43.229240,0 ],
                [13.297016,43.228584,0 ],
                [13.297143,43.228504,0 ],
                [13.297414,43.228516,0 ],
                [13.297902,43.228611,0 ],
                [13.298278,43.228611,0 ],
                [13.298577,43.228554,0 ],
                [13.298900,43.228439,0 ],
                [13.299468,43.228123,0 ],
                [13.300515,43.227482,0 ],
                [13.301614,43.226803,0 ],
                [13.301875,43.226589,0 ],
                [13.302583,43.226009,0 ],
                [13.302838,43.225826,0 ],
                [13.303063,43.225704,0 ],
                [13.303166,43.225639,0 ],
                [13.303218,43.225563,0 ],
                [13.303219,43.225452,0 ],
                [13.303136,43.225311,0 ],
                [13.302306,43.224743,0 ],
                [13.302464,43.224667,0 ],
                [13.304192,43.224926,0 ],
                [13.304589,43.224911,0 ],
                [13.305374,43.224419,0 ],
                [13.304861,43.223980,0 ],
                [13.304152,43.223423,0 ],
                [13.303156,43.222717,0 ],
                [13.302620,43.222244,0 ],
                [13.301947,43.221481,0 ],
                [13.301581,43.220810,0 ],
                [13.301424,43.220562,0 ],
                [13.301252,43.220268,0 ],
                [13.300853,43.219803,0 ],
                [13.300681,43.219555,0 ],
                [13.300582,43.219379,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA DIVINA PASTORA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.351105,43.217384 ,0],
                [13.351952,43.217720,0 ],
                [13.352451,43.217979,0 ],
                [13.352604,43.217999,0 ],
                [13.352781,43.217972,0 ],
                [13.353283,43.217754,0 ],
                [13.353460,43.217636,0 ],
                [13.353601,43.217388,0 ],
                [13.353709,43.217243,0 ],
                [13.353845,43.217163,0 ],
                [13.354039,43.217171,0 ],
                [13.354943,43.217525,0 ],
                [13.356145,43.217770,0 ],
                [13.356371,43.217842,0 ],
                [13.357962,43.218838,0 ],
                [13.358240,43.218937,0 ],
                [13.358487,43.218987,0 ],
                [13.359364,43.219055,0 ],
                [13.359594,43.219120,0 ],
                [13.360390,43.219635,0 ],
                [13.361660,43.220516,0 ],
                [13.363166,43.221363,0 ],
                [13.363413,43.221466,0 ],
                [13.363733,43.221573,0 ],
                [13.366035,43.222191,0 ],
                [13.366302,43.222237,0 ],
                [13.366841,43.222237,0 ],
                [13.367109,43.222290,0 ],
                [13.367694,43.222595,0 ],
                [13.367941,43.222683,0 ],
                [13.368261,43.222755,0 ],
                [13.369268,43.222889,0 ],
                [13.374312,43.224342,0 ],
                [13.374639,43.224468,0 ],
                [13.375170,43.224735,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA FONTAIELLO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.302669,43.154957 ,0],
                [13.302653,43.155014,0 ],
                [13.302656,43.155075,0 ],
                [13.302717,43.155117,0 ],
                [13.303149,43.155243,0 ],
                [13.303549,43.155388,0 ],
                [13.303966,43.155563,0 ],
                [13.304184,43.155704,0 ],
                [13.304384,43.155796,0 ],
                [13.304828,43.156116,0 ],
                [13.304916,43.156193,0 ],
                [13.305008,43.156349,0 ],
                [13.305501,43.156967,0 ],
                [13.305726,43.157234,0 ],
                [13.305858,43.157413,0 ],
                [13.305893,43.157482,0 ],
                [13.305896,43.157570,0 ],
                [13.305867,43.157642,0 ],
                [13.305772,43.157719,0 ],
                [13.305714,43.157799,0 ],
                [13.305706,43.157837,0 ],
                [13.305760,43.157940,0 ],
                [13.305959,43.158169,0 ],
                [13.306123,43.158501,0 ],
                [13.306140,43.158588,0 ],
                [13.306143,43.158695,0 ],
                [13.306120,43.158810,0 ],
                [13.306004,43.159294,0 ],
                [13.307107,43.159634,0 ],
                [13.307429,43.159752,0 ],
                [13.310155,43.160118,0 ],
                [13.310506,43.160172,0 ],
                [13.310924,43.160191,0 ],
                [13.311368,43.160252,0 ],
                [13.311584,43.160271,0 ],
                [13.311839,43.160259,0 ],
                [13.312046,43.160236,0 ],
                [13.312328,43.160172,0 ],
                [13.312588,43.160027,0 ],
                [13.312925,43.159630,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA FONTEBIGONCIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276112,43.229172 ,0],
                [13.276220,43.229111,0 ],
                [13.276450,43.228863,0 ],
                [13.277472,43.228168,0 ],
                [13.277899,43.227810,0 ],
                [13.278344,43.227589,0 ],
                [13.278847,43.227325,0 ],
                [13.278990,43.227268,0 ],
                [13.279351,43.227215,0 ],
                [13.279678,43.227158,0 ],
                [13.279872,43.227093,0 ],
                [13.280026,43.227028,0 ],
                [13.280299,43.226929,0 ],
                [13.280379,43.226852,0 ],
                [13.280475,43.226692,0 ],
                [13.280419,43.226559,0 ],
                [13.280421,43.226204,0 ],
                [13.280396,43.226074,0 ],
                [13.280247,43.225895,0 ],
                [13.279355,43.225208,0 ],
                [13.279247,43.224792,0 ],
                [13.278955,43.224457,0 ],
                [13.278798,43.224319,0 ],
                [13.278530,43.223869,0 ],
                [13.278365,43.223732,0 ],
                [13.278234,43.223633,0 ],
                [13.278048,43.223370,0 ],
                [13.278069,43.223270,0 ],
                [13.278168,43.223068,0 ],
                [13.278362,43.222546,0 ],
                [13.278419,43.222336,0 ],
                [13.278492,43.221748,0 ],
                [13.278143,43.221146,0 ],
                [13.278121,43.221001,0 ],
                [13.278191,43.220631,0 ],
                [13.278134,43.220379,0 ],
                [13.278066,43.220165,0 ],
                [13.278035,43.220062,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA LE GRAZIE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.263330,43.189888 ,0],
                [13.263534,43.189888,0 ],
                [13.264145,43.189606,0 ],
                [13.264555,43.189449,0 ],
                [13.264761,43.189411,0 ],
                [13.264979,43.189426,0 ],
                [13.265889,43.189701,0 ],
                [13.266158,43.189758,0 ],
                [13.266417,43.189667,0 ],
                [13.266503,43.189632,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA MAESTA&#x27;",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276933,43.219997 ,0],
                [13.276834,43.219090,0 ],
                [13.276741,43.218235,0 ],
                [13.276817,43.217709,0 ],
                [13.276966,43.217228,0 ],
                [13.277876,43.215927,0 ],
                [13.277874,43.215866,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA MASSACCIO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.275513,43.229683 ,0],
                [13.274459,43.230419,0 ],
                [13.274402,43.230919,0 ],
                [13.274459,43.231426,0 ],
                [13.274548,43.231594,0 ],
                [13.274691,43.231682,0 ],
                [13.274929,43.231781,0 ],
                [13.275196,43.232250,0 ],
                [13.275340,43.232395,0 ],
                [13.275666,43.232533,0 ],
                [13.275816,43.232651,0 ],
                [13.276083,43.233013,0 ],
                [13.276322,43.233299,0 ],
                [13.276548,43.233662,0 ],
                [13.276536,43.233768,0 ],
                [13.276577,43.233818,0 ],
                [13.276922,43.233795,0 ],
                [13.277668,43.233772,0 ],
                [13.278374,43.233704,0 ],
                [13.278719,43.233624,0 ],
                [13.279268,43.233540,0 ],
                [13.280014,43.233559,0 ],
                [13.280395,43.233624,0 ],
                [13.281108,43.233810,0 ],
                [13.281427,43.233906,0 ],
                [13.281726,43.233917,0 ],
                [13.282126,43.233994,0 ],
                [13.282540,43.234028,0 ],
                [13.283722,43.234222,0 ],
                [13.284633,43.234432,0 ],
                [13.285183,43.234493,0 ],
                [13.285611,43.234627,0 ],
                [13.286331,43.234802,0 ],
                [13.286969,43.234905,0 ],
                [13.287376,43.234921,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA PACE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.300404,43.214993 ,0],
                [13.303377,43.215073,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA PARRUCCIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.290729,43.190781 ,0],
                [13.290936,43.190742,0 ],
                [13.291344,43.190731,0 ],
                [13.291719,43.190643,0 ],
                [13.292178,43.190632,0 ],
                [13.292276,43.190578,0 ],
                [13.292490,43.190315,0 ],
                [13.292700,43.190105,0 ],
                [13.292825,43.190033,0 ],
                [13.292966,43.189980,0 ],
                [13.293099,43.189972,0 ],
                [13.293268,43.190010,0 ],
                [13.293500,43.190086,0 ],
                [13.293834,43.190269,0 ],
                [13.294191,43.190384,0 ],
                [13.294564,43.190498,0 ],
                [13.294741,43.190540,0 ],
                [13.294878,43.190521,0 ],
                [13.295014,43.190449,0 ],
                [13.295113,43.190369,0 ],
                [13.295220,43.190113,0 ],
                [13.295571,43.189846,0 ],
                [13.295755,43.189754,0 ],
                [13.296017,43.189606,0 ],
                [13.296130,43.189560,0 ],
                [13.296337,43.189522,0 ],
                [13.296588,43.189491,0 ],
                [13.296791,43.189423,0 ],
                [13.296936,43.189350,0 ],
                [13.297151,43.189266,0 ],
                [13.297440,43.189068,0 ],
                [13.297585,43.189007,0 ],
                [13.297846,43.188923,0 ],
                [13.298089,43.188828,0 ],
                [13.298367,43.188736,0 ],
                [13.298644,43.188618,0 ],
                [13.298835,43.188469,0 ],
                [13.298995,43.188328,0 ],
                [13.299372,43.187912,0 ],
                [13.299550,43.187569,0 ],
                [13.299768,43.187344,0 ],
                [13.300059,43.186951,0 ],
                [13.300341,43.186749,0 ],
                [13.300708,43.186592,0 ],
                [13.301036,43.186428,0 ],
                [13.301215,43.186249,0 ],
                [13.301696,43.185528,0 ],
                [13.301902,43.185303,0 ],
                [13.302104,43.185024,0 ],
                [13.302178,43.184940,0 ],
                [13.302306,43.184826,0 ],
                [13.302463,43.184731,0 ],
                [13.302697,43.184635,0 ],
                [13.303076,43.184441,0 ],
                [13.303150,43.184368,0 ],
                [13.303185,43.184299,0 ],
                [13.303308,43.183987,0 ],
                [13.303541,43.183743,0 ],
                [13.303733,43.183567,0 ],
                [13.303818,43.183399,0 ],
                [13.303836,43.183277,0 ],
                [13.303834,43.182957,0 ],
                [13.303861,43.182804,0 ],
                [13.303851,43.182510,0 ],
                [13.303893,43.182396,0 ],
                [13.303957,43.182247,0 ],
                [13.304068,43.182091,0 ],
                [13.304173,43.181915,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA PATERNO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.305891,43.188419 ,0],
                [13.305987,43.188377,0 ],
                [13.306447,43.188377,0 ],
                [13.306607,43.188313,0 ],
                [13.306952,43.188072,0 ],
                [13.307460,43.187965,0 ],
                [13.308574,43.188110,0 ],
                [13.308775,43.188122,0 ],
                [13.308936,43.188053,0 ],
                [13.309288,43.187737,0 ],
                [13.309312,43.187603,0 ],
                [13.309254,43.187477,0 ],
                [13.308962,43.187164,0 ],
                [13.308864,43.187016,0 ],
                [13.308741,43.186676,0 ],
                [13.308611,43.186497,0 ],
                [13.308287,43.186241,0 ],
                [13.307719,43.185848,0 ],
                [13.307566,43.185722,0 ],
                [13.307443,43.185513,0 ],
                [13.306430,43.183529,0 ],
                [13.306420,43.183346,0 ],
                [13.306492,43.183189,0 ],
                [13.306612,43.183079,0 ],
                [13.306781,43.182995,0 ],
                [13.307095,43.182907,0 ],
                [13.307674,43.182762,0 ],
                [13.307891,43.182674,0 ],
                [13.308003,43.182568,0 ],
                [13.308035,43.182419,0 ],
                [13.308089,43.182178,0 ],
                [13.308088,43.182083,0 ],
                [13.308595,43.181828,0 ],
                [13.309558,43.180073,0 ],
                [13.309726,43.179871,0 ],
                [13.310647,43.179066,0 ],
                [13.311175,43.178543,0 ],
                [13.311387,43.177559,0 ],
                [13.311506,43.177311,0 ],
                [13.311634,43.177185,0 ],
                [13.312261,43.176857,0 ],
                [13.312501,43.176674,0 ],
                [13.312892,43.176060,0 ],
                [13.313091,43.175835,0 ],
                [13.313676,43.175297,0 ],
                [13.313853,43.175201,0 ],
                [13.314127,43.175152,0 ],
                [13.314466,43.175198,0 ],
                [13.315248,43.175354,0 ],
                [13.315683,43.175396,0 ],
                [13.316867,43.175144,0 ],
                [13.317157,43.175129,0 ],
                [13.317738,43.175167,0 ],
                [13.318180,43.175144,0 ],
                [13.320347,43.174900,0 ],
                [13.320548,43.174911,0 ],
                [13.320904,43.175076,0 ],
                [13.321309,43.175354,0 ],
                [13.321519,43.175430,0 ],
                [13.321769,43.175449,0 ],
                [13.322261,43.175446,0 ],
                [13.322769,43.175468,0 ],
                [13.323285,43.175529,0 ],
                [13.323439,43.175579,0 ],
                [13.323528,43.175682,0 ],
                [13.323691,43.175995,0 ],
                [13.323838,43.176262,0 ],
                [13.323944,43.176361,0 ],
                [13.324097,43.176399,0 ],
                [13.324242,43.176361,0 ],
                [13.324433,43.176041,0 ],
                [13.324600,43.175781,0 ],
                [13.324833,43.175537,0 ],
                [13.324912,43.175419,0 ],
                [13.324951,43.175278,0 ],
                [13.324986,43.174576,0 ],
                [13.324928,43.174232,0 ],
                [13.324884,43.173809,0 ],
                [13.324631,43.173225,0 ],
                [13.324597,43.173008,0 ],
                [13.324717,43.172802,0 ],
                [13.324877,43.172729,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA PIANARUCCI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.318854,43.213078 ,0],
                [13.318912,43.213303,0 ],
                [13.318888,43.213509,0 ],
                [13.318540,43.214417,0 ],
                [13.318535,43.214546,0 ],
                [13.318582,43.214687,0 ],
                [13.318740,43.214813,0 ],
                [13.319700,43.215034,0 ],
                [13.322072,43.215530,0 ],
                [13.322564,43.215652,0 ],
                [13.323124,43.215836,0 ],
                [13.324496,43.216358,0 ],
                [13.324918,43.216461,0 ],
                [13.325466,43.216484,0 ],
                [13.326262,43.216419,0 ],
                [13.328157,43.216209,0 ],
                [13.332158,43.216164,0 ],
                [13.332610,43.216263,0 ],
                [13.333001,43.216312,0 ],
                [13.334058,43.216312,0 ],
                [13.334295,43.216267,0 ],
                [13.334569,43.216145,0 ],
                [13.334906,43.216026,0 ],
                [13.336831,43.215622,0 ],
                [13.337100,43.215519,0 ],
                [13.337794,43.215073,0 ],
                [13.338040,43.214947,0 ],
                [13.338260,43.214874,0 ],
                [13.338906,43.214760,0 ],
                [13.339360,43.214725,0 ],
                [13.341803,43.214817,0 ],
                [13.342180,43.214848,0 ],
                [13.342519,43.214943,0 ],
                [13.342866,43.215088,0 ],
                [13.343688,43.215672,0 ],
                [13.343954,43.215794,0 ],
                [13.344225,43.215866,0 ],
                [13.348009,43.216248,0 ],
                [13.348297,43.216301,0 ],
                [13.348595,43.216389,0 ],
                [13.350998,43.217339,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA PIANCIANO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286865,43.204185 ,0],
                [13.286902,43.203785,0 ],
                [13.286959,43.203476,0 ],
                [13.287029,43.203217,0 ],
                [13.287157,43.202942,0 ],
                [13.287725,43.202057,0 ],
                [13.287853,43.201653,0 ],
                [13.287852,43.201527,0 ],
                [13.287770,43.201309,0 ],
                [13.287688,43.201160,0 ],
                [13.287535,43.200966,0 ],
                [13.287462,43.200794,0 ],
                [13.287420,43.200569,0 ],
                [13.287433,43.200390,0 ],
                [13.287363,43.200089,0 ],
                [13.287187,43.199871,0 ],
                [13.287050,43.199604,0 ],
                [13.287021,43.199169,0 ],
                [13.286927,43.198532,0 ],
                [13.286893,43.198181,0 ],
                [13.286914,43.197971,0 ],
                [13.287029,43.197685,0 ],
                [13.287193,43.197445,0 ],
                [13.287573,43.197166,0 ],
                [13.287832,43.196972,0 ],
                [13.288064,43.196766,0 ],
                [13.288295,43.196487,0 ],
                [13.288556,43.195904,0 ],
                [13.288719,43.195473,0 ],
                [13.288803,43.195282,0 ],
                [13.288950,43.195038,0 ],
                [13.289002,43.194874,0 ],
                [13.288987,43.194641,0 ],
                [13.288989,43.194260,0 ],
                [13.289024,43.194172,0 ],
                [13.289159,43.194038,0 ],
                [13.289471,43.193817,0 ],
                [13.289680,43.193619,0 ],
                [13.289826,43.193306,0 ],
                [13.289902,43.193184,0 ],
                [13.289987,43.193127,0 ],
                [13.290112,43.193100,0 ],
                [13.290363,43.193104,0 ],
                [13.290498,43.193077,0 ],
                [13.290717,43.192986,0 ],
                [13.290829,43.192905,0 ],
                [13.290949,43.192783,0 ],
                [13.291011,43.192642,0 ],
                [13.291009,43.192436,0 ],
                [13.290950,43.192238,0 ],
                [13.290782,43.192020,0 ],
                [13.290759,43.191914,0 ],
                [13.290739,43.191628,0 ],
                [13.290694,43.191498,0 ],
                [13.290522,43.191231,0 ],
                [13.290485,43.191139,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA PIANIBIANCHI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.273690,43.185608 ,0],
                [13.273912,43.185917,0 ],
                [13.274229,43.186592,0 ],
                [13.274507,43.187340,0 ],
                [13.274779,43.187775,0 ],
                [13.274931,43.188145,0 ],
                [13.274940,43.188576,0 ],
                [13.274893,43.188896,0 ],
                [13.274746,43.189217,0 ],
                [13.274612,43.189476,0 ],
                [13.274069,43.191097,0 ],
                [13.273510,43.192528,0 ],
                [13.273414,43.192959,0 ],
                [13.273431,43.193451,0 ],
                [13.273663,43.195362,0 ],
                [13.273679,43.195675,0 ],
                [13.273380,43.196663,0 ],
                [13.273290,43.196972,0 ],
                [13.273306,43.197353,0 ],
                [13.273487,43.197819,0 ],
                [13.274276,43.199203,0 ],
                [13.275030,43.200619,0 ],
                [13.275187,43.200825,0 ],
                [13.276001,43.201481,0 ],
                [13.276145,43.201694,0 ],
                [13.276125,43.201942,0 ],
                [13.276019,43.202114,0 ],
                [13.275759,43.202442,0 ],
                [13.275703,43.202702,0 ],
                [13.275784,43.202961,0 ],
                [13.276083,43.203217,0 ],
                [13.276333,43.203438,0 ],
                [13.276784,43.204029,0 ],
                [13.277092,43.204437,0 ],
                [13.277699,43.204945,0 ],
                [13.278161,43.205204,0 ],
                [13.278439,43.205311,0 ],
                [13.278893,43.205441,0 ],
                [13.279038,43.205463,0 ],
                [13.281052,43.205360,0 ],
                [13.281710,43.205296,0 ],
                [13.281995,43.205227,0 ],
                [13.282942,43.204872,0 ],
                [13.283254,43.204807,0 ],
                [13.284210,43.204517,0 ],
                [13.284499,43.204475,0 ],
                [13.285172,43.204552,0 ],
                [13.285933,43.204803,0 ],
                [13.286452,43.205029,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA PORTANOVA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.282465,43.214783 ,0],
                [13.282462,43.214882,0 ],
                [13.282459,43.215336,0 ],
                [13.282759,43.215584,0 ],
                [13.282856,43.215733,0 ],
                [13.282899,43.215878,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA RAMBONA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.276401,43.233948 ,0],
                [13.276388,43.234074,0 ],
                [13.276450,43.234459,0 ],
                [13.276474,43.234806,0 ],
                [13.276599,43.235165,0 ],
                [13.276567,43.235462,0 ],
                [13.276834,43.236076,0 ],
                [13.277144,43.236683,0 ],
                [13.277322,43.236908,0 ],
                [13.277452,43.237015,0 ],
                [13.278501,43.237656,0 ],
                [13.278841,43.237900,0 ],
                [13.279305,43.238255,0 ],
                [13.279870,43.238705,0 ],
                [13.280990,43.239399,0 ],
                [13.281281,43.239613,0 ],
                [13.281539,43.239746,0 ],
                [13.283382,43.240410,0 ],
                [13.283607,43.240444,0 ],
                [13.286213,43.240711,0 ],
                [13.289961,43.241116,0 ],
                [13.292745,43.241432,0 ],
                [13.294049,43.241722,0 ],
                [13.294899,43.241947,0 ],
                [13.295599,43.242256,0 ],
                [13.296404,43.242817,0 ],
                [13.298013,43.243965,0 ],
                [13.298149,43.244106,0 ],
                [13.298275,43.244652,0 ],
                [13.298386,43.244968,0 ],
                [13.298510,43.245205,0 ],
                [13.298993,43.246540,0 ],
                [13.299116,43.246704,0 ],
                [13.299403,43.247028,0 ],
                [13.302168,43.250530,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA RANCIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.346140,43.229412 ,0],
                [13.346840,43.229736,0 ],
                [13.347545,43.230034,0 ],
                [13.349474,43.230778,0 ],
                [13.354177,43.233032,0 ],
                [13.369334,43.240276,0 ],
                [13.369795,43.240471,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA REDENTORE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.306337,43.194336 ,0],
                [13.306367,43.194248,0 ],
                [13.306376,43.194149,0 ],
                [13.306341,43.193981,0 ],
                [13.306293,43.193825,0 ],
                [13.306316,43.193726,0 ],
                [13.306512,43.193390,0 ],
                [13.306615,43.193142,0 ],
                [13.306744,43.192978,0 ],
                [13.306886,43.192921,0 ],
                [13.307028,43.192921,0 ],
                [13.307199,43.192974,0 ],
                [13.308395,43.193825,0 ],
                [13.308551,43.193916,0 ],
                [13.308790,43.193981,0 ],
                [13.309730,43.194149,0 ],
                [13.310033,43.194336,0 ],
                [13.310511,43.195004,0 ],
                [13.310578,43.195080,0 ],
                [13.310697,43.195160,0 ],
                [13.310885,43.195240,0 ],
                [13.311372,43.195362,0 ],
                [13.311620,43.195404,0 ],
                [13.311917,43.195496,0 ],
                [13.312065,43.195568,0 ],
                [13.312250,43.195698,0 ],
                [13.312410,43.195808,0 ],
                [13.312570,43.195900,0 ],
                [13.312742,43.195961,0 ],
                [13.313367,43.196102,0 ],
                [13.313501,43.196152,0 ],
                [13.313674,43.196224,0 ],
                [13.313805,43.196327,0 ],
                [13.313893,43.196419,0 ],
                [13.314062,43.196655,0 ],
                [13.314159,43.196747,0 ],
                [13.314277,43.196815,0 ],
                [13.314508,43.196896,0 ],
                [13.314776,43.196930,0 ],
                [13.315083,43.196949,0 ],
                [13.315909,43.197258,0 ],
                [13.316023,43.197319,0 ],
                [13.316108,43.197414,0 ],
                [13.316405,43.197983,0 ],
                [13.316477,43.198063,0 ],
                [13.316590,43.198120,0 ],
                [13.316762,43.198128,0 ],
                [13.317361,43.198025,0 ],
                [13.317482,43.198025,0 ],
                [13.317595,43.198059,0 ],
                [13.317751,43.198151,0 ],
                [13.317932,43.198212,0 ],
                [13.318095,43.198215,0 ],
                [13.318718,43.198082,0 ],
                [13.319300,43.197914,0 ],
                [13.320312,43.197674,0 ],
                [13.320496,43.197655,0 ],
                [13.320672,43.197659,0 ],
                [13.320865,43.197716,0 ],
                [13.321042,43.197834,0 ],
                [13.321650,43.198444,0 ],
                [13.321780,43.198540,0 ],
                [13.321986,43.198616,0 ],
                [13.322170,43.198635,0 ],
                [13.322556,43.198582,0 ],
                [13.322803,43.198612,0 ],
                [13.322946,43.198662,0 ],
                [13.323051,43.198753,0 ],
                [13.323381,43.199268,0 ],
                [13.323678,43.199738,0 ],
                [13.323784,43.199860,0 ],
                [13.323923,43.199959,0 ],
                [13.324079,43.200039,0 ],
                [13.324280,43.200092,0 ],
                [13.324472,43.200119,0 ],
                [13.324716,43.200115,0 ],
                [13.324870,43.200081,0 ],
                [13.325054,43.200016,0 ],
                [13.325205,43.199940,0 ],
                [13.325759,43.199501,0 ],
                [13.325925,43.199341,0 ],
                [13.326087,43.199089,0 ],
                [13.326190,43.198845,0 ],
                [13.326264,43.198757,0 ],
                [13.326373,43.198708,0 ],
                [13.326983,43.198513,0 ],
                [13.327109,43.198509,0 ],
                [13.327218,43.198524,0 ],
                [13.327340,43.198593,0 ],
                [13.327635,43.198837,0 ],
                [13.327744,43.198902,0 ],
                [13.327921,43.198959,0 ],
                [13.328773,43.199146,0 ],
                [13.328979,43.199177,0 ],
                [13.329301,43.199177,0 ],
                [13.329510,43.199139,0 ],
                [13.329953,43.199028,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA REGNANO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.311007,43.167793 ,0],
                [13.311255,43.167721,0 ],
                [13.311522,43.167664,0 ],
                [13.311884,43.167645,0 ],
                [13.312329,43.167610,0 ],
                [13.312581,43.167480,0 ],
                [13.312680,43.167408,0 ],
                [13.313386,43.167015,0 ],
                [13.313771,43.166836,0 ],
                [13.314849,43.166374,0 ],
                [13.314978,43.166332,0 ],
                [13.316107,43.166164,0 ],
                [13.316270,43.166111,0 ],
                [13.316517,43.166008,0 ],
                [13.316863,43.165897,0 ],
                [13.317027,43.165943,0 ],
                [13.317370,43.166206,0 ],
                [13.317610,43.166348,0 ],
                [13.317763,43.166416,0 ],
                [13.318171,43.166439,0 ],
                [13.318870,43.166523,0 ],
                [13.319500,43.166565,0 ],
                [13.321766,43.166653,0 ],
                [13.322103,43.166702,0 ],
                [13.322356,43.166702,0 ],
                [13.322633,43.166683,0 ],
                [13.323025,43.166641,0 ],
                [13.323792,43.166630,0 ],
                [13.324076,43.166653,0 ],
                [13.325803,43.166996,0 ],
                [13.326046,43.167065,0 ],
                [13.326264,43.167099,0 ],
                [13.326468,43.167107,0 ],
                [13.326661,43.167072,0 ],
                [13.326829,43.167034,0 ],
                [13.326978,43.166973,0 ],
                [13.327273,43.166801,0 ],
                [13.327941,43.166550,0 ],
                [13.328385,43.166367,0 ],
                [13.328787,43.166298,0 ],
                [13.329128,43.166218,0 ],
                [13.329420,43.166187,0 ],
                [13.329618,43.166206,0 ],
                [13.329867,43.166260,0 ],
                [13.330086,43.166340,0 ],
                [13.330388,43.166370,0 ],
                [13.330538,43.166454,0 ],
                [13.330731,43.166546,0 ],
                [13.330855,43.166576,0 ],
                [13.331015,43.166592,0 ],
                [13.331183,43.166573,0 ],
                [13.331480,43.166519,0 ],
                [13.332079,43.166409,0 ],
                [13.332282,43.166389,0 ],
                [13.332688,43.166393,0 ],
                [13.333169,43.166317,0 ],
                [13.333364,43.166321,0 ],
                [13.334032,43.166241,0 ],
                [13.334190,43.166260,0 ],
                [13.334316,43.166309,0 ],
                [13.334435,43.166382,0 ],
                [13.334516,43.166512,0 ],
                [13.334591,43.166691,0 ],
                [13.334631,43.166775,0 ],
                [13.334722,43.166855,0 ],
                [13.335291,43.167229,0 ],
                [13.335814,43.167477,0 ],
                [13.335957,43.167522,0 ],
                [13.336170,43.167320,0 ],
                [13.336452,43.167027,0 ],
                [13.336647,43.166683,0 ],
                [13.336798,43.166420,0 ],
                [13.336926,43.166115,0 ],
                [13.337003,43.165668,0 ],
                [13.337388,43.164181,0 ],
                [13.337477,43.163887,0 ],
                [13.337565,43.163692,0 ],
                [13.337689,43.163559,0 ],
                [13.337796,43.163471,0 ],
                [13.338006,43.163429,0 ],
                [13.338577,43.163376,0 ],
                [13.338901,43.163322,0 ],
                [13.339160,43.163231,0 ],
                [13.339516,43.163025,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA RIBUTINO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.288458,43.205036 ,0],
                [13.288730,43.205044,0 ],
                [13.289114,43.204998,0 ],
                [13.289244,43.205013,0 ],
                [13.289342,43.205086,0 ],
                [13.289510,43.205318,0 ],
                [13.289804,43.205654,0 ],
                [13.289934,43.205746,0 ],
                [13.290076,43.205780,0 ],
                [13.290797,43.205837,0 ],
                [13.292701,43.206123,0 ],
                [13.293045,43.206200,0 ],
                [13.293358,43.206299,0 ],
                [13.294196,43.206741,0 ],
                [13.295419,43.207172,0 ],
                [13.296619,43.207859,0 ],
                [13.296810,43.207893,0 ],
                [13.297466,43.207863,0 ],
                [13.297681,43.207817,0 ],
                [13.297863,43.207726,0 ],
                [13.298861,43.206657,0 ],
                [13.299034,43.206573,0 ],
                [13.299205,43.206539,0 ],
                [13.299622,43.206486,0 ],
                [13.300076,43.206474,0 ],
                [13.301044,43.206528,0 ],
                [13.302001,43.206532,0 ],
                [13.303167,43.206394,0 ],
                [13.304225,43.206287,0 ],
                [13.304513,43.206322,0 ],
                [13.306203,43.206894,0 ],
                [13.306622,43.207073,0 ],
                [13.308143,43.207767,0 ],
                [13.308561,43.208015,0 ],
                [13.309587,43.208637,0 ],
                [13.310046,43.208855,0 ],
                [13.310863,43.209213,0 ],
                [13.311149,43.209309,0 ],
                [13.311619,43.209427,0 ],
                [13.311981,43.209541,0 ],
                [13.312773,43.209808,0 ],
                [13.313416,43.210075,0 ],
                [13.314220,43.210430,0 ],
                [13.314668,43.210644,0 ],
                [13.314862,43.210701,0 ],
                [13.315447,43.210808,0 ],
                [13.316061,43.211044,0 ],
                [13.316460,43.211304,0 ],
                [13.317141,43.211845,0 ],
                [13.317780,43.212284,0 ],
                [13.318692,43.212845,0 ],
                [13.318794,43.212982,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA RIOLANTE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.275849,43.229294 ,0],
                [13.276765,43.228230,0 ],
                [13.276812,43.228004,0 ],
                [13.276661,43.227829,0 ],
                [13.275231,43.227070,0 ],
                [13.274904,43.226692,0 ],
                [13.274733,43.226456,0 ],
                [13.274636,43.226242,0 ],
                [13.274599,43.225662,0 ],
                [13.274421,43.225300,0 ],
                [13.274338,43.225063,0 ],
                [13.274356,43.224819,0 ],
                [13.274449,43.224525,0 ],
                [13.274652,43.224243,0 ],
                [13.274778,43.224049,0 ],
                [13.274852,43.223766,0 ],
                [13.274831,43.223637,0 ],
                [13.274713,43.223206,0 ],
                [13.274697,43.223007,0 ],
                [13.274716,43.222721,0 ],
                [13.274562,43.221977,0 ],
                [13.274562,43.221848,0 ],
                [13.274621,43.221664,0 ],
                [13.274749,43.221416,0 ],
                [13.275038,43.221024,0 ],
                [13.275180,43.220940,0 ],
                [13.275424,43.220924,0 ],
                [13.275600,43.220978,0 ],
                [13.276017,43.221367,0 ],
                [13.276221,43.221504,0 ],
                [13.276411,43.221516,0 ],
                [13.276601,43.221451,0 ],
                [13.276714,43.221287,0 ],
                [13.276946,43.220272,0 ],
                [13.276952,43.220116,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA ROFANELLO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.270948,43.176800 ,0],
                [13.271354,43.175419,0 ],
                [13.270823,43.174484,0 ],
                [13.270393,43.173386,0 ],
                [13.270210,43.173119,0 ],
                [13.270000,43.172852,0 ],
                [13.269864,43.172546,0 ],
                [13.269924,43.172382,0 ],
                [13.270131,43.172173,0 ],
                [13.270436,43.171635,0 ],
                [13.271070,43.169724,0 ],
                [13.271001,43.169552,0 ],
                [13.270791,43.169243,0 ],
                [13.270750,43.169098,0 ],
                [13.270782,43.168941,0 ],
                [13.270727,43.168652,0 ],
                [13.270759,43.168438,0 ],
                [13.270717,43.168114,0 ],
                [13.270722,43.167976,0 ],
                [13.270749,43.167881,0 ],
                [13.270903,43.167728,0 ],
                [13.271096,43.167557,0 ],
                [13.271129,43.167439,0 ],
                [13.271074,43.167252,0 ],
                [13.271107,43.167110,0 ],
                [13.271333,43.166702,0 ],
                [13.271451,43.166363,0 ],
                [13.271125,43.165653,0 ],
                [13.270604,43.165165,0 ],
                [13.270469,43.164989,0 ],
                [13.270448,43.164829,0 ],
                [13.270568,43.164650,0 ],
                [13.271262,43.164013,0 ],
                [13.271408,43.163712,0 ],
                [13.271649,43.163597,0 ],
                [13.271830,43.163517,0 ],
                [13.271916,43.163406,0 ],
                [13.271900,43.163029,0 ],
                [13.271852,43.162834,0 ],
                [13.272012,43.162495,0 ],
                [13.272145,43.162441,0 ],
                [13.272488,43.162445,0 ],
                [13.272649,43.162415,0 ],
                [13.272978,43.162312,0 ],
                [13.273266,43.162251,0 ],
                [13.273386,43.162186,0 ],
                [13.273419,43.162106,0 ],
                [13.273398,43.161995,0 ],
                [13.273310,43.161755,0 ],
                [13.273301,43.161518,0 ],
                [13.273408,43.161411,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA ROSCIANO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.249516,43.209789 ,0],
                [13.249466,43.209751,0 ],
                [13.249357,43.209606,0 ],
                [13.249143,43.209251,0 ],
                [13.248883,43.208916,0 ],
                [13.248775,43.208714,0 ],
                [13.248757,43.208641,0 ],
                [13.248781,43.208534,0 ],
                [13.249009,43.208324,0 ],
                [13.249029,43.208172,0 ],
                [13.248848,43.207870,0 ],
                [13.248747,43.207634,0 ],
                [13.248691,43.207172,0 ],
                [13.248714,43.206955,0 ],
                [13.248759,43.206795,0 ],
                [13.248811,43.206356,0 ],
                [13.248817,43.206211,0 ],
                [13.248755,43.205994,0 ],
                [13.248824,43.205803,0 ],
                [13.249086,43.205326,0 ],
                [13.249252,43.205154,0 ],
                [13.249607,43.204880,0 ],
                [13.249657,43.204800,0 ],
                [13.249249,43.204006,0 ],
                [13.249227,43.203728,0 ],
                [13.249296,43.203484,0 ],
                [13.250141,43.202312,0 ],
                [13.250205,43.201973,0 ],
                [13.250192,43.201870,0 ],
                [13.250032,43.201622,0 ],
                [13.249999,43.201530,0 ],
                [13.250369,43.200871,0 ],
                [13.250707,43.200321,0 ],
                [13.250739,43.200218,0 ],
                [13.250667,43.199944,0 ],
                [13.250661,43.199741,0 ],
                [13.250706,43.199535,0 ],
                [13.250821,43.199368,0 ],
                [13.251040,43.199165,0 ],
                [13.251160,43.199005,0 ],
                [13.251233,43.198826,0 ],
                [13.251278,43.198631,0 ],
                [13.251292,43.198227,0 ],
                [13.251595,43.198166,0 ],
                [13.253216,43.197788,0 ],
                [13.255418,43.197243,0 ],
                [13.256400,43.196850,0 ],
                [13.256930,43.196693,0 ],
                [13.257125,43.196617,0 ],
                [13.257236,43.196468,0 ],
                [13.257426,43.196323,0 ],
                [13.257787,43.196129,0 ],
                [13.258721,43.195526,0 ],
                [13.258932,43.195351,0 ],
                [13.259664,43.194664,0 ],
                [13.259812,43.194546,0 ],
                [13.259986,43.194450,0 ],
                [13.260255,43.194363,0 ],
                [13.260620,43.194370,0 ],
                [13.261526,43.194340,0 ],
                [13.261816,43.194355,0 ],
                [13.262103,43.194420,0 ],
                [13.263048,43.194786,0 ],
                [13.264419,43.195557,0 ],
                [13.264552,43.195591,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA ROTONDO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.340014,43.225792 ,0],
                [13.341744,43.226662,0 ],
                [13.342838,43.227379,0 ],
                [13.344955,43.228760,0 ],
                [13.345303,43.228966,0 ],
                [13.346028,43.229351,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SALCITO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.311954,43.235077 ,0],
                [13.311729,43.234997,0 ],
                [13.311472,43.234917,0 ],
                [13.311261,43.234844,0 ],
                [13.311101,43.234760,0 ],
                [13.310987,43.234680,0 ],
                [13.310884,43.234592,0 ],
                [13.310800,43.234436,0 ],
                [13.310751,43.234215,0 ],
                [13.310746,43.234009,0 ],
                [13.310676,43.233776,0 ],
                [13.310624,43.233555,0 ],
                [13.310672,43.233284,0 ],
                [13.310692,43.232456,0 ],
                [13.310666,43.232380,0 ],
                [13.310791,43.232281,0 ],
                [13.312005,43.230679,0 ],
                [13.312246,43.230076,0 ],
                [13.312258,43.229961,0 ],
                [13.312231,43.229729,0 ],
                [13.312229,43.229515,0 ],
                [13.312379,43.229309,0 ],
                [13.312353,43.229214,0 ],
                [13.312453,43.229160,0 ],
                [13.312554,43.229198,0 ],
                [13.312705,43.229263,0 ],
                [13.312901,43.229362,0 ],
                [13.313267,43.229580,0 ],
                [13.314588,43.229885,0 ],
                [13.314689,43.229893,0 ],
                [13.316012,43.229652,0 ],
                [13.317237,43.229561,0 ],
                [13.317764,43.229519,0 ],
                [13.318210,43.229397,0 ],
                [13.318680,43.229248,0 ],
                [13.319269,43.229084,0 ],
                [13.320009,43.228928,0 ],
                [13.320279,43.228821,0 ],
                [13.320459,43.228630,0 ],
                [13.320591,43.228577,0 ],
                [13.321075,43.228657,0 ],
                [13.321232,43.228611,0 ],
                [13.321577,43.228485,0 ],
                [13.322189,43.228043,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SAN BARTOLOMEO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.263965,43.216057 ,0],
                [13.264482,43.215977,0 ],
                [13.264862,43.215870,0 ],
                [13.265539,43.215656,0 ],
                [13.265836,43.215591,0 ],
                [13.266108,43.215668,0 ],
                [13.266338,43.215832,0 ],
                [13.266611,43.216068,0 ],
                [13.266874,43.216160,0 ],
                [13.267162,43.216141,0 ],
                [13.267434,43.216091,0 ],
                [13.267662,43.215988,0 ],
                [13.268017,43.215740,0 ],
                [13.268456,43.215374,0 ],
                [13.268606,43.215076,0 ],
                [13.268662,43.214573,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SAN DIEGO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.244740,43.191738 ,0],
                [13.244908,43.191734,0 ],
                [13.246709,43.191303,0 ],
                [13.247725,43.191048,0 ],
                [13.248065,43.191002,0 ],
                [13.248384,43.191025,0 ],
                [13.250216,43.191296,0 ],
                [13.250541,43.191326,0 ],
                [13.250808,43.191296,0 ],
                [13.251781,43.190971,0 ],
                [13.251968,43.190826,0 ],
                [13.252036,43.190704,0 ],
                [13.252253,43.190113,0 ],
                [13.252382,43.189899,0 ],
                [13.252528,43.189781,0 ],
                [13.252764,43.189617,0 ],
                [13.252973,43.189518,0 ],
                [13.253229,43.189438,0 ],
                [13.254590,43.189098,0 ],
                [13.254889,43.189064,0 ],
                [13.255124,43.189091,0 ],
                [13.255292,43.189156,0 ],
                [13.255440,43.189285,0 ],
                [13.255529,43.189426,0 ],
                [13.255615,43.189663,0 ],
                [13.255695,43.189938,0 ],
                [13.255702,43.190243,0 ],
                [13.255552,43.190628,0 ],
                [13.255325,43.191120,0 ],
                [13.255321,43.191284,0 ],
                [13.255374,43.191467,0 ],
                [13.255522,43.191586,0 ],
                [13.255748,43.191654,0 ],
                [13.256031,43.191654,0 ],
                [13.256612,43.191586,0 ],
                [13.259356,43.191135,0 ],
                [13.259533,43.191109,0 ],
                [13.260734,43.190933,0 ],
                [13.261084,43.190773,0 ],
                [13.262075,43.190170,0 ],
                [13.262484,43.190033,0 ],
                [13.262823,43.189972,0 ],
                [13.263330,43.189888,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SAN GIOVANNI",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.286261,43.225368 ,0],
                [13.285960,43.225033,0 ],
                [13.285526,43.224682,0 ],
                [13.284967,43.224350,0 ],
                [13.284676,43.224136,0 ],
                [13.284491,43.223743,0 ],
                [13.284573,43.223621,0 ],
                [13.285120,43.223560,0 ],
                [13.285253,43.223469,0 ],
                [13.286309,43.222511,0 ],
                [13.287753,43.221218,0 ],
                [13.288134,43.221088,0 ],
                [13.289021,43.220913,0 ],
                [13.289278,43.220867,0 ],
                [13.289494,43.220776,0 ],
                [13.289716,43.220570,0 ],
                [13.289798,43.220421,0 ],
                [13.289781,43.220242,0 ],
                [13.289479,43.219891,0 ],
                [13.288929,43.219448,0 ],
                [13.288919,43.219337,0 ],
                [13.290232,43.218216,0 ],
                [13.290231,43.218067,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SAN GIUSEPPE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.269749,43.242981 ,0],
                [13.269712,43.242771,0 ],
                [13.269534,43.242428,0 ],
                [13.269288,43.242111,0 ],
                [13.269014,43.241791,0 ],
                [13.268891,43.241592,0 ],
                [13.268795,43.241356,0 ],
                [13.268800,43.241096,0 ],
                [13.268887,43.240849,0 ],
                [13.269344,43.240307,0 ],
                [13.269397,43.239975,0 ],
                [13.269713,43.239548,0 ],
                [13.269698,43.239288,0 ],
                [13.269341,43.238724,0 ],
                [13.269055,43.238464,0 ],
                [13.268762,43.238201,0 ],
                [13.268537,43.237957,0 ],
                [13.268365,43.237724,0 ],
                [13.268146,43.237232,0 ],
                [13.267973,43.236790,0 ],
                [13.267534,43.236080,0 ],
                [13.267301,43.235592,0 ],
                [13.267313,43.235367,0 ],
                [13.267440,43.235062,0 ],
                [13.267763,43.234741,0 ],
                [13.267681,43.234520,0 ],
                [13.267686,43.234230,0 ],
                [13.267831,43.233532,0 ],
                [13.267931,43.233303,0 ],
                [13.268146,43.232891,0 ],
                [13.268821,43.232437,0 ],
                [13.269166,43.232307,0 ],
                [13.269818,43.232365,0 ],
                [13.270292,43.232349,0 ],
                [13.271561,43.232265,0 ],
                [13.271703,43.232220,0 ],
                [13.271817,43.232086,0 ],
                [13.271829,43.231758,0 ],
                [13.272139,43.231323,0 ],
                [13.272293,43.231232,0 ],
                [13.272930,43.231064,0 ],
                [13.274277,43.230564,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SAN MARTINO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.262426,43.202232 ,0],
                [13.262752,43.202053,0 ],
                [13.262999,43.201946,0 ],
                [13.263208,43.201870,0 ],
                [13.264090,43.201645,0 ],
                [13.264310,43.201519,0 ],
                [13.264478,43.201401,0 ],
                [13.264676,43.201157,0 ],
                [13.265386,43.200573,0 ],
                [13.265823,43.200359,0 ],
                [13.266168,43.200249,0 ],
                [13.266487,43.200203,0 ],
                [13.267087,43.200142,0 ],
                [13.267323,43.200199,0 ],
                [13.267581,43.200462,0 ],
                [13.267717,43.200623,0 ],
                [13.267919,43.201061,0 ],
                [13.267980,43.201149,0 ],
                [13.268063,43.201206,0 ],
                [13.268318,43.201321,0 ],
                [13.268766,43.201580,0 ],
                [13.269230,43.201824,0 ],
                [13.269381,43.201870,0 ],
                [13.269648,43.202000,0 ],
                [13.269858,43.202137,0 ],
                [13.269949,43.202229,0 ],
                [13.269969,43.202400,0 ],
                [13.270034,43.202499,0 ],
                [13.270083,43.202637,0 ],
                [13.270054,43.202789,0 ],
                [13.270081,43.202847,0 ],
                [13.270152,43.202908,0 ],
                [13.270285,43.202961,0 ],
                [13.270604,43.203030,0 ],
                [13.270755,43.203182,0 ],
                [13.270936,43.203331,0 ],
                [13.271271,43.203434,0 ],
                [13.271455,43.203430,0 ],
                [13.271560,43.203468,0 ],
                [13.271934,43.203808,0 ],
                [13.272138,43.203899,0 ],
                [13.272370,43.203960,0 ],
                [13.272802,43.204052,0 ],
                [13.273074,43.204182,0 ],
                [13.273270,43.204220,0 ],
                [13.273469,43.204273,0 ],
                [13.273951,43.204479,0 ],
                [13.274196,43.204620,0 ],
                [13.274327,43.204678,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SAN ROCCO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.273518,43.185257 ,0],
                [13.273588,43.185173,0 ],
                [13.273992,43.184864,0 ],
                [13.274157,43.184597,0 ],
                [13.274287,43.184448,0 ],
                [13.274685,43.184166,0 ],
                [13.274811,43.184052,0 ],
                [13.274845,43.183971,0 ],
                [13.274875,43.183800,0 ],
                [13.274865,43.183453,0 ],
                [13.274881,43.183346,0 ],
                [13.274992,43.183178,0 ],
                [13.275131,43.182987,0 ],
                [13.275419,43.182762,0 ],
                [13.275674,43.182522,0 ],
                [13.275723,43.182438,0 ],
                [13.275667,43.182144,0 ],
                [13.275679,43.182083,0 ],
                [13.275728,43.182026,0 ],
                [13.276005,43.181953,0 ],
                [13.276099,43.181911,0 ],
                [13.276624,43.181202,0 ],
                [13.276760,43.181107,0 ],
                [13.277057,43.181015,0 ],
                [13.277308,43.180920,0 ],
                [13.277778,43.180695,0 ],
                [13.278712,43.180122,0 ],
                [13.279230,43.179714,0 ],
                [13.279768,43.179207,0 ],
                [13.279846,43.179127,0 ],
                [13.279879,43.179043,0 ],
                [13.279869,43.178844,0 ],
                [13.279926,43.178787,0 ],
                [13.280017,43.178764,0 ],
                [13.280117,43.178810,0 ],
                [13.280209,43.178909,0 ],
                [13.280291,43.178951,0 ],
                [13.280402,43.178959,0 ],
                [13.280514,43.178932,0 ],
                [13.280604,43.178871,0 ],
                [13.280732,43.178753,0 ],
                [13.280929,43.178440,0 ],
                [13.281031,43.178349,0 ],
                [13.281270,43.178234,0 ],
                [13.281443,43.178143,0 ],
                [13.281599,43.177959,0 ],
                [13.281635,43.177883,0 ],
                [13.281568,43.177670,0 ],
                [13.281592,43.177582,0 ],
                [13.281694,43.177483,0 ],
                [13.281966,43.177261,0 ],
                [13.282505,43.176914,0 ],
                [13.282596,43.176826,0 ],
                [13.282591,43.176750,0 ],
                [13.282557,43.176670,0 ],
                [13.282445,43.176502,0 ],
                [13.282365,43.176353,0 ],
                [13.282331,43.176105,0 ],
                [13.282358,43.175869,0 ],
                [13.282390,43.175728,0 ],
                [13.282488,43.175571,0 ],
                [13.282623,43.175434,0 ],
                [13.282730,43.175259,0 ],
                [13.282816,43.175159,0 ],
                [13.282952,43.175106,0 ],
                [13.283055,43.175037,0 ],
                [13.283095,43.174961,0 ],
                [13.283050,43.174839,0 ],
                [13.283028,43.174717,0 ],
                [13.283040,43.174629,0 ],
                [13.283137,43.174389,0 ],
                [13.283212,43.174320,0 ],
                [13.283335,43.174263,0 ],
                [13.283413,43.174202,0 ],
                [13.283448,43.173923,0 ],
                [13.283411,43.173840,0 ],
                [13.283278,43.173710,0 ],
                [13.283244,43.173607,0 ],
                [13.283340,43.173092,0 ],
                [13.283401,43.172993,0 ],
                [13.283516,43.172924,0 ],
                [13.283913,43.172836,0 ],
                [13.284048,43.172756,0 ],
                [13.284113,43.172504,0 ],
                [13.284144,43.172291,0 ],
                [13.284210,43.172192,0 ],
                [13.284404,43.172100,0 ],
                [13.284620,43.171783,0 ],
                [13.284752,43.171661,0 ],
                [13.285448,43.171368,0 ],
                [13.285551,43.171303,0 ],
                [13.285612,43.171215,0 ],
                [13.285607,43.171116,0 ],
                [13.285434,43.170479,0 ],
                [13.285265,43.169868,0 ],
                [13.285196,43.169502,0 ],
                [13.285233,43.169399,0 ],
                [13.285597,43.168877,0 ],
                [13.285597,43.168781,0 ],
                [13.285550,43.168694,0 ],
                [13.285371,43.168438,0 ],
                [13.285367,43.168346,0 ],
                [13.285412,43.168266,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SANTA CROCE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.330091,43.199009 ,0],
                [13.330497,43.198872,0 ],
                [13.330907,43.198700,0 ],
                [13.331461,43.198372,0 ],
                [13.332112,43.198032,0 ],
                [13.332233,43.197922,0 ],
                [13.332336,43.197765,0 ],
                [13.332377,43.197624,0 ],
                [13.332475,43.197090,0 ],
                [13.332588,43.196564,0 ],
                [13.332687,43.196434,0 ],
                [13.332879,43.196327,0 ],
                [13.333063,43.196281,0 ],
                [13.333289,43.196266,0 ],
                [13.334748,43.196323,0 ],
                [13.334987,43.196365,0 ],
                [13.335180,43.196404,0 ],
                [13.335895,43.196667,0 ],
                [13.336654,43.196896,0 ],
                [13.337040,43.196972,0 ],
                [13.337342,43.196987,0 ],
                [13.337618,43.196972,0 ],
                [13.337857,43.196930,0 ],
                [13.338112,43.196857,0 ],
                [13.338505,43.196716,0 ],
                [13.341613,43.195469,0 ],
                [13.341826,43.195461,0 ],
                [13.342015,43.195492,0 ],
                [13.342187,43.195541,0 ],
                [13.342284,43.195610,0 ],
                [13.342385,43.195709,0 ],
                [13.342538,43.195934,0 ],
                [13.342677,43.196095,0 ],
                [13.342774,43.196186,0 ],
                [13.342942,43.196278,0 ],
                [13.343199,43.196335,0 ],
                [13.344956,43.196632,0 ],
                [13.348241,43.197212,0 ],
                [13.348400,43.197212,0 ],
                [13.348593,43.197174,0 ],
                [13.349052,43.197006,0 ],
                [13.349240,43.196957,0 ],
                [13.349462,43.196926,0 ],
                [13.350296,43.196926,0 ],
                [13.350492,43.196899,0 ],
                [13.350635,43.196838,0 ],
                [13.352057,43.195988,0 ],
                [13.352186,43.195930,0 ],
                [13.352341,43.195881,0 ],
                [13.352484,43.195904,0 ],
                [13.352627,43.195999,0 ],
                [13.352724,43.196098,0 ],
                [13.352775,43.196190,0 ],
                [13.352797,43.196289,0 ],
                [13.352756,43.196423,0 ],
                [13.352406,43.196697,0 ],
                [13.352377,43.196781,0 ],
                [13.352386,43.196865,0 ],
                [13.352445,43.196934,0 ],
                [13.352554,43.196983,0 ],
                [13.354946,43.197498,0 ],
                [13.355093,43.197529,0 ],
                [13.355244,43.197506,0 ],
                [13.355331,43.197449,0 ],
                [13.355372,43.197342,0 ],
                [13.355181,43.196354,0 ],
                [13.355138,43.196262,0 ],
                [13.355042,43.196186,0 ],
                [13.354915,43.196110,0 ],
                [13.354351,43.195839,0 ],
                [13.354263,43.195778,0 ],
                [13.354229,43.195671,0 ],
                [13.354253,43.195560,0 ],
                [13.354621,43.194935,0 ],
                [13.354674,43.194801,0 ],
                [13.354673,43.194668,0 ],
                [13.354651,43.194553,0 ],
                [13.354579,43.194401,0 ],
                [13.352797,43.191940,0 ],
                [13.352746,43.191807,0 ],
                [13.352733,43.191723,0 ],
                [13.352769,43.191597,0 ],
                [13.352839,43.191502,0 ],
                [13.352940,43.191448,0 ],
                [13.353538,43.191200,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SANTA LUCIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.247354,43.227245 ,0],
                [13.247844,43.226929,0 ],
                [13.248309,43.226692,0 ],
                [13.248885,43.226547,0 ],
                [13.249384,43.226273,0 ],
                [13.249713,43.225937,0 ],
                [13.250014,43.225365,0 ],
                [13.250454,43.225010,0 ],
                [13.250648,43.224812,0 ],
                [13.250747,43.224377,0 ],
                [13.250882,43.224232,0 ],
                [13.251178,43.224022,0 ],
                [13.251287,43.223766,0 ],
                [13.251310,43.223457,0 ],
                [13.251249,43.223213,0 ],
                [13.251025,43.222687,0 ],
                [13.251041,43.222515,0 ],
                [13.251497,43.222195,0 ],
                [13.251674,43.221886,0 ],
                [13.251680,43.221607,0 ],
                [13.251552,43.221214,0 ],
                [13.251534,43.221024,0 ],
                [13.251760,43.220711,0 ],
                [13.251776,43.220459,0 ],
                [13.251526,43.219727,0 ],
                [13.251524,43.219536,0 ],
                [13.251869,43.219101,0 ],
                [13.252258,43.218800,0 ],
                [13.252588,43.218632,0 ],
                [13.253426,43.218292,0 ],
                [13.254610,43.217781,0 ],
                [13.255075,43.217514,0 ],
                [13.255540,43.217163,0 ],
                [13.255734,43.217060,0 ],
                [13.256014,43.217007,0 ],
                [13.256277,43.217033,0 ],
                [13.257254,43.217316,0 ],
                [13.257645,43.217339,0 ],
                [13.258077,43.217274,0 ],
                [13.258407,43.217144,0 ],
                [13.258855,43.216911,0 ],
                [13.259168,43.216724,0 ],
                [13.259294,43.216614,0 ],
                [13.259428,43.216377,0 ],
                [13.259648,43.216244,0 ],
                [13.259877,43.216209,0 ],
                [13.260233,43.216202,0 ],
                [13.260504,43.216156,0 ],
                [13.260809,43.216011,0 ],
                [13.261045,43.215919,0 ],
                [13.261326,43.215904,0 ],
                [13.261580,43.215992,0 ],
                [13.262040,43.216225,0 ],
                [13.262506,43.216278,0 ],
                [13.262939,43.216228,0 ],
                [13.263821,43.216091,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SANT&#x27;ANDREA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.285440,43.168228 ,0],
                [13.285469,43.168182,0 ],
                [13.285547,43.168167,0 ],
                [13.286432,43.168289,0 ],
                [13.286581,43.168316,0 ],
                [13.286693,43.168358,0 ],
                [13.286797,43.168434,0 ],
                [13.286867,43.168472,0 ],
                [13.286962,43.168472,0 ],
                [13.287045,43.168449,0 ],
                [13.287160,43.168385,0 ],
                [13.287234,43.168362,0 ],
                [13.287440,43.168358,0 ],
                [13.287556,43.168335,0 ],
                [13.287742,43.168289,0 ],
                [13.288199,43.168125,0 ],
                [13.288278,43.168068,0 ],
                [13.288277,43.168003,0 ],
                [13.288194,43.167942,0 ],
                [13.287945,43.167824,0 ],
                [13.287427,43.167557,0 ],
                [13.287340,43.167530,0 ],
                [13.287191,43.167553,0 ],
                [13.286902,43.167641,0 ],
                [13.286820,43.167625,0 ],
                [13.286787,43.167576,0 ],
                [13.286864,43.167496,0 ],
                [13.287127,43.167294,0 ],
                [13.287346,43.167137,0 ],
                [13.287526,43.166985,0 ],
                [13.287604,43.166878,0 ],
                [13.287800,43.166485,0 ],
                [13.287774,43.166367,0 ],
                [13.287551,43.165703,0 ],
                [13.287538,43.165470,0 ],
                [13.287516,43.164700,0 ],
                [13.287536,43.164635,0 ],
                [13.287581,43.164577,0 ],
                [13.287845,43.164398,0 ],
                [13.288000,43.164234,0 ],
                [13.288085,43.164024,0 ],
                [13.288130,43.163841,0 ],
                [13.288200,43.163696,0 ],
                [13.288378,43.163452,0 ],
                [13.288465,43.163296,0 ],
                [13.288453,43.163208,0 ],
                [13.288165,43.162899,0 ],
                [13.288139,43.162827,0 ],
                [13.288178,43.162556,0 ],
                [13.288165,43.162205,0 ],
                [13.288179,43.161991,0 ],
                [13.288204,43.161804,0 ],
                [13.288208,43.161617,0 ],
                [13.288109,43.161301,0 ],
                [13.287977,43.160732,0 ],
                [13.287918,43.160378,0 ],
                [13.287721,43.159832,0 ],
                [13.287065,43.158810,0 ],
                [13.286828,43.158577,0 ],
                [13.286740,43.158546,0 ],
                [13.286486,43.158585,0 ],
                [13.286214,43.158585,0 ],
                [13.286056,43.158558,0 ],
                [13.285917,43.158504,0 ],
                [13.285876,43.158466,0 ],
                [13.285907,43.158424,0 ],
                [13.286212,43.158287,0 ],
                [13.286248,43.158234,0 ],
                [13.286227,43.158157,0 ],
                [13.285666,43.157669,0 ],
                [13.284829,43.157082,0 ],
                [13.284531,43.156811,0 ],
                [13.284469,43.156731,0 ],
                [13.284443,43.156639,0 ],
                [13.284372,43.156017,0 ],
                [13.284531,43.155918,0 ],
                [13.284657,43.155666,0 ],
                [13.284721,43.155415,0 ],
                [13.284843,43.155342,0 ],
                [13.285073,43.155277,0 ],
                [13.285247,43.155201,0 ],
                [13.285369,43.155220,0 ],
                [13.285704,43.155502,0 ],
                [13.285821,43.155521,0 ],
                [13.286102,43.155464,0 ],
                [13.286430,43.155575,0 ],
                [13.286713,43.155731,0 ],
                [13.286860,43.155750,0 ],
                [13.287203,43.155704,0 ],
                [13.287413,43.155712,0 ],
                [13.287551,43.155743,0 ],
                [13.287755,43.155739,0 ],
                [13.287945,43.155750,0 ],
                [13.288262,43.155869,0 ],
                [13.288488,43.155972,0 ],
                [13.288894,43.156193,0 ],
                [13.289467,43.156399,0 ],
                [13.289913,43.156521,0 ],
                [13.290195,43.156643,0 ],
                [13.290452,43.156872,0 ],
                [13.290545,43.156925,0 ],
                [13.290703,43.156948,0 ],
                [13.290831,43.156933,0 ],
                [13.291540,43.156712,0 ],
                [13.291790,43.156624,0 ],
                [13.292056,43.156631,0 ],
                [13.292277,43.156788,0 ],
                [13.292462,43.156967,0 ],
                [13.292561,43.157108,0 ],
                [13.292622,43.157177,0 ],
                [13.293073,43.157295,0 ],
                [13.293615,43.157436,0 ],
                [13.293969,43.157597,0 ],
                [13.294057,43.157600,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA SANT&#x27;ANGELO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.324715,43.181755 ,0],
                [13.324838,43.181767,0 ],
                [13.325100,43.181747,0 ],
                [13.325508,43.181702,0 ],
                [13.325731,43.181683,0 ],
                [13.326003,43.181683,0 ],
                [13.326578,43.181698,0 ],
                [13.326841,43.181725,0 ],
                [13.327325,43.181820,0 ],
                [13.327614,43.181843,0 ],
                [13.329325,43.181816,0 ],
                [13.329492,43.181828,0 ],
                [13.329900,43.181915,0 ],
                [13.330119,43.181946,0 ],
                [13.330286,43.181931,0 ],
                [13.330680,43.181801,0 ],
                [13.330876,43.181744,0 ],
                [13.331069,43.181709,0 ],
                [13.331276,43.181713,0 ],
                [13.331578,43.181736,0 ],
                [13.332373,43.181820,0 ],
                [13.333049,43.181908,0 ],
                [13.333531,43.181965,0 ],
                [13.333659,43.181950,0 ],
                [13.333869,43.181885,0 ],
                [13.334097,43.181839,0 ],
                [13.334315,43.181801,0 ],
                [13.334947,43.181736,0 ],
                [13.335402,43.181728,0 ],
                [13.335547,43.181759,0 ],
                [13.335939,43.181950,0 ],
                [13.336353,43.182198,0 ],
                [13.337797,43.182907,0 ],
                [13.337952,43.183056,0 ],
                [13.338243,43.183167,0 ],
                [13.338365,43.183151,0 ],
                [13.338474,43.183167,0 ],
                [13.340097,43.183815,0 ],
                [13.340481,43.183968,0 ],
                [13.340631,43.184063,0 ],
                [13.340913,43.184299,0 ],
                [13.341098,43.184448,0 ],
                [13.341222,43.184555,0 ],
                [13.341649,43.184761,0 ],
                [13.342340,43.185139,0 ],
                [13.342569,43.185284,0 ],
                [13.342927,43.185661,0 ],
                [13.343079,43.185883,0 ],
                [13.343150,43.186085,0 ],
                [13.343164,43.186329,0 ],
                [13.343935,43.187302,0 ],
                [13.344032,43.187393,0 ],
                [13.344156,43.187477,0 ],
                [13.344363,43.187595,0 ],
                [13.344645,43.187691,0 ],
                [13.347292,43.187988,0 ],
                [13.347810,43.188046,0 ],
                [13.347941,43.188087,0 ],
                [13.348285,43.188248,0 ],
                [13.349333,43.188824,0 ],
                [13.349950,43.189178,0 ],
                [13.350091,43.189251,0 ],
                [13.350223,43.189304,0 ],
                [13.350842,43.189407,0 ],
                [13.351750,43.189476,0 ],
                [13.351892,43.189522,0 ],
                [13.352023,43.189587,0 ],
                [13.352292,43.189754,0 ],
                [13.352354,43.189838,0 ],
                [13.352431,43.190113,0 ],
                [13.352484,43.190205,0 ],
                [13.352569,43.190319,0 ],
                [13.352688,43.190418,0 ],
                [13.352829,43.190517,0 ],
                [13.353067,43.190742,0 ],
                [13.353178,43.190884,0 ],
                [13.353201,43.191013,0 ],
                [13.353167,43.191116,0 ],
                [13.353132,43.191208,0 ],
                [13.352914,43.191338,0 ],
                [13.352783,43.191418,0 ],
                [13.352692,43.191509,0 ],
                [13.352644,43.191624,0 ],
                [13.352641,43.191761,0 ],
                [13.352663,43.191830,0 ],
                [13.352712,43.191875,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA TROIANO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.257380,43.218525 ,0],
                [13.257826,43.218391,0 ],
                [13.258199,43.218243,0 ],
                [13.258641,43.218052,0 ],
                [13.258975,43.217903,0 ],
                [13.259164,43.217846,0 ],
                [13.259722,43.217831,0 ],
                [13.260006,43.217793,0 ],
                [13.260489,43.217602,0 ],
                [13.260896,43.217430,0 ],
                [13.261254,43.217335,0 ],
                [13.261956,43.217220,0 ],
                [13.263530,43.216995,0 ],
                [13.263888,43.217007,0 ],
                [13.265125,43.217148,0 ],
                [13.265993,43.217262,0 ],
                [13.266308,43.217274,0 ],
                [13.266546,43.217220,0 ],
                [13.266695,43.217133,0 ],
                [13.266854,43.217003,0 ],
                [13.266943,43.216866,0 ],
                [13.266992,43.216709,0 ],
                [13.267035,43.216488,0 ],
                [13.267109,43.216343,0 ],
                [13.267253,43.216259,0 ],
                [13.267806,43.216110,0 ],
                [13.267995,43.216034,0 ],
                [13.268124,43.215935,0 ],
                [13.268316,43.215679,0 ],
                [13.268539,43.215485,0 ],
                [13.268777,43.215271,0 ],
                [13.268916,43.215088,0 ],
                [13.268990,43.214878,0 ],
                [13.268938,43.214680,0 ],
                [13.268867,43.214539,0 ],
                [13.268742,43.214386,0 ],
                [13.268790,43.214184,0 ],
                [13.268899,43.214020,0 ],
                [13.269073,43.213921,0 ],
                [13.269292,43.213879,0 ],
                [13.269636,43.213898,0 ],
                [13.269936,43.213924,0 ],
                [13.270194,43.213913,0 ],
                [13.270463,43.213833,0 ],
                [13.270701,43.213715,0 ],
                [13.270905,43.213623,0 ],
                [13.271194,43.213593,0 ],
                [13.271907,43.213604,0 ],
                [13.272934,43.213665,0 ],
                [13.273323,43.213676,0 ],
                [13.273616,43.213589,0 ],
                [13.273910,43.213417,0 ],
                [13.274202,43.213291,0 ],
                [13.274527,43.213253,0 ],
                [13.274830,43.213230,0 ],
                [13.275472,43.212997,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA VAGLIE",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.266953,43.205444 ,0],
                [13.267140,43.205482,0 ],
                [13.267306,43.205479,0 ],
                [13.268093,43.205330,0 ],
                [13.268858,43.205070,0 ],
                [13.268990,43.205048,0 ],
                [13.269070,43.205063,0 ],
                [13.269199,43.205181,0 ],
                [13.269351,43.205372,0 ],
                [13.269793,43.205887,0 ],
                [13.270153,43.206268,0 ],
                [13.270542,43.206730,0 ],
                [13.270558,43.206799,0 ],
                [13.270395,43.207161,0 ],
                [13.270350,43.207329,0 ],
                [13.270378,43.207359,0 ],
                [13.271039,43.207401,0 ],
                [13.271242,43.207352,0 ],
                [13.271448,43.207268,0 ],
                [13.271480,43.207237,0 ],
                [13.271537,43.207272,0 ],
                [13.271811,43.207378,0 ],
                [13.272099,43.207542,0 ],
                [13.272404,43.207668,0 ],
                [13.272752,43.207890,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "CONTRADA VICIGLIANO",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.269237,43.244068 ,0],
                [13.269251,43.244522,0 ],
                [13.269294,43.244629,0 ],
                [13.269511,43.244724,0 ],
                [13.270754,43.245132,0 ],
                [13.270959,43.245209,0 ],
                [13.271147,43.245342,0 ],
                [13.271581,43.245457,0 ],
                [13.271936,43.245567,0 ],
                [13.273587,43.245716,0 ],
                [13.273913,43.245777,0 ],
                [13.275723,43.246449,0 ],
                [13.275959,43.246552,0 ],
                [13.277974,43.248203,0 ],
                [13.278119,43.248264,0 ],
                [13.278716,43.248280,0 ],
                [13.279047,43.248314,0 ],
                [13.280362,43.248714,0 ],
                [13.280719,43.248837,0 ],
                [13.282196,43.249153,0 ],
                [13.283028,43.249321,0 ],
                [13.283697,43.249447,0 ],
                [13.283908,43.249496,0 ],
                [13.285067,43.249908,0 ],
                [13.285491,43.249989,0 ],
                [13.286571,43.250141,0 ],
                [13.287846,43.250519,0 ],
                [13.288112,43.250553,0 ],
                [13.288885,43.250584,0 ],
                [13.289135,43.250683,0 ],
                [13.289580,43.251049,0 ],
                [13.290098,43.251404,0 ],
                [13.290665,43.251839,0 ],
                [13.291538,43.252449,0 ],
                [13.291871,43.252789,0 ],
                [13.292380,43.253170,0 ],
                [13.293229,43.253632,0 ],
                [13.293666,43.253922,0 ],
                [13.294200,43.254223,0 ],
                [13.294547,43.254356,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "LARGO DELLA GIUSTIZIA",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.308253,43.217941 ,0],
                [13.308999,43.216911,0 ],
                [13.309826,43.217224,0 ],
                [13.309584,43.217552,0 ],
                [13.310415,43.217888,0 ],
                [13.310371,43.217934,0 ],
                [13.309536,43.217609,0 ],
                [13.309203,43.218048,0 ],
                [13.308500,43.217766,0 ]
                ]
              }
            ]
          } 
       ,{ "type": "Feature",
          "properties": {
            "name": "TRAVERSA DELLA SOLIDARIET&#xc0;",
            "description": "",
            "style": {
              "lineStyle": {"color": "#696969","width": "1.000000" }
              },
            "end": ""
          },
          "multigeometry": [
            { "type": "LineString",
              "coordinates": [
                [13.308251,43.216183 ,0],
                [13.310364,43.217052,0 ],
                [13.310663,43.217304,0 ]
                ]
              }
            ]
          } 
        ],
      "bbox": [13.244740,43.154957,13.375279,43.254356]
      }
    ]
  }  );