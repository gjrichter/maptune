ixmaps.jsapi.import(
{ "type": "Map",
  "name": "world",
  "title": "",
  "description": "",
  "comment": "Creator: JsonGis 1.1 version:1.1 build:255 generation-time:Wed Jan 30 19:00:21 2013 ",
  "bbox": [-85,-60,85,80],
  "layers": [
    { "type": "FeatureCollection",
      "properties": {
        "name": "World_countries_shp",
        "description": "",
        "Snippet": "",
        "visibility": "1",
        "open": "1",
        "legendstyle": "|NOLEGEND",
        "end": ""
      },
      "features": [
        ],
      "bbox": [-80,-40,80,40]
      }
    ]
  }  );